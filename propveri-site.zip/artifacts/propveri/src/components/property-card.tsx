import { Link } from "wouter";
import { Building2, CheckCircle2, MapPin, AlertTriangle, Clock } from "lucide-react";
import { formatIndianPrice, calculatePriceDiff, cn } from "@/lib/utils";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent, CardFooter } from "@/components/ui/card";

export function PropertyCard({ property }: { property: any }) {
  const { isWarning, percentage } = calculatePriceDiff(property.listedPrice, property.actualVisitPrice);
  
  return (
    <Link href={`/properties/${property.id}`} className="group block h-full">
      <Card className="overflow-hidden h-full flex flex-col transition-all duration-300 hover:shadow-lg hover:border-primary/50 bg-card">
        <div className="relative aspect-[4/3] bg-muted overflow-hidden">
          {property.imageUrl ? (
            <img src={property.imageUrl} alt={property.title} className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105" />
          ) : (
            <div className="w-full h-full flex items-center justify-center bg-secondary">
              <Building2 className="w-12 h-12 text-muted-foreground/30" />
            </div>
          )}
          
          <div className="absolute top-3 left-3 flex flex-col gap-2">
            {property.locationVerified ? (
              <Badge variant="secondary" className="bg-green-100 text-green-800 hover:bg-green-100 border-green-200 shadow-sm flex items-center gap-1 font-medium">
                <CheckCircle2 className="w-3.5 h-3.5" /> Verified Location
              </Badge>
            ) : (
              <Badge variant="secondary" className="bg-amber-100 text-amber-800 hover:bg-amber-100 border-amber-200 shadow-sm flex items-center gap-1 font-medium">
                <Clock className="w-3.5 h-3.5" /> Pending Verification
              </Badge>
            )}
            {property.featured && (
              <Badge className="bg-primary text-primary-foreground shadow-sm font-medium w-fit">
                Featured
              </Badge>
            )}
            {property.status === 'sold' && (
              <Badge className="bg-destructive text-destructive-foreground shadow-sm font-medium w-fit">
                Sold
              </Badge>
            )}
          </div>
        </div>
        
        <CardContent className="p-5 flex-1 flex flex-col">
          <div className="flex items-center gap-1.5 text-sm text-muted-foreground mb-2 font-medium">
            <MapPin className="w-3.5 h-3.5" />
            <span>{property.city}, {property.state}</span>
          </div>
          
          <h3 className="font-semibold text-lg line-clamp-2 mb-4 group-hover:text-primary transition-colors leading-tight">
            {property.title}
          </h3>
          
          <div className="mt-auto grid grid-cols-2 gap-3 p-3 bg-secondary/50 rounded-lg">
            <div>
              <p className="text-xs text-muted-foreground font-medium mb-1">Listed Price</p>
              <p className="font-semibold text-lg">{formatIndianPrice(property.listedPrice)}</p>
            </div>
            <div>
              <p className="text-xs text-muted-foreground font-medium mb-1 flex items-center gap-1">
                Actual Visit
                {isWarning && <AlertTriangle className="w-3 h-3 text-destructive" />}
              </p>
              <p className={cn("font-semibold text-lg", isWarning ? "text-destructive" : "text-foreground")}>
                {formatIndianPrice(property.actualVisitPrice)}
              </p>
            </div>
          </div>
          
          {isWarning && (
            <div className="mt-3 text-xs flex items-start gap-1.5 text-destructive bg-destructive/10 p-2 rounded text-left">
              <AlertTriangle className="w-3.5 h-3.5 shrink-0 mt-0.5" />
              <span>Visit price is {percentage.toFixed(0)}% higher than listed</span>
            </div>
          )}
        </CardContent>
        
        <CardFooter className="p-5 pt-0 flex justify-between items-center text-sm border-t border-border/50 bg-card mt-auto">
          <div className="flex gap-4 text-muted-foreground font-medium">
            <span>{property.bedrooms} Beds</span>
            <span>{property.bathrooms} Baths</span>
          </div>
          <span className="font-medium">{property.areasqft} sqft</span>
        </CardFooter>
      </Card>
    </Link>
  );
}