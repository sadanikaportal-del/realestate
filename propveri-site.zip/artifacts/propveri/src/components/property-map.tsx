import { useEffect, useRef, useState } from "react";
import { Link } from "wouter";
import { MapContainer, TileLayer, Marker, Popup, useMap } from "react-leaflet";
import L from "leaflet";
import { Bed, Square, MapPin, ExternalLink } from "lucide-react";
import { formatIndianPrice, cn } from "@/lib/utils";
import type { Property } from "@workspace/api-client-react";

// Fix default leaflet icon URL issue in Vite
delete (L.Icon.Default.prototype as any)._getIconUrl;
L.Icon.Default.mergeOptions({
  iconRetinaUrl: new URL("leaflet/dist/images/marker-icon-2x.png", import.meta.url).href,
  iconUrl: new URL("leaflet/dist/images/marker-icon.png", import.meta.url).href,
  shadowUrl: new URL("leaflet/dist/images/marker-shadow.png", import.meta.url).href,
});

function makePriceIcon(price: number, active: boolean) {
  const label = formatIndianPrice(price);
  return L.divIcon({
    className: "",
    html: `
      <div style="
        background: ${active ? "#1e3a6e" : "#ffffff"};
        color: ${active ? "#ffffff" : "#1e3a6e"};
        border: 2px solid #1e3a6e;
        border-radius: 20px;
        padding: 4px 10px;
        font-size: 12px;
        font-weight: 700;
        font-family: 'Open Sans', sans-serif;
        white-space: nowrap;
        box-shadow: 0 2px 8px rgba(0,0,0,0.2);
        position: relative;
        cursor: pointer;
        transition: all 0.15s;
      ">
        ${label}
        <div style="
          position: absolute;
          bottom: -7px;
          left: 50%;
          transform: translateX(-50%);
          width: 0;
          height: 0;
          border-left: 6px solid transparent;
          border-right: 6px solid transparent;
          border-top: 7px solid ${active ? "#1e3a6e" : "#1e3a6e"};
        "></div>
      </div>
    `,
    iconAnchor: [30, 32],
    popupAnchor: [0, -35],
  });
}

function FlyToCity({ city, properties }: { city: string; properties: Property[] }) {
  const map = useMap();
  useEffect(() => {
    if (properties.length === 0) return;
    const pts = properties.map(p => [p.latitude, p.longitude] as [number, number]);
    const bounds = L.latLngBounds(pts);
    map.fitBounds(bounds, { padding: [60, 60], maxZoom: 13 });
  }, [city, properties.length]);
  return null;
}

interface PropertyMapProps {
  properties: Property[];
  city: string;
  activeId: number | null;
  onHover: (id: number | null) => void;
}

export function PropertyMap({ properties, city, activeId, onHover }: PropertyMapProps) {
  const mapRef = useRef<L.Map | null>(null);

  // Default center: India
  const center: [number, number] = [20.5937, 78.9629];

  return (
    <MapContainer
      center={center}
      zoom={5}
      className="w-full h-full z-0"
      ref={mapRef}
    >
      <TileLayer
        attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a>'
        url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
      />

      <FlyToCity city={city} properties={properties} />

      {properties.map(p => (
        <Marker
          key={p.id}
          position={[p.latitude, p.longitude]}
          icon={makePriceIcon(p.listedPrice, activeId === p.id)}
          eventHandlers={{
            mouseover: () => onHover(p.id),
            mouseout: () => onHover(null),
          }}
        >
          <Popup className="property-popup" maxWidth={240} minWidth={220}>
            <div className="font-sans">
              {p.imageUrl && (
                <img
                  src={p.imageUrl}
                  alt={p.title}
                  className="w-full h-28 object-cover rounded-md mb-2"
                  style={{ borderRadius: "6px", marginBottom: "8px", display: "block" }}
                />
              )}
              <p style={{ fontWeight: 700, fontSize: "13px", marginBottom: "4px", lineHeight: "1.3" }}>
                {p.title}
              </p>
              <p style={{ fontSize: "11px", color: "#6b7280", marginBottom: "6px", display: "flex", alignItems: "center", gap: "3px" }}>
                📍 {p.city}, {p.state}
              </p>
              <div style={{ display: "flex", gap: "10px", fontSize: "11px", color: "#6b7280", marginBottom: "8px" }}>
                <span>🛏 {p.bedrooms} Beds</span>
                <span>🚿 {p.bathrooms} Baths</span>
                <span>📐 {p.areasqft} sqft</span>
              </div>
              <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", borderTop: "1px solid #e5e7eb", paddingTop: "8px" }}>
                <div>
                  <p style={{ fontSize: "14px", fontWeight: 700, color: "#1e3a6e" }}>{formatIndianPrice(p.listedPrice)}</p>
                  {p.actualVisitPrice && p.actualVisitPrice !== p.listedPrice && (
                    <p style={{ fontSize: "10px", color: "#ef4444" }}>
                      Visit: {formatIndianPrice(p.actualVisitPrice)}
                    </p>
                  )}
                </div>
                <a
                  href={`/properties/${p.id}`}
                  style={{
                    background: "#1e3a6e", color: "white",
                    padding: "5px 10px", borderRadius: "6px",
                    fontSize: "11px", fontWeight: 600, textDecoration: "none",
                    display: "inline-flex", alignItems: "center", gap: "3px",
                  }}
                >
                  View ↗
                </a>
              </div>
            </div>
          </Popup>
        </Marker>
      ))}
    </MapContainer>
  );
}
