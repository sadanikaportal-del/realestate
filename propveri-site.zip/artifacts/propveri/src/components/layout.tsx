import { Link, useLocation } from "wouter";
import { Search, LayoutDashboard, PlusCircle, Users, Package as PackageIcon, LogOut, User, ChevronDown, Wrench } from "lucide-react";
import logoImg from "/logo.png";
import { cn } from "@/lib/utils";
import { useAuth } from "@/lib/auth-context";
import { Button } from "@/components/ui/button";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";

function NavLink({ href, icon: Icon, children }: { href: string; icon?: any; children: React.ReactNode }) {
  const [location] = useLocation();
  const isActive = location === href || (href !== "/" && location.startsWith(href));

  return (
    <Link href={href} className={cn(
      "flex items-center gap-2 px-3 py-2 rounded-md text-sm font-medium transition-colors",
      isActive
        ? "bg-primary text-primary-foreground"
        : "text-muted-foreground hover:bg-muted hover:text-foreground"
    )}>
      {Icon && <Icon className="w-4 h-4" />}
      {children}
    </Link>
  );
}

export function Layout({ children }: { children: React.ReactNode }) {
  const { user, logout } = useAuth();

  return (
    <div className="min-h-screen bg-background font-sans">
      <header className="sticky top-0 z-50 w-full border-b bg-card/80 backdrop-blur supports-[backdrop-filter]:bg-card/60">
        <div className="container mx-auto px-4 h-16 flex items-center justify-between">
          <div className="flex items-center gap-8">
            <Link href="/" className="flex items-center gap-2">
              <img src={logoImg} alt="PropVeri Logo" className="h-10 w-10 object-contain" />
              <span className="font-bold text-xl tracking-tight text-primary">PropVeri</span>
            </Link>

            <nav className="hidden md:flex items-center gap-1">
              <NavLink href="/properties" icon={Search}>Browse</NavLink>
              <NavLink href="/services" icon={Wrench}>Services</NavLink>
              <NavLink href="/packages" icon={PackageIcon}>Packages</NavLink>
              <NavLink href="/users" icon={Users}>Directory</NavLink>
            </nav>
          </div>

          <div className="flex items-center gap-3">
            {user ? (
              <>
                <Link
                  href="/dashboard"
                  className="text-sm font-medium text-muted-foreground hover:text-foreground transition-colors hidden sm:block"
                >
                  Dashboard
                </Link>

                <DropdownMenu>
                  <DropdownMenuTrigger asChild>
                    <button className="flex items-center gap-2 pl-3 pr-2 py-1.5 rounded-full border border-border hover:bg-muted transition-colors text-sm font-medium">
                      <div className="w-6 h-6 rounded-full bg-primary text-primary-foreground flex items-center justify-center text-xs font-bold">
                        {user.name.charAt(0).toUpperCase()}
                      </div>
                      <span className="hidden sm:block max-w-[100px] truncate">{user.name.split(" ")[0]}</span>
                      <ChevronDown className="w-3.5 h-3.5 text-muted-foreground" />
                    </button>
                  </DropdownMenuTrigger>
                  <DropdownMenuContent align="end" className="w-52">
                    <div className="px-3 py-2">
                      <p className="text-sm font-semibold truncate">{user.name}</p>
                      <p className="text-xs text-muted-foreground truncate">{user.email}</p>
                      <span className="inline-block mt-1 text-[10px] font-medium px-1.5 py-0.5 rounded bg-primary/10 text-primary capitalize">{user.role}</span>
                    </div>
                    <DropdownMenuSeparator />
                    <DropdownMenuItem asChild>
                      <Link href="/dashboard" className="flex items-center gap-2 cursor-pointer">
                        <LayoutDashboard className="w-4 h-4" /> Dashboard
                      </Link>
                    </DropdownMenuItem>
                    <DropdownMenuItem asChild>
                      <Link href="/list-property" className="flex items-center gap-2 cursor-pointer">
                        <PlusCircle className="w-4 h-4" /> List Property
                      </Link>
                    </DropdownMenuItem>
                    <DropdownMenuSeparator />
                    <DropdownMenuItem
                      onClick={() => logout()}
                      className="flex items-center gap-2 text-destructive focus:text-destructive cursor-pointer"
                    >
                      <LogOut className="w-4 h-4" /> Sign Out
                    </DropdownMenuItem>
                  </DropdownMenuContent>
                </DropdownMenu>
              </>
            ) : (
              <>
                <Link
                  href="/signin"
                  className="text-sm font-medium text-muted-foreground hover:text-foreground transition-colors hidden sm:block"
                >
                  Sign In
                </Link>
                <Link
                  href="/signup"
                  className="inline-flex items-center justify-center gap-2 whitespace-nowrap rounded-md text-sm font-medium ring-offset-background transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 bg-primary text-primary-foreground hover:bg-primary/90 h-10 px-4 py-2"
                >
                  <User className="w-4 h-4" />
                  Sign Up
                </Link>
              </>
            )}

            {user && (
              <Link
                href="/list-property"
                className="inline-flex items-center justify-center gap-2 whitespace-nowrap rounded-md text-sm font-medium ring-offset-background transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 bg-primary text-primary-foreground hover:bg-primary/90 h-10 px-4 py-2 hidden sm:inline-flex"
              >
                <PlusCircle className="w-4 h-4" />
                List Property
              </Link>
            )}
          </div>
        </div>
      </header>

      <main className="flex-1">
        {children}
      </main>

      <footer className="border-t bg-card py-12 mt-auto">
        <div className="container mx-auto px-4 text-center text-sm text-muted-foreground">
          <div className="flex items-center justify-center gap-2 mb-4">
            <img src={logoImg} alt="PropVeri Logo" className="h-8 w-8 object-contain" />
            <span className="font-bold text-lg text-foreground">PropVeri</span>
          </div>
          <div className="flex flex-wrap justify-center gap-x-8 gap-y-2 mb-6 text-sm">
            <Link href="/properties" className="hover:text-foreground transition-colors">Browse</Link>
            <Link href="/services" className="hover:text-foreground transition-colors">Services</Link>
            <Link href="/packages" className="hover:text-foreground transition-colors">Packages</Link>
            <Link href="/users" className="hover:text-foreground transition-colors">Directory</Link>
            <Link href="/list-property" className="hover:text-foreground transition-colors">List Property</Link>
          </div>
          <p>Honest property listings for India. No hidden prices. No fake locations.</p>
          <p className="mt-3 opacity-50">&copy; {new Date().getFullYear()} PropVeri. All rights reserved.</p>
        </div>
      </footer>
    </div>
  );
}
