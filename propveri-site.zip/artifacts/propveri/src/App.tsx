import { Switch, Route, Router as WouterRouter } from "wouter";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import { Layout } from "@/components/layout";
import { AuthProvider } from "@/lib/auth-context";
import NotFound from "@/pages/not-found";

import Home from "@/pages/home";
import Properties from "@/pages/properties";
import PropertyDetail from "@/pages/property-detail";
import ListProperty from "@/pages/list-property";
import Dashboard from "@/pages/dashboard";
import Packages from "@/pages/packages";
import Users from "@/pages/users";
import SignIn from "@/pages/signin";
import SignUp from "@/pages/signup";
import Services from "@/pages/services";
import PackersMovers from "@/pages/services/packers-movers";
import RentalAgreement from "@/pages/services/rental-agreement";
import HomeLoan from "@/pages/services/home-loans";
import HomeRepairs from "@/pages/services/home-repairs";
import TenantVerification from "@/pages/services/tenant-verification";
import LegalServices from "@/pages/services/legal-services";
import InteriorDesign from "@/pages/services/interior-design";
import PropertyManagement from "@/pages/services/property-management";

const queryClient = new QueryClient({
  defaultOptions: {
    queries: {
      retry: false,
      refetchOnWindowFocus: false,
    },
  },
});

const AUTH_PATHS = ["/signin", "/signup"];

function Router() {
  return (
    <Switch>
      <Route path="/" component={Home} />
      <Route path="/properties" component={Properties} />
      <Route path="/properties/:id" component={PropertyDetail} />
      <Route path="/list-property" component={ListProperty} />
      <Route path="/dashboard" component={Dashboard} />
      <Route path="/packages" component={Packages} />
      <Route path="/users" component={Users} />
      <Route path="/signin" component={SignIn} />
      <Route path="/signup" component={SignUp} />
      <Route path="/services" component={Services} />
      <Route path="/services/packers-movers" component={PackersMovers} />
      <Route path="/services/rental-agreement" component={RentalAgreement} />
      <Route path="/services/home-loans" component={HomeLoan} />
      <Route path="/services/home-repairs" component={HomeRepairs} />
      <Route path="/services/tenant-verification" component={TenantVerification} />
      <Route path="/services/legal-services" component={LegalServices} />
      <Route path="/services/interior-design" component={InteriorDesign} />
      <Route path="/services/property-management" component={PropertyManagement} />
      <Route component={NotFound} />
    </Switch>
  );
}

function AppShell() {
  return (
    <Switch>
      {AUTH_PATHS.map(p => (
        <Route key={p} path={p}>
          <Router />
        </Route>
      ))}
      <Route>
        <Layout>
          <Router />
        </Layout>
      </Route>
    </Switch>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <WouterRouter base={import.meta.env.BASE_URL.replace(/\/$/, "")}>
          <AuthProvider>
            <AppShell />
          </AuthProvider>
        </WouterRouter>
        <Toaster />
      </TooltipProvider>
    </QueryClientProvider>
  );
}

export default App;
