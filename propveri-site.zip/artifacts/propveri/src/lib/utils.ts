import { clsx, type ClassValue } from "clsx"
import { twMerge } from "tailwind-merge"

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs))
}

export function formatIndianPrice(lakhs: number) {
  if (lakhs >= 100) return `₹${(lakhs / 100).toFixed(2)}Cr`;
  return `₹${lakhs}L`;
}

export function calculatePriceDiff(listed: number, actual: number) {
  const diff = actual - listed;
  const percentage = (diff / listed) * 100;
  return {
    diff,
    percentage,
    isWarning: percentage > 10,
  };
}

export interface PriceBreakdownItem {
  label: string;
  amount: number;
  note: string;
  isTotal?: boolean;
}

export function computePriceBreakdown(
  actualVisitPrice: number,
  type: string,
  areasqft: number
): PriceBreakdownItem[] {
  // All amounts in lakhs
  // Stamp duty: 5% of actual price (Maharashtra/common rate)
  const stampDuty = Math.round(actualVisitPrice * 0.05 * 100) / 100;
  // Registration: 1% of actual price
  const registration = Math.round(actualVisitPrice * 0.01 * 100) / 100;
  // Maintenance deposit: based on area (₹25/sqft → convert to lakhs)
  const maintenance =
    type === "plot" || type === "commercial"
      ? 0
      : Math.round(((areasqft * 25) / 100000) * 100) / 100;
  // Parking: flat for apartment/villa
  const parking =
    type === "apartment" ? 3 : type === "villa" ? 5 : 0;
  // Legal & documentation
  const legal = 0.5;
  // Base price = actual minus all charges
  const charges = stampDuty + registration + maintenance + parking + legal;
  const basePrice = Math.round((actualVisitPrice - charges) * 100) / 100;

  const items: PriceBreakdownItem[] = [
    {
      label: "Base Property Price",
      amount: basePrice,
      note: "Seller's final asking price",
    },
    {
      label: "Stamp Duty",
      amount: stampDuty,
      note: "5% of property value",
    },
    {
      label: "Registration Charges",
      amount: registration,
      note: "1% of property value",
    },
  ];

  if (maintenance > 0) {
    items.push({
      label: "Maintenance Deposit",
      amount: maintenance,
      note: `₹25/sqft for ${areasqft} sqft`,
    });
  }

  if (parking > 0) {
    items.push({
      label: "Parking Charges",
      amount: parking,
      note: type === "villa" ? "2-car covered parking" : "Dedicated parking slot",
    });
  }

  items.push({
    label: "Legal & Documentation",
    amount: legal,
    note: "Title search, agreement drafting",
  });

  items.push({
    label: "Total Cost to Buyer",
    amount: actualVisitPrice,
    note: "All-inclusive move-in cost",
    isTotal: true,
  });

  return items;
}