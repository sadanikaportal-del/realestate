import { useState, useMemo } from "react";
import { Link } from "wouter";
import { ChevronLeft, Building2, CheckCircle2, TrendingDown, Calculator, Star } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Slider } from "@/components/ui/slider";
import { Badge } from "@/components/ui/badge";
import { cn } from "@/lib/utils";

const BANKS = [
  { name: "SBI Home Loan", rate: 8.40, process: "7 days", max: "90%", badge: "Lowest Rate", logo: "🏦" },
  { name: "HDFC Bank", rate: 8.50, process: "5 days", max: "90%", badge: "Most Popular", logo: "🏦" },
  { name: "ICICI Bank", rate: 8.65, process: "4 days", max: "85%", badge: "Fastest", logo: "🏦" },
  { name: "Axis Bank", rate: 8.75, process: "6 days", max: "80%", badge: null, logo: "🏦" },
  { name: "Kotak Mahindra", rate: 8.85, process: "5 days", max: "80%", badge: null, logo: "🏦" },
];

function calcEMI(principal: number, annualRate: number, years: number) {
  if (!principal || !annualRate || !years) return 0;
  const r = annualRate / 12 / 100;
  const n = years * 12;
  return (principal * r * Math.pow(1 + r, n)) / (Math.pow(1 + r, n) - 1);
}

function fmt(n: number) {
  if (n >= 10000000) return `₹${(n / 10000000).toFixed(2)} Cr`;
  if (n >= 100000) return `₹${(n / 100000).toFixed(2)} L`;
  return `₹${Math.round(n).toLocaleString("en-IN")}`;
}

export default function HomeLoans() {
  const [loanAmount, setLoanAmount] = useState(5000000);
  const [tenure, setTenure] = useState(20);
  const [rate, setRate] = useState(8.50);
  const [eligForm, setEligForm] = useState({ income: "", age: "", employer: "", existing: "" });
  const [eligResult, setEligResult] = useState<number | null>(null);

  const emi = useMemo(() => calcEMI(loanAmount, rate, tenure), [loanAmount, rate, tenure]);
  const totalPayment = emi * tenure * 12;
  const totalInterest = totalPayment - loanAmount;

  function checkEligibility() {
    const income = parseInt(eligForm.income) || 0;
    const maxEMI = income * 0.5;
    const eligible = maxEMI * 12 * tenure / (1 + rate / 12 / 100);
    setEligResult(Math.min(eligible, 10000000));
  }

  return (
    <div className="min-h-screen">
      <div className="bg-primary text-white py-12 px-4">
        <div className="container mx-auto max-w-4xl">
          <Link href="/services" className="inline-flex items-center gap-1.5 text-white/70 hover:text-white text-sm mb-6">
            <ChevronLeft className="w-4 h-4" /> Back to Services
          </Link>
          <div className="flex items-center gap-3 mb-3">
            <div className="w-12 h-12 bg-orange-100 rounded-xl flex items-center justify-center">
              <Building2 className="w-6 h-6 text-orange-600" />
            </div>
            <div>
              <Badge className="bg-white/20 text-white border-white/30 text-xs mb-1">Save ₹2L+</Badge>
              <h1 className="text-2xl font-bold">Home Loans</h1>
            </div>
          </div>
          <p className="text-white/75 max-w-xl">Compare rates from 20+ banks. Calculate your EMI. Get the best deal with PropVeri's loan advisors.</p>
        </div>
      </div>

      <div className="container mx-auto max-w-4xl px-4 py-10 space-y-8">
        {/* EMI Calculator */}
        <div className="bg-white border rounded-2xl p-6 shadow-sm">
          <h2 className="text-xl font-bold mb-6 flex items-center gap-2"><Calculator className="w-5 h-5 text-primary" /> EMI Calculator</h2>
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
            <div className="space-y-6">
              <div>
                <div className="flex justify-between mb-2">
                  <label className="text-sm font-semibold">Loan Amount</label>
                  <span className="text-sm font-bold text-primary">{fmt(loanAmount)}</span>
                </div>
                <Slider min={500000} max={20000000} step={100000} value={[loanAmount]} onValueChange={v => setLoanAmount(v[0])} />
                <div className="flex justify-between text-xs text-muted-foreground mt-1"><span>₹5L</span><span>₹2Cr</span></div>
              </div>
              <div>
                <div className="flex justify-between mb-2">
                  <label className="text-sm font-semibold">Interest Rate (% p.a.)</label>
                  <span className="text-sm font-bold text-primary">{rate.toFixed(2)}%</span>
                </div>
                <Slider min={7.0} max={14.0} step={0.05} value={[rate]} onValueChange={v => setRate(v[0])} />
                <div className="flex justify-between text-xs text-muted-foreground mt-1"><span>7%</span><span>14%</span></div>
              </div>
              <div>
                <div className="flex justify-between mb-2">
                  <label className="text-sm font-semibold">Loan Tenure</label>
                  <span className="text-sm font-bold text-primary">{tenure} years</span>
                </div>
                <Slider min={1} max={30} step={1} value={[tenure]} onValueChange={v => setTenure(v[0])} />
                <div className="flex justify-between text-xs text-muted-foreground mt-1"><span>1 yr</span><span>30 yrs</span></div>
              </div>
            </div>

            <div className="bg-gradient-to-br from-primary/5 to-primary/10 rounded-xl p-5 flex flex-col justify-center">
              <p className="text-sm font-semibold text-muted-foreground mb-1 text-center">Monthly EMI</p>
              <p className="text-5xl font-bold text-primary text-center mb-5">{fmt(emi)}</p>
              <div className="space-y-2 text-sm">
                <div className="flex justify-between py-2 border-b border-primary/10">
                  <span className="text-muted-foreground">Principal Amount</span>
                  <span className="font-semibold">{fmt(loanAmount)}</span>
                </div>
                <div className="flex justify-between py-2 border-b border-primary/10">
                  <span className="text-muted-foreground">Total Interest</span>
                  <span className="font-semibold text-destructive">{fmt(totalInterest)}</span>
                </div>
                <div className="flex justify-between py-2 font-bold">
                  <span>Total Payment</span>
                  <span>{fmt(totalPayment)}</span>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Bank Comparison */}
        <div className="bg-white border rounded-2xl p-6 shadow-sm">
          <h2 className="text-xl font-bold mb-5">Compare Bank Rates</h2>
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="bg-muted/50 rounded-lg">
                  <th className="text-left py-3 px-4 font-semibold rounded-l-lg">Bank</th>
                  <th className="text-center py-3 px-4 font-semibold">Interest Rate</th>
                  <th className="text-center py-3 px-4 font-semibold">Your EMI</th>
                  <th className="text-center py-3 px-4 font-semibold">Processing</th>
                  <th className="text-center py-3 px-4 font-semibold">Max LTV</th>
                  <th className="text-center py-3 px-4 font-semibold rounded-r-lg">Action</th>
                </tr>
              </thead>
              <tbody>
                {BANKS.map((b, i) => {
                  const bankEMI = calcEMI(loanAmount, b.rate, tenure);
                  return (
                    <tr key={b.name} className={cn("border-b last:border-0", i === 0 && "bg-green-50")}>
                      <td className="py-3 px-4">
                        <div className="flex items-center gap-2">
                          <span className="text-xl">{b.logo}</span>
                          <div>
                            <p className="font-semibold">{b.name}</p>
                            {b.badge && <span className="text-[10px] text-primary font-bold">{b.badge}</span>}
                          </div>
                        </div>
                      </td>
                      <td className="text-center py-3 px-4">
                        <span className={cn("font-bold", i === 0 && "text-green-600")}>{b.rate.toFixed(2)}%</span>
                      </td>
                      <td className="text-center py-3 px-4 font-bold">{fmt(bankEMI)}</td>
                      <td className="text-center py-3 px-4 text-muted-foreground">{b.process}</td>
                      <td className="text-center py-3 px-4 text-muted-foreground">{b.max}</td>
                      <td className="text-center py-3 px-4">
                        <Button size="sm" variant={i === 0 ? "default" : "outline"}>Apply</Button>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>

        {/* Eligibility Checker */}
        <div className="bg-white border rounded-2xl p-6 shadow-sm">
          <h2 className="text-xl font-bold mb-5">Check Your Eligibility</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="space-y-4">
              <div>
                <label className="text-sm font-semibold mb-1 block">Monthly Income (₹) *</label>
                <Input type="number" placeholder="80000" value={eligForm.income} onChange={e => setEligForm(f => ({ ...f, income: e.target.value }))} />
              </div>
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="text-sm font-semibold mb-1 block">Age</label>
                  <Input type="number" placeholder="32" min={21} max={65} value={eligForm.age} onChange={e => setEligForm(f => ({ ...f, age: e.target.value }))} />
                </div>
                <div>
                  <label className="text-sm font-semibold mb-1 block">Employer Type</label>
                  <select className="w-full h-10 border border-border rounded-md px-3 text-sm" value={eligForm.employer} onChange={e => setEligForm(f => ({ ...f, employer: e.target.value }))}>
                    <option value="">Select</option>
                    <option>Salaried</option>
                    <option>Self-Employed</option>
                    <option>Business Owner</option>
                  </select>
                </div>
              </div>
              <div>
                <label className="text-sm font-semibold mb-1 block">Existing EMIs (₹/month)</label>
                <Input type="number" placeholder="0" value={eligForm.existing} onChange={e => setEligForm(f => ({ ...f, existing: e.target.value }))} />
              </div>
              <Button className="w-full" onClick={checkEligibility}>Check Eligibility</Button>
            </div>

            {eligResult !== null ? (
              <div className="bg-gradient-to-br from-green-50 to-emerald-50 border border-green-200 rounded-xl p-6 flex flex-col items-center justify-center text-center">
                <CheckCircle2 className="w-10 h-10 text-green-600 mb-3" />
                <p className="text-sm text-green-700 font-semibold mb-1">You are eligible for</p>
                <p className="text-4xl font-bold text-green-700 mb-2">{fmt(eligResult)}</p>
                <p className="text-xs text-muted-foreground mb-4">Based on your stated income. Actual approval subject to lender assessment.</p>
                <Button size="sm">Apply Now →</Button>
              </div>
            ) : (
              <div className="bg-muted/30 rounded-xl p-6 flex items-center justify-center">
                <div className="text-center text-muted-foreground">
                  <TrendingDown className="w-10 h-10 mx-auto mb-2 opacity-30" />
                  <p className="text-sm">Fill the form to see your maximum eligible loan amount</p>
                </div>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
