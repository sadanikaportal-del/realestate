import { useState } from "react";
import { Link } from "wouter";
import { ChevronLeft, HandshakeIcon, CheckCircle2, Star, Calendar, Phone, Clock, ChevronDown, ChevronUp } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { cn } from "@/lib/utils";

const SERVICES_LIST = [
  { id: "title", icon: "📜", label: "Title Search & Verification", desc: "Verify property ownership history for last 30 years. Identify encumbrances, disputes, or liens.", price: "₹5,000", time: "3–5 days" },
  { id: "sale_deed", icon: "✍️", label: "Sale Deed Drafting", desc: "Legally vetted sale deed drafted by a property lawyer. Review + revisions included.", price: "₹8,000", time: "2–3 days" },
  { id: "rera", icon: "🏗", label: "RERA Compliance Check", desc: "Verify if a project is RERA registered and check compliance status.", price: "₹3,000", time: "1–2 days" },
  { id: "noc", icon: "📋", label: "No Objection Certificate", desc: "Bank NOC for home loan closure. Society NOC for resale.", price: "₹4,500", time: "3–4 days" },
  { id: "will", icon: "📝", label: "Will & Estate Planning", desc: "Draft a legally valid will with property inheritance clauses.", price: "₹12,000", time: "5–7 days" },
  { id: "dispute", icon: "⚖️", label: "Dispute Resolution", desc: "Legal representation for property disputes, tenant eviction, builder delays.", price: "₹15,000+", time: "Varies" },
];

const LAWYERS = [
  { name: "Adv. Meera Krishnan", city: "Bangalore", exp: "12 yrs", rating: 4.9, reviews: 328, speciality: "Title Search, Sale Deed", available: "Today", img: "MK" },
  { name: "Adv. Rajesh Agarwal", city: "Mumbai", exp: "18 yrs", rating: 4.8, reviews: 512, speciality: "RERA, Dispute Resolution", available: "Tomorrow", img: "RA" },
  { name: "Adv. Sunita Rao", city: "Hyderabad", exp: "9 yrs", rating: 4.7, reviews: 215, speciality: "Estate Planning, NOC", available: "Today", img: "SR" },
];

const FAQS = [
  { q: "How do I verify if a property title is clear?", a: "Our lawyers conduct a 30-year title search on your behalf using the sub-registrar records. You'll receive a detailed report within 3–5 business days." },
  { q: "Is a sale deed the same as a sale agreement?", a: "No. A sale agreement is a promise to sell. A sale deed is the final registered document that transfers ownership. Both are legally important." },
  { q: "What is RERA and why does it matter?", a: "RERA (Real Estate Regulatory Authority) protects homebuyers from builder fraud. Always verify RERA registration before buying an under-construction property." },
  { q: "How much does a consultation cost?", a: "The first 15-minute consultation is free. Subsequent sessions and services are billed as per the service pricing shown above." },
];

export default function LegalServices() {
  const [selectedService, setSelectedService] = useState<string | null>(null);
  const [form, setForm] = useState({ name: "", phone: "", city: "", serviceNote: "", date: "" });
  const [submitted, setSubmitted] = useState(false);
  const [openFaq, setOpenFaq] = useState<number | null>(null);

  const valid = form.name && form.phone && selectedService;

  return (
    <div className="min-h-screen">
      <div className="bg-primary text-white py-12 px-4">
        <div className="container mx-auto max-w-4xl">
          <Link href="/services" className="inline-flex items-center gap-1.5 text-white/70 hover:text-white text-sm mb-6">
            <ChevronLeft className="w-4 h-4" /> Back to Services
          </Link>
          <div className="flex items-center gap-3 mb-3">
            <div className="w-12 h-12 bg-purple-100 rounded-xl flex items-center justify-center">
              <HandshakeIcon className="w-6 h-6 text-purple-600" />
            </div>
            <h1 className="text-2xl font-bold">Legal Services</h1>
          </div>
          <p className="text-white/75 max-w-xl">Expert property lawyers for title verification, sale deed, RERA compliance, and dispute resolution.</p>
          <p className="mt-3 text-yellow-300 text-sm font-semibold">✦ First consultation FREE (15 minutes)</p>
        </div>
      </div>

      <div className="container mx-auto max-w-4xl px-4 py-10 space-y-10">
        {submitted ? (
          <div className="text-center py-10">
            <CheckCircle2 className="w-16 h-16 text-green-600 mx-auto mb-4" />
            <h2 className="text-2xl font-bold mb-2">Consultation Booked!</h2>
            <p className="text-muted-foreground mb-1">A PropVeri lawyer will call <strong>{form.phone}</strong> within 2 hours.</p>
            <p className="text-muted-foreground text-sm mb-6">Service: {SERVICES_LIST.find(s => s.id === selectedService)?.label}</p>
            <Button variant="outline" onClick={() => { setSubmitted(false); setForm({ name: "", phone: "", city: "", serviceNote: "", date: "" }); setSelectedService(null); }}>
              Book Another
            </Button>
          </div>
        ) : (
          <>
            {/* Services grid */}
            <div>
              <h2 className="text-xl font-bold mb-5">Select a Service</h2>
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                {SERVICES_LIST.map(s => (
                  <button key={s.id} onClick={() => setSelectedService(s.id === selectedService ? null : s.id)}
                    className={cn("border-2 rounded-xl p-4 text-left transition-all hover:shadow-md",
                      selectedService === s.id ? "border-primary bg-primary/5 shadow-sm" : "border-border bg-white hover:border-primary/40")}>
                    <div className="text-2xl mb-2">{s.icon}</div>
                    <h3 className="font-semibold text-sm mb-1">{s.label}</h3>
                    <p className="text-xs text-muted-foreground mb-3 leading-relaxed">{s.desc}</p>
                    <div className="flex items-center justify-between">
                      <span className="text-sm font-bold text-primary">{s.price}</span>
                      <span className="text-xs text-muted-foreground flex items-center gap-1"><Clock className="w-3 h-3" />{s.time}</span>
                    </div>
                  </button>
                ))}
              </div>
            </div>

            {/* Lawyer profiles */}
            <div>
              <h2 className="text-xl font-bold mb-5">Our Lawyers</h2>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                {LAWYERS.map(l => (
                  <div key={l.name} className="bg-white border rounded-xl p-4 hover:shadow-md transition-shadow">
                    <div className="flex items-start gap-3 mb-3">
                      <div className="w-10 h-10 rounded-full bg-primary text-white flex items-center justify-center text-sm font-bold shrink-0">{l.img}</div>
                      <div>
                        <p className="font-bold text-sm">{l.name}</p>
                        <p className="text-xs text-muted-foreground">{l.city} · {l.exp} exp</p>
                      </div>
                    </div>
                    <div className="flex items-center gap-2 text-xs text-muted-foreground mb-2">
                      <Star className="w-3.5 h-3.5 text-yellow-400 fill-yellow-400" /> {l.rating} ({l.reviews} reviews)
                    </div>
                    <p className="text-xs text-muted-foreground mb-3">{l.speciality}</p>
                    <Badge className={cn("text-xs", l.available === "Today" ? "bg-green-100 text-green-700 border-green-200" : "bg-amber-100 text-amber-700 border-amber-200")}>
                      Available: {l.available}
                    </Badge>
                  </div>
                ))}
              </div>
            </div>

            {/* Booking form */}
            <div className="bg-white border rounded-2xl p-6 shadow-sm">
              <h2 className="text-xl font-bold mb-5">Book a Consultation</h2>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <label className="text-sm font-semibold mb-1.5 block">Your Name *</label>
                  <Input placeholder="Vikram Singh" value={form.name} onChange={e => setForm(f => ({ ...f, name: e.target.value }))} />
                </div>
                <div>
                  <label className="text-sm font-semibold mb-1.5 block">Phone *</label>
                  <div className="relative">
                    <Phone className="absolute left-3 top-3 w-4 h-4 text-muted-foreground" />
                    <Input className="pl-9" placeholder="+91 98765 43210" value={form.phone} onChange={e => setForm(f => ({ ...f, phone: e.target.value }))} />
                  </div>
                </div>
                <div>
                  <label className="text-sm font-semibold mb-1.5 block">City</label>
                  <Input placeholder="Bangalore" value={form.city} onChange={e => setForm(f => ({ ...f, city: e.target.value }))} />
                </div>
                <div>
                  <label className="text-sm font-semibold mb-1.5 block">Preferred Date</label>
                  <div className="relative">
                    <Calendar className="absolute left-3 top-3 w-4 h-4 text-muted-foreground" />
                    <Input type="date" className="pl-9" value={form.date} onChange={e => setForm(f => ({ ...f, date: e.target.value }))} />
                  </div>
                </div>
                <div className="md:col-span-2">
                  <label className="text-sm font-semibold mb-1.5 block">Describe Your Query (optional)</label>
                  <textarea className="w-full border border-border rounded-md p-3 text-sm h-20 resize-none focus:outline-none focus:ring-2 focus:ring-primary/30"
                    placeholder="e.g. I want to buy a resale flat and need title verification..." value={form.serviceNote} onChange={e => setForm(f => ({ ...f, serviceNote: e.target.value }))} />
                </div>
              </div>
              {!selectedService && <p className="text-sm text-amber-600 mt-3">← Please select a service above</p>}
              <Button className="w-full h-12 text-base mt-4" disabled={!valid} onClick={() => setSubmitted(true)}>
                Book Free Consultation →
              </Button>
            </div>

            {/* FAQs */}
            <div>
              <h2 className="text-xl font-bold mb-5">Frequently Asked Questions</h2>
              <div className="space-y-2">
                {FAQS.map((faq, i) => (
                  <div key={i} className="bg-white border rounded-xl overflow-hidden">
                    <button onClick={() => setOpenFaq(openFaq === i ? null : i)} className="w-full flex items-center justify-between p-4 text-left">
                      <span className="font-semibold text-sm">{faq.q}</span>
                      {openFaq === i ? <ChevronUp className="w-4 h-4 text-muted-foreground shrink-0" /> : <ChevronDown className="w-4 h-4 text-muted-foreground shrink-0" />}
                    </button>
                    {openFaq === i && <div className="px-4 pb-4 text-sm text-muted-foreground leading-relaxed">{faq.a}</div>}
                  </div>
                ))}
              </div>
            </div>
          </>
        )}
      </div>
    </div>
  );
}
