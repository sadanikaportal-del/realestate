import { useState } from "react";
import { Link } from "wouter";
import { ChevronLeft, Wrench, CheckCircle2, Clock, Star, Phone, Calendar, MapPin } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { cn } from "@/lib/utils";

const CATEGORIES = [
  { id: "plumbing", icon: "🚿", label: "Plumbing", desc: "Leaks, taps, pipes, drainage", price: "₹299 onwards" },
  { id: "electrical", icon: "⚡", label: "Electrical", desc: "Wiring, switches, fan, MCB", price: "₹349 onwards" },
  { id: "carpentry", icon: "🪚", label: "Carpentry", desc: "Doors, windows, furniture fix", price: "₹399 onwards" },
  { id: "ac", icon: "❄️", label: "AC Service", desc: "Cleaning, gas refill, repair", price: "₹599 onwards" },
  { id: "painting", icon: "🎨", label: "Painting", desc: "Wall painting, touch-ups", price: "₹8/sqft" },
  { id: "cleaning", icon: "🧹", label: "Deep Cleaning", desc: "Full home deep clean", price: "₹1,499 onwards" },
  { id: "pest", icon: "🐛", label: "Pest Control", desc: "Cockroach, termite, rodent", price: "₹999 onwards" },
  { id: "appliance", icon: "🔧", label: "Appliance Repair", desc: "Washing machine, fridge, etc.", price: "₹349 onwards" },
];

const TIME_SLOTS = ["9:00 AM", "11:00 AM", "1:00 PM", "3:00 PM", "5:00 PM", "7:00 PM"];

export default function HomeRepairs() {
  const [selected, setSelected] = useState<string[]>([]);
  const [date, setDate] = useState("");
  const [slot, setSlot] = useState("");
  const [address, setAddress] = useState("");
  const [issue, setIssue] = useState("");
  const [phone, setPhone] = useState("");
  const [submitted, setSubmitted] = useState(false);

  function toggle(id: string) {
    setSelected(s => s.includes(id) ? s.filter(x => x !== id) : [...s, id]);
  }

  const bookingId = `PV-REP-${Math.floor(Math.random() * 90000 + 10000)}`;
  const valid = selected.length > 0 && date && slot && address && phone;

  return (
    <div className="min-h-screen">
      <div className="bg-primary text-white py-12 px-4">
        <div className="container mx-auto max-w-3xl">
          <Link href="/services" className="inline-flex items-center gap-1.5 text-white/70 hover:text-white text-sm mb-6">
            <ChevronLeft className="w-4 h-4" /> Back to Services
          </Link>
          <div className="flex items-center gap-3 mb-3">
            <div className="w-12 h-12 bg-teal-100 rounded-xl flex items-center justify-center">
              <Wrench className="w-6 h-6 text-teal-600" />
            </div>
            <div>
              <Badge className="bg-white/20 text-white border-white/30 text-xs mb-1">On Demand</Badge>
              <h1 className="text-2xl font-bold">Home Repairs</h1>
            </div>
          </div>
          <p className="text-white/75 max-w-xl">Verified professionals for all home repairs. Same-day service available. Fixed transparent pricing.</p>
          <div className="flex gap-5 mt-4 text-sm text-white/80">
            {["Same-day", "Fixed Rates", "Warranty on Work", "Background Verified"].map(f => (
              <span key={f} className="flex items-center gap-1"><CheckCircle2 className="w-3.5 h-3.5 text-green-400" /> {f}</span>
            ))}
          </div>
        </div>
      </div>

      <div className="container mx-auto max-w-3xl px-4 py-10">
        {submitted ? (
          <div className="text-center">
            <div className="w-20 h-20 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-4">
              <CheckCircle2 className="w-10 h-10 text-green-600" />
            </div>
            <h2 className="text-2xl font-bold mb-2">Booking Confirmed!</h2>
            <p className="text-muted-foreground mb-2">Booking ID: <strong>{bookingId}</strong></p>
            <p className="text-muted-foreground mb-6">Your technician will arrive on <strong>{date}</strong> at <strong>{slot}</strong></p>

            <div className="bg-white border rounded-xl p-5 text-left max-w-sm mx-auto mb-6 space-y-3">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-full bg-primary text-white flex items-center justify-center text-sm font-bold">SR</div>
                <div>
                  <p className="font-bold">Suresh Rajan</p>
                  <div className="flex items-center gap-1 text-xs text-muted-foreground">
                    <Star className="w-3 h-3 text-yellow-400 fill-yellow-400" /> 4.9 · 847 jobs
                  </div>
                </div>
              </div>
              <div className="text-sm space-y-1 text-muted-foreground">
                <p><Clock className="w-3.5 h-3.5 inline mr-1.5" />{date} · {slot}</p>
                <p><MapPin className="w-3.5 h-3.5 inline mr-1.5" />{address}</p>
                <p><Phone className="w-3.5 h-3.5 inline mr-1.5" />Will call 30 min before arrival</p>
              </div>
              <div className="flex gap-2 pt-2">
                {selected.map(id => {
                  const cat = CATEGORIES.find(c => c.id === id)!;
                  return <span key={id} className="text-xs bg-muted px-2 py-1 rounded-full">{cat.icon} {cat.label}</span>;
                })}
              </div>
            </div>

            <div className="flex gap-3 justify-center">
              <Button variant="outline" onClick={() => { setSubmitted(false); setSelected([]); setDate(""); setSlot(""); setAddress(""); setIssue(""); setPhone(""); }}>
                Book Another
              </Button>
              <Button>Track Technician</Button>
            </div>
          </div>
        ) : (
          <div className="space-y-6">
            {/* Service selection */}
            <div className="bg-white border rounded-2xl p-5 shadow-sm">
              <h2 className="font-bold text-lg mb-4">Select Service(s) <span className="text-destructive">*</span></h2>
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
                {CATEGORIES.map(cat => (
                  <button key={cat.id} onClick={() => toggle(cat.id)}
                    className={cn("border-2 rounded-xl p-3 text-left transition-all",
                      selected.includes(cat.id) ? "border-primary bg-primary/5" : "border-border hover:border-primary/40")}>
                    <div className="text-2xl mb-1.5">{cat.icon}</div>
                    <p className="font-semibold text-xs">{cat.label}</p>
                    <p className="text-[10px] text-muted-foreground mt-0.5">{cat.price}</p>
                  </button>
                ))}
              </div>
              {selected.length > 0 && (
                <p className="text-sm text-primary font-medium mt-3">
                  ✓ {selected.length} service{selected.length > 1 ? "s" : ""} selected
                </p>
              )}
            </div>

            {/* Date & Time */}
            <div className="bg-white border rounded-2xl p-5 shadow-sm">
              <h2 className="font-bold text-lg mb-4">Schedule <span className="text-destructive">*</span></h2>
              <div className="mb-4">
                <label className="text-sm font-semibold mb-1.5 block">Date</label>
                <div className="relative">
                  <Calendar className="absolute left-3 top-3 w-4 h-4 text-muted-foreground" />
                  <Input type="date" className="pl-9" value={date} onChange={e => setDate(e.target.value)} min={new Date().toISOString().split("T")[0]} />
                </div>
              </div>
              <div>
                <label className="text-sm font-semibold mb-2 block">Time Slot</label>
                <div className="grid grid-cols-3 sm:grid-cols-6 gap-2">
                  {TIME_SLOTS.map(t => (
                    <button key={t} onClick={() => setSlot(t)}
                      className={cn("py-2 rounded-lg border text-xs font-medium transition-colors",
                        slot === t ? "bg-primary text-white border-primary" : "border-border hover:border-primary")}>
                      {t}
                    </button>
                  ))}
                </div>
              </div>
            </div>

            {/* Location & Contact */}
            <div className="bg-white border rounded-2xl p-5 shadow-sm">
              <h2 className="font-bold text-lg mb-4">Location & Contact</h2>
              <div className="space-y-4">
                <div>
                  <label className="text-sm font-semibold mb-1.5 block">Full Address <span className="text-destructive">*</span></label>
                  <div className="relative">
                    <MapPin className="absolute left-3 top-3 w-4 h-4 text-muted-foreground" />
                    <Input className="pl-9" placeholder="Flat 202, Lotus Apts, Koramangala, Bangalore" value={address} onChange={e => setAddress(e.target.value)} />
                  </div>
                </div>
                <div>
                  <label className="text-sm font-semibold mb-1.5 block">Describe the Issue (optional)</label>
                  <textarea
                    className="w-full border border-border rounded-md p-3 text-sm h-20 resize-none focus:outline-none focus:ring-2 focus:ring-primary/30"
                    placeholder="e.g. Tap in kitchen is leaking since 2 days..."
                    value={issue}
                    onChange={e => setIssue(e.target.value)}
                  />
                </div>
                <div>
                  <label className="text-sm font-semibold mb-1.5 block">Phone Number <span className="text-destructive">*</span></label>
                  <div className="relative">
                    <Phone className="absolute left-3 top-3 w-4 h-4 text-muted-foreground" />
                    <Input className="pl-9" placeholder="+91 98765 43210" value={phone} onChange={e => setPhone(e.target.value)} />
                  </div>
                </div>
              </div>
            </div>

            <Button className="w-full h-12 text-base" disabled={!valid} onClick={() => setSubmitted(true)}>
              Book Service →
            </Button>
          </div>
        )}
      </div>
    </div>
  );
}
