import { useState } from "react";
import { Link } from "wouter";
import { ChevronLeft, FileText, CheckCircle2, Download, Printer, Share2, Calendar, IndianRupee } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { cn } from "@/lib/utils";

export default function RentalAgreement() {
  const [form, setForm] = useState({
    ownerName: "", ownerPhone: "", ownerAadhaar: "",
    tenantName: "", tenantPhone: "", tenantAadhaar: "",
    property: "", city: "",
    rent: "", deposit: "", duration: "11", startDate: "",
  });
  const [submitted, setSubmitted] = useState(false);
  const [agree, setAgree] = useState(false);

  function update(k: string, v: string) { setForm(f => ({ ...f, [k]: v })); }

  const isValid = form.ownerName && form.tenantName && form.property && form.rent && form.startDate && agree;

  const today = new Date().toLocaleDateString("en-IN", { day: "numeric", month: "long", year: "numeric" });

  return (
    <div className="min-h-screen">
      <div className="bg-primary text-white py-12 px-4">
        <div className="container mx-auto max-w-4xl">
          <Link href="/services" className="inline-flex items-center gap-1.5 text-white/70 hover:text-white text-sm mb-6">
            <ChevronLeft className="w-4 h-4" /> Back to Services
          </Link>
          <div className="flex items-center gap-3 mb-3">
            <div className="w-12 h-12 bg-green-100 rounded-xl flex items-center justify-center">
              <FileText className="w-6 h-6 text-green-600" />
            </div>
            <div>
              <Badge className="bg-white/20 text-white border-white/30 text-xs mb-1">Digital</Badge>
              <h1 className="text-2xl font-bold">Rental Agreement</h1>
            </div>
          </div>
          <p className="text-white/75 max-w-xl">Legally valid, e-stamped rental agreements ready in minutes. Delivered digitally and to your doorstep.</p>
        </div>
      </div>

      <div className="container mx-auto max-w-4xl px-4 py-10">
        {submitted ? (
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
            {/* Agreement Preview */}
            <div className="bg-white border-2 border-primary/20 rounded-2xl p-6 shadow-md font-mono text-sm leading-relaxed">
              <div className="text-center border-b pb-4 mb-4">
                <p className="text-xs text-muted-foreground uppercase tracking-wider mb-1">Rental Agreement</p>
                <h3 className="text-base font-bold">RESIDENTIAL TENANCY AGREEMENT</h3>
                <p className="text-xs text-muted-foreground mt-1">Generated on {today}</p>
              </div>
              <div className="space-y-3 text-xs leading-relaxed text-gray-700">
                <p>This agreement is entered into on <strong>{form.startDate || "[date]"}</strong> between:</p>
                <p><strong>LANDLORD:</strong> {form.ownerName || "[Owner Name]"} (Aadhaar: {form.ownerAadhaar || "XXXX-XXXX-XXXX"})</p>
                <p><strong>TENANT:</strong> {form.tenantName || "[Tenant Name]"} (Aadhaar: {form.tenantAadhaar || "XXXX-XXXX-XXXX"})</p>
                <p><strong>PROPERTY:</strong> {form.property || "[Property Address]"}, {form.city || "[City]"}</p>
                <div className="border-t border-b py-3 my-3 space-y-1">
                  <p><strong>Monthly Rent:</strong> ₹{form.rent ? parseInt(form.rent).toLocaleString("en-IN") : "—"}</p>
                  <p><strong>Security Deposit:</strong> ₹{form.deposit ? parseInt(form.deposit).toLocaleString("en-IN") : form.rent ? (parseInt(form.rent) * 2).toLocaleString("en-IN") : "—"}</p>
                  <p><strong>Tenancy Period:</strong> {form.duration} months</p>
                  <p><strong>Commencement:</strong> {form.startDate || "—"}</p>
                </div>
                <p className="text-[10px] text-muted-foreground">
                  This agreement is subject to the provisions of the Rent Control Act applicable in the state. Any disputes shall be settled under Indian law through arbitration or the appropriate court having jurisdiction.
                </p>
                <div className="flex justify-between mt-6 pt-4 border-t text-xs">
                  <div className="text-center">
                    <div className="h-8 border-b border-dashed border-gray-400 mb-1 w-24" />
                    <p>Landlord Signature</p>
                  </div>
                  <div className="text-center">
                    <div className="h-8 border-b border-dashed border-gray-400 mb-1 w-24" />
                    <p>Tenant Signature</p>
                  </div>
                </div>
              </div>
            </div>

            {/* Actions */}
            <div className="space-y-4">
              <div className="bg-green-50 border border-green-200 rounded-xl p-5">
                <div className="flex items-center gap-3 mb-3">
                  <CheckCircle2 className="w-8 h-8 text-green-600" />
                  <div>
                    <h3 className="font-bold text-green-800">Agreement Generated!</h3>
                    <p className="text-sm text-green-700">Reference ID: PV-AGR-{Math.floor(Math.random() * 90000 + 10000)}</p>
                  </div>
                </div>
                <p className="text-sm text-green-700">Your rental agreement is ready. Our team will contact you within 2 hours for e-stamp verification and delivery.</p>
              </div>

              <div className="bg-white border rounded-xl p-5 space-y-3">
                <h3 className="font-semibold">Next Steps</h3>
                {[
                  { step: 1, text: "PropVeri team verifies details (2 hrs)", done: true },
                  { step: 2, text: "e-Stamp paper applied (₹100 govt fee)", done: false },
                  { step: 3, text: "Digital copy sent to both parties", done: false },
                  { step: 4, text: "Physical copy delivered (24–48 hrs)", done: false },
                ].map(s => (
                  <div key={s.step} className="flex items-start gap-3">
                    <div className={cn("w-6 h-6 rounded-full flex items-center justify-center text-xs font-bold shrink-0 mt-0.5",
                      s.done ? "bg-green-500 text-white" : "bg-muted text-muted-foreground")}>
                      {s.done ? "✓" : s.step}
                    </div>
                    <p className="text-sm text-muted-foreground">{s.text}</p>
                  </div>
                ))}
              </div>

              <div className="flex gap-3">
                <Button className="flex-1 gap-2"><Download className="w-4 h-4" /> Download PDF</Button>
                <Button variant="outline" className="gap-2"><Share2 className="w-4 h-4" /> Share</Button>
              </div>
              <Button variant="outline" className="w-full" onClick={() => { setSubmitted(false); setForm({ ownerName: "", ownerPhone: "", ownerAadhaar: "", tenantName: "", tenantPhone: "", tenantAadhaar: "", property: "", city: "", rent: "", deposit: "", duration: "11", startDate: "" }); setAgree(false); }}>
                Create New Agreement
              </Button>
            </div>
          </div>
        ) : (
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
            <div className="space-y-6">
              {/* Owner Details */}
              <div className="bg-white border rounded-xl p-5">
                <h3 className="font-bold mb-4 flex items-center gap-2"><span className="w-6 h-6 bg-primary text-white rounded-full text-xs flex items-center justify-center font-bold">1</span> Owner / Landlord Details</h3>
                <div className="space-y-3">
                  <div>
                    <label className="text-xs font-semibold text-muted-foreground uppercase tracking-wider mb-1 block">Full Name *</label>
                    <Input placeholder="Suresh Patel" value={form.ownerName} onChange={e => update("ownerName", e.target.value)} />
                  </div>
                  <div className="grid grid-cols-2 gap-3">
                    <div>
                      <label className="text-xs font-semibold text-muted-foreground uppercase tracking-wider mb-1 block">Phone</label>
                      <Input placeholder="+91 98765..." value={form.ownerPhone} onChange={e => update("ownerPhone", e.target.value)} />
                    </div>
                    <div>
                      <label className="text-xs font-semibold text-muted-foreground uppercase tracking-wider mb-1 block">Aadhaar (last 4)</label>
                      <Input placeholder="XXXX" maxLength={4} value={form.ownerAadhaar} onChange={e => update("ownerAadhaar", e.target.value)} />
                    </div>
                  </div>
                </div>
              </div>

              {/* Tenant Details */}
              <div className="bg-white border rounded-xl p-5">
                <h3 className="font-bold mb-4 flex items-center gap-2"><span className="w-6 h-6 bg-primary text-white rounded-full text-xs flex items-center justify-center font-bold">2</span> Tenant Details</h3>
                <div className="space-y-3">
                  <div>
                    <label className="text-xs font-semibold text-muted-foreground uppercase tracking-wider mb-1 block">Full Name *</label>
                    <Input placeholder="Priya Sharma" value={form.tenantName} onChange={e => update("tenantName", e.target.value)} />
                  </div>
                  <div className="grid grid-cols-2 gap-3">
                    <div>
                      <label className="text-xs font-semibold text-muted-foreground uppercase tracking-wider mb-1 block">Phone</label>
                      <Input placeholder="+91 98765..." value={form.tenantPhone} onChange={e => update("tenantPhone", e.target.value)} />
                    </div>
                    <div>
                      <label className="text-xs font-semibold text-muted-foreground uppercase tracking-wider mb-1 block">Aadhaar (last 4)</label>
                      <Input placeholder="XXXX" maxLength={4} value={form.tenantAadhaar} onChange={e => update("tenantAadhaar", e.target.value)} />
                    </div>
                  </div>
                </div>
              </div>
            </div>

            <div className="space-y-6">
              {/* Property Details */}
              <div className="bg-white border rounded-xl p-5">
                <h3 className="font-bold mb-4 flex items-center gap-2"><span className="w-6 h-6 bg-primary text-white rounded-full text-xs flex items-center justify-center font-bold">3</span> Property & Terms</h3>
                <div className="space-y-3">
                  <div>
                    <label className="text-xs font-semibold text-muted-foreground uppercase tracking-wider mb-1 block">Property Address *</label>
                    <Input placeholder="Flat 402, Sunshine Apts, MG Road" value={form.property} onChange={e => update("property", e.target.value)} />
                  </div>
                  <div>
                    <label className="text-xs font-semibold text-muted-foreground uppercase tracking-wider mb-1 block">City</label>
                    <Input placeholder="Bangalore" value={form.city} onChange={e => update("city", e.target.value)} />
                  </div>
                  <div className="grid grid-cols-2 gap-3">
                    <div>
                      <label className="text-xs font-semibold text-muted-foreground uppercase tracking-wider mb-1 block">Monthly Rent (₹) *</label>
                      <Input type="number" placeholder="25000" value={form.rent} onChange={e => update("rent", e.target.value)} />
                    </div>
                    <div>
                      <label className="text-xs font-semibold text-muted-foreground uppercase tracking-wider mb-1 block">Security Deposit (₹)</label>
                      <Input type="number" placeholder="50000" value={form.deposit} onChange={e => update("deposit", e.target.value)} />
                    </div>
                  </div>
                  <div className="grid grid-cols-2 gap-3">
                    <div>
                      <label className="text-xs font-semibold text-muted-foreground uppercase tracking-wider mb-1 block">Duration</label>
                      <select className="w-full h-10 border border-border rounded-md px-3 text-sm" value={form.duration} onChange={e => update("duration", e.target.value)}>
                        {["6", "11", "12", "24", "36"].map(d => <option key={d} value={d}>{d} months</option>)}
                      </select>
                    </div>
                    <div>
                      <label className="text-xs font-semibold text-muted-foreground uppercase tracking-wider mb-1 block">Start Date *</label>
                      <Input type="date" value={form.startDate} onChange={e => update("startDate", e.target.value)} />
                    </div>
                  </div>
                </div>
              </div>

              <div className="bg-white border rounded-xl p-5">
                <label className="flex items-start gap-3 cursor-pointer">
                  <input type="checkbox" checked={agree} onChange={e => setAgree(e.target.checked)} className="mt-1" />
                  <span className="text-sm text-muted-foreground">I confirm the details above are correct. I agree to PropVeri's <a href="#" className="text-primary underline">Terms of Service</a> for rental agreements.</span>
                </label>
              </div>

              <Button className="w-full h-12 text-base" disabled={!isValid} onClick={() => setSubmitted(true)}>
                <FileText className="w-4 h-4 mr-2" /> Generate Agreement →
              </Button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
