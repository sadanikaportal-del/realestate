import { useState } from "react";
import { Link } from "wouter";
import { ChevronLeft, BadgeCheck, CheckCircle2, Search, Clock, AlertTriangle, Shield, User, Phone, Briefcase } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { cn } from "@/lib/utils";

const MOCK_STATUS = [
  { id: "PV-VER-84712", status: "completed", name: "Priya Sharma", date: "20 May 2026", score: 92, checks: [
    { label: "Police Verification", status: "clear" },
    { label: "Credit Score Check", status: "clear" },
    { label: "Employment Verified", status: "clear" },
    { label: "Previous Address", status: "clear" },
    { label: "Reference Check", status: "clear" },
  ]},
  { id: "PV-VER-33201", status: "in_progress", name: "Rahul Mehta", date: "22 May 2026", score: null, checks: [
    { label: "Police Verification", status: "clear" },
    { label: "Credit Score Check", status: "clear" },
    { label: "Employment Verified", status: "pending" },
    { label: "Previous Address", status: "pending" },
    { label: "Reference Check", status: "pending" },
  ]},
];

export default function TenantVerification() {
  const [tab, setTab] = useState<"submit" | "track">("submit");
  const [form, setForm] = useState({ tenantName: "", phone: "", aadhaar: "", pan: "", employer: "", empType: "", prevAddress: "", ownerName: "", ownerPhone: "" });
  const [submitted, setSubmitted] = useState(false);
  const [trackId, setTrackId] = useState("");
  const [trackResult, setTrackResult] = useState<typeof MOCK_STATUS[0] | null>(null);
  const [trackError, setTrackError] = useState(false);
  const verificationId = `PV-VER-${Math.floor(Math.random() * 90000 + 10000)}`;

  function update(k: string, v: string) { setForm(f => ({ ...f, [k]: v })); }

  function doTrack() {
    const found = MOCK_STATUS.find(s => s.id === trackId.trim().toUpperCase());
    if (found) { setTrackResult(found); setTrackError(false); }
    else { setTrackResult(null); setTrackError(true); }
  }

  const valid = form.tenantName && form.phone && form.aadhaar && form.ownerPhone;

  return (
    <div className="min-h-screen">
      <div className="bg-primary text-white py-12 px-4">
        <div className="container mx-auto max-w-3xl">
          <Link href="/services" className="inline-flex items-center gap-1.5 text-white/70 hover:text-white text-sm mb-6">
            <ChevronLeft className="w-4 h-4" /> Back to Services
          </Link>
          <div className="flex items-center gap-3 mb-3">
            <div className="w-12 h-12 bg-indigo-100 rounded-xl flex items-center justify-center">
              <BadgeCheck className="w-6 h-6 text-indigo-600" />
            </div>
            <h1 className="text-2xl font-bold">Tenant Verification</h1>
          </div>
          <p className="text-white/75 max-w-xl">Comprehensive background check — police clearance, credit score, employment, and reference verification.</p>
        </div>
      </div>

      <div className="container mx-auto max-w-3xl px-4 py-10">
        {/* Tabs */}
        <div className="flex bg-muted rounded-xl p-1 mb-8 max-w-xs">
          {[{ id: "submit", label: "Submit Request" }, { id: "track", label: "Track Status" }].map(t => (
            <button key={t.id} onClick={() => { setTab(t.id as any); setSubmitted(false); }}
              className={cn("flex-1 py-2 rounded-lg text-sm font-semibold transition-colors",
                tab === t.id ? "bg-white shadow text-foreground" : "text-muted-foreground hover:text-foreground")}>
              {t.label}
            </button>
          ))}
        </div>

        {tab === "submit" ? (
          submitted ? (
            <div className="text-center">
              <div className="w-20 h-20 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <CheckCircle2 className="w-10 h-10 text-green-600" />
              </div>
              <h2 className="text-2xl font-bold mb-2">Request Submitted!</h2>
              <p className="text-muted-foreground mb-1">Verification ID: <strong className="text-primary">{verificationId}</strong></p>
              <p className="text-muted-foreground mb-6 text-sm">Save this ID to track your verification status. Results in 48–72 hours.</p>
              <div className="bg-white border rounded-xl p-5 text-left max-w-sm mx-auto mb-6 space-y-3">
                <h3 className="font-bold">Verification Checklist</h3>
                {[
                  { label: "Police Verification", time: "24 hrs" },
                  { label: "Credit Score Check", time: "2 hrs" },
                  { label: "Employment Verified", time: "12 hrs" },
                  { label: "Previous Address", time: "24 hrs" },
                  { label: "Reference Check", time: "12 hrs" },
                ].map(c => (
                  <div key={c.label} className="flex items-center justify-between text-sm">
                    <span className="flex items-center gap-2 text-muted-foreground"><Clock className="w-3.5 h-3.5" /> {c.label}</span>
                    <span className="text-xs bg-amber-100 text-amber-700 px-2 py-0.5 rounded-full">{c.time}</span>
                  </div>
                ))}
              </div>
              <div className="flex gap-3 justify-center">
                <Button variant="outline" onClick={() => { setSubmitted(false); setForm({ tenantName: "", phone: "", aadhaar: "", pan: "", employer: "", empType: "", prevAddress: "", ownerName: "", ownerPhone: "" }); }}>
                  Submit Another
                </Button>
                <Button onClick={() => { setTab("track"); setTrackId(verificationId); }}>Track Status</Button>
              </div>
            </div>
          ) : (
            <div className="space-y-5">
              <div className="bg-white border rounded-2xl p-5 shadow-sm">
                <h3 className="font-bold mb-4 flex items-center gap-2"><User className="w-4 h-4 text-primary" /> Tenant Information</h3>
                <div className="space-y-3">
                  <div className="grid grid-cols-2 gap-3">
                    <div>
                      <label className="text-xs font-semibold text-muted-foreground block mb-1">Full Name *</label>
                      <Input placeholder="Priya Sharma" value={form.tenantName} onChange={e => update("tenantName", e.target.value)} />
                    </div>
                    <div>
                      <label className="text-xs font-semibold text-muted-foreground block mb-1">Phone *</label>
                      <Input placeholder="+91 98765..." value={form.phone} onChange={e => update("phone", e.target.value)} />
                    </div>
                  </div>
                  <div className="grid grid-cols-2 gap-3">
                    <div>
                      <label className="text-xs font-semibold text-muted-foreground block mb-1">Aadhaar Number *</label>
                      <Input placeholder="XXXX XXXX XXXX" maxLength={12} value={form.aadhaar} onChange={e => update("aadhaar", e.target.value)} />
                    </div>
                    <div>
                      <label className="text-xs font-semibold text-muted-foreground block mb-1">PAN Number</label>
                      <Input placeholder="ABCDE1234F" maxLength={10} value={form.pan} onChange={e => update("pan", e.target.value.toUpperCase())} />
                    </div>
                  </div>
                </div>
              </div>

              <div className="bg-white border rounded-2xl p-5 shadow-sm">
                <h3 className="font-bold mb-4 flex items-center gap-2"><Briefcase className="w-4 h-4 text-primary" /> Employment Details</h3>
                <div className="space-y-3">
                  <div className="grid grid-cols-2 gap-3">
                    <div>
                      <label className="text-xs font-semibold text-muted-foreground block mb-1">Employer / Company</label>
                      <Input placeholder="Infosys Ltd." value={form.employer} onChange={e => update("employer", e.target.value)} />
                    </div>
                    <div>
                      <label className="text-xs font-semibold text-muted-foreground block mb-1">Employment Type</label>
                      <select className="w-full h-10 border border-border rounded-md px-3 text-sm" value={form.empType} onChange={e => update("empType", e.target.value)}>
                        <option value="">Select</option>
                        <option>Salaried</option>
                        <option>Self-Employed</option>
                        <option>Student</option>
                        <option>Retired</option>
                      </select>
                    </div>
                  </div>
                  <div>
                    <label className="text-xs font-semibold text-muted-foreground block mb-1">Previous Address</label>
                    <Input placeholder="Previous city / locality" value={form.prevAddress} onChange={e => update("prevAddress", e.target.value)} />
                  </div>
                </div>
              </div>

              <div className="bg-white border rounded-2xl p-5 shadow-sm">
                <h3 className="font-bold mb-4 flex items-center gap-2"><Phone className="w-4 h-4 text-primary" /> Owner Details (for report delivery)</h3>
                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className="text-xs font-semibold text-muted-foreground block mb-1">Owner Name</label>
                    <Input placeholder="Suresh Patel" value={form.ownerName} onChange={e => update("ownerName", e.target.value)} />
                  </div>
                  <div>
                    <label className="text-xs font-semibold text-muted-foreground block mb-1">Owner Phone *</label>
                    <Input placeholder="+91 99000..." value={form.ownerPhone} onChange={e => update("ownerPhone", e.target.value)} />
                  </div>
                </div>
              </div>

              <div className="flex items-start gap-3 p-4 bg-amber-50 border border-amber-200 rounded-xl text-sm text-amber-800">
                <Shield className="w-4 h-4 mt-0.5 shrink-0" />
                <span>Tenant consent is mandatory. PropVeri will send an SMS to the tenant's number for consent before starting verification.</span>
              </div>

              <Button className="w-full h-12 text-base" disabled={!valid} onClick={() => setSubmitted(true)}>
                <BadgeCheck className="w-4 h-4 mr-2" /> Submit Verification Request →
              </Button>
            </div>
          )
        ) : (
          /* Track tab */
          <div className="space-y-5">
            <div className="bg-white border rounded-2xl p-5 shadow-sm">
              <h3 className="font-bold mb-4">Enter Verification ID</h3>
              <div className="flex gap-3">
                <Input placeholder="e.g. PV-VER-84712" value={trackId} onChange={e => setTrackId(e.target.value)} onKeyDown={e => e.key === "Enter" && doTrack()} className="flex-1" />
                <Button onClick={doTrack} disabled={!trackId.trim()}>
                  <Search className="w-4 h-4 mr-1.5" /> Track
                </Button>
              </div>
              <p className="text-xs text-muted-foreground mt-2">Try: <button className="text-primary underline" onClick={() => setTrackId("PV-VER-84712")}>PV-VER-84712</button> or <button className="text-primary underline" onClick={() => setTrackId("PV-VER-33201")}>PV-VER-33201</button></p>
              {trackError && <p className="text-sm text-destructive mt-2 flex items-center gap-1.5"><AlertTriangle className="w-4 h-4" /> ID not found. Please check and try again.</p>}
            </div>

            {trackResult && (
              <div className="bg-white border-2 border-primary/20 rounded-2xl p-5 shadow-sm">
                <div className="flex items-start justify-between mb-4">
                  <div>
                    <p className="text-xs text-muted-foreground">{trackResult.id}</p>
                    <h3 className="font-bold text-lg">{trackResult.name}</h3>
                    <p className="text-sm text-muted-foreground">Submitted: {trackResult.date}</p>
                  </div>
                  <div className="text-right">
                    {trackResult.status === "completed" ? (
                      <>
                        <div className="text-3xl font-bold text-green-600">{trackResult.score}</div>
                        <p className="text-xs text-muted-foreground">Trust Score</p>
                        <Badge className="bg-green-100 text-green-700 border-green-200 mt-1">Verified ✓</Badge>
                      </>
                    ) : (
                      <Badge className="bg-amber-100 text-amber-700 border-amber-200">In Progress</Badge>
                    )}
                  </div>
                </div>
                <div className="space-y-2.5">
                  {trackResult.checks.map(c => (
                    <div key={c.label} className="flex items-center justify-between py-2 border-b last:border-0">
                      <span className="text-sm">{c.label}</span>
                      <span className={cn("text-xs font-semibold flex items-center gap-1",
                        c.status === "clear" ? "text-green-600" : "text-amber-600")}>
                        {c.status === "clear" ? <CheckCircle2 className="w-3.5 h-3.5" /> : <Clock className="w-3.5 h-3.5" />}
                        {c.status === "clear" ? "Clear" : "Pending"}
                      </span>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  );
}
