import { useState } from "react";
import { Link } from "wouter";
import { ChevronLeft, PhoneCall, CheckCircle2, X, Star, Building2, BarChart3, Phone, MapPin } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { cn } from "@/lib/utils";

const PLANS = [
  {
    id: "basic", name: "Basic", price: "₹999/mo", desc: "Perfect for hands-off owners",
    features: ["Tenant finding", "Rent collection", "Monthly rent statement", "Basic maintenance coordination"],
    missing: ["Dedicated manager", "Legal support", "Annual audit"],
    color: "border-border",
    badge: null,
  },
  {
    id: "standard", name: "Standard", price: "₹1,999/mo", desc: "Most popular for active landlords",
    features: ["Everything in Basic", "Dedicated property manager", "Maintenance oversight (up to ₹5K/mo)", "Tenant verification included", "Legal advisory (1 hr/mo)"],
    missing: ["Annual property audit"],
    color: "border-primary",
    badge: "Most Popular",
  },
  {
    id: "premium", name: "Premium", price: "₹3,499/mo", desc: "Complete peace of mind",
    features: ["Everything in Standard", "Unlimited maintenance coverage", "Annual property condition audit", "Priority legal support", "Vacancy protection (15 days free)"],
    missing: [],
    color: "border-primary",
    badge: "Best Value",
  },
];

const STEPS = [
  { icon: "📋", title: "Enroll Property", desc: "Fill this form and share your property details." },
  { icon: "🤝", title: "Meet Your Manager", desc: "We assign you a dedicated property manager within 24 hours." },
  { icon: "🏠", title: "Find Tenant", desc: "We list, screen, and verify tenants on your behalf." },
  { icon: "💰", title: "Collect & Report", desc: "Rent is collected and transferred to you every month with a statement." },
];

export default function PropertyManagement() {
  const [selectedPlan, setSelectedPlan] = useState("standard");
  const [form, setForm] = useState({ name: "", phone: "", email: "", city: "", address: "", bhk: "", rent: "" });
  const [submitted, setSubmitted] = useState(false);

  function update(k: string, v: string) { setForm(f => ({ ...f, [k]: v })); }

  const valid = form.name && form.phone && form.city && form.address;

  return (
    <div className="min-h-screen">
      <div className="bg-primary text-white py-12 px-4">
        <div className="container mx-auto max-w-4xl">
          <Link href="/services" className="inline-flex items-center gap-1.5 text-white/70 hover:text-white text-sm mb-6">
            <ChevronLeft className="w-4 h-4" /> Back to Services
          </Link>
          <div className="flex items-center gap-3 mb-3">
            <div className="w-12 h-12 bg-red-100 rounded-xl flex items-center justify-center">
              <PhoneCall className="w-6 h-6 text-red-600" />
            </div>
            <div>
              <Badge className="bg-white/20 text-white border-white/30 text-xs mb-1">For Owners</Badge>
              <h1 className="text-2xl font-bold">Property Management</h1>
            </div>
          </div>
          <p className="text-white/75 max-w-xl">We manage your rental property end-to-end — tenant finding, rent collection, maintenance, and legal support.</p>
        </div>
      </div>

      <div className="container mx-auto max-w-4xl px-4 py-10 space-y-10">
        {submitted ? (
          <div className="text-center py-10">
            <CheckCircle2 className="w-16 h-16 text-green-600 mx-auto mb-4" />
            <h2 className="text-2xl font-bold mb-2">Property Enrolled!</h2>
            <p className="text-muted-foreground mb-2">Your dedicated property manager will contact <strong>{form.phone}</strong> within 24 hours.</p>
            <p className="text-muted-foreground text-sm mb-6">Plan: <strong>{PLANS.find(p => p.id === selectedPlan)?.name}</strong> — {PLANS.find(p => p.id === selectedPlan)?.price}</p>
            <div className="bg-white border rounded-xl p-5 max-w-sm mx-auto mb-6 space-y-2 text-left text-sm">
              <p><strong>Property:</strong> {form.address}, {form.city}</p>
              <p><strong>Expected Rent:</strong> ₹{form.rent ? parseInt(form.rent).toLocaleString("en-IN") : "—"}/mo</p>
            </div>
            <Button variant="outline" onClick={() => { setSubmitted(false); setForm({ name: "", phone: "", email: "", city: "", address: "", bhk: "", rent: "" }); }}>
              Enroll Another Property
            </Button>
          </div>
        ) : (
          <>
            {/* How it works */}
            <div>
              <h2 className="text-xl font-bold mb-6 text-center">How It Works</h2>
              <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                {STEPS.map((s, i) => (
                  <div key={i} className="text-center">
                    <div className="text-4xl mb-3">{s.icon}</div>
                    <p className="font-bold text-sm mb-1">{s.title}</p>
                    <p className="text-xs text-muted-foreground leading-relaxed">{s.desc}</p>
                  </div>
                ))}
              </div>
            </div>

            {/* Pricing plans */}
            <div>
              <h2 className="text-xl font-bold mb-6">Choose Your Plan</h2>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-5">
                {PLANS.map(plan => (
                  <div key={plan.id} onClick={() => setSelectedPlan(plan.id)}
                    className={cn("border-2 rounded-2xl p-5 cursor-pointer transition-all relative",
                      selectedPlan === plan.id ? "border-primary bg-primary/5 shadow-md" : "border-border bg-white hover:border-primary/40")}>
                    {plan.badge && (
                      <span className="absolute -top-3 left-1/2 -translate-x-1/2 text-xs font-bold px-3 py-1 bg-primary text-white rounded-full">
                        {plan.badge}
                      </span>
                    )}
                    <div className="mb-4 mt-1">
                      <h3 className="font-bold text-lg">{plan.name}</h3>
                      <p className="text-2xl font-bold text-primary">{plan.price}</p>
                      <p className="text-xs text-muted-foreground">{plan.desc}</p>
                    </div>
                    <ul className="space-y-2 mb-3">
                      {plan.features.map(f => (
                        <li key={f} className="flex items-start gap-2 text-xs">
                          <CheckCircle2 className="w-3.5 h-3.5 text-green-500 shrink-0 mt-0.5" /> {f}
                        </li>
                      ))}
                      {plan.missing.map(f => (
                        <li key={f} className="flex items-start gap-2 text-xs text-muted-foreground/60">
                          <X className="w-3.5 h-3.5 shrink-0 mt-0.5" /> {f}
                        </li>
                      ))}
                    </ul>
                    <div className={cn("w-full h-1 rounded-full mt-3", selectedPlan === plan.id ? "bg-primary" : "bg-border")} />
                  </div>
                ))}
              </div>
            </div>

            {/* Enrollment form */}
            <div className="bg-white border rounded-2xl p-6 shadow-sm">
              <h2 className="text-xl font-bold mb-5">Enroll Your Property</h2>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <label className="text-sm font-semibold mb-1.5 block">Owner Name *</label>
                  <Input placeholder="Suresh Nair" value={form.name} onChange={e => update("name", e.target.value)} />
                </div>
                <div>
                  <label className="text-sm font-semibold mb-1.5 block">Phone *</label>
                  <div className="relative">
                    <Phone className="absolute left-3 top-3 w-4 h-4 text-muted-foreground" />
                    <Input className="pl-9" placeholder="+91 98765 43210" value={form.phone} onChange={e => update("phone", e.target.value)} />
                  </div>
                </div>
                <div>
                  <label className="text-sm font-semibold mb-1.5 block">City *</label>
                  <Input placeholder="Mumbai" value={form.city} onChange={e => update("city", e.target.value)} />
                </div>
                <div>
                  <label className="text-sm font-semibold mb-1.5 block">Email</label>
                  <Input type="email" placeholder="you@example.com" value={form.email} onChange={e => update("email", e.target.value)} />
                </div>
                <div className="md:col-span-2">
                  <label className="text-sm font-semibold mb-1.5 block">Property Address *</label>
                  <div className="relative">
                    <MapPin className="absolute left-3 top-3 w-4 h-4 text-muted-foreground" />
                    <Input className="pl-9" placeholder="Flat 302, Sea View Apts, Bandra West, Mumbai" value={form.address} onChange={e => update("address", e.target.value)} />
                  </div>
                </div>
                <div>
                  <label className="text-sm font-semibold mb-1.5 block">BHK Type</label>
                  <select className="w-full h-10 border border-border rounded-md px-3 text-sm" value={form.bhk} onChange={e => update("bhk", e.target.value)}>
                    <option value="">Select</option>
                    {["1 BHK", "2 BHK", "3 BHK", "4 BHK+", "Studio", "Commercial"].map(b => <option key={b}>{b}</option>)}
                  </select>
                </div>
                <div>
                  <label className="text-sm font-semibold mb-1.5 block">Expected Monthly Rent (₹)</label>
                  <Input type="number" placeholder="25000" value={form.rent} onChange={e => update("rent", e.target.value)} />
                </div>
              </div>
              <div className="mt-4 p-4 bg-muted/30 rounded-xl text-sm flex items-center gap-3">
                <BarChart3 className="w-5 h-5 text-primary shrink-0" />
                <span>Selected: <strong>{PLANS.find(p => p.id === selectedPlan)?.name}</strong> plan at <strong>{PLANS.find(p => p.id === selectedPlan)?.price}</strong></span>
              </div>
              <Button className="w-full h-12 text-base mt-4" disabled={!valid} onClick={() => setSubmitted(true)}>
                <PhoneCall className="w-4 h-4 mr-2" /> Enroll Property →
              </Button>
            </div>
          </>
        )}
      </div>
    </div>
  );
}
