import { useState } from "react";
import { Link } from "wouter";
import { ChevronLeft, Truck, CheckCircle2, Star, Shield, MapPin, Calendar, Package, Phone, User, ArrowRight, ChevronRight } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { cn } from "@/lib/utils";

const MOVE_TYPES = [
  { id: "1bhk", label: "1 BHK", icon: "🏠" },
  { id: "2bhk", label: "2 BHK", icon: "🏡" },
  { id: "3bhk", label: "3 BHK+", icon: "🏘" },
  { id: "office", label: "Office", icon: "🏢" },
  { id: "vehicle", label: "Vehicle Only", icon: "🚗" },
  { id: "storage", label: "Storage", icon: "📦" },
];

const MOCK_QUOTES = [
  { company: "SafeShift Movers", rating: 4.8, reviews: 2341, price: "₹8,500", time: "6–8 hrs", badge: "Most Booked", color: "border-primary" },
  { company: "QuickMove India", rating: 4.6, reviews: 1820, price: "₹7,200", time: "7–9 hrs", badge: "Best Value", color: "border-green-500" },
  { company: "CargoKing Pro", rating: 4.5, reviews: 973, price: "₹9,800", time: "5–7 hrs", badge: "Fastest", color: "border-orange-400" },
];

export default function PackersMovers() {
  const [step, setStep] = useState(1);
  const [form, setForm] = useState({ from: "", to: "", date: "", moveType: "", floors: "", name: "", phone: "", email: "" });
  const [submitted, setSubmitted] = useState(false);

  function update(key: string, val: string) {
    setForm(f => ({ ...f, [key]: val }));
  }

  const step1Valid = form.from && form.to && form.date;
  const step2Valid = form.moveType;
  const step3Valid = form.name && form.phone;

  return (
    <div className="min-h-screen">
      {/* Hero */}
      <div className="bg-primary text-white py-12 px-4">
        <div className="container mx-auto max-w-3xl">
          <Link href="/services" className="inline-flex items-center gap-1.5 text-white/70 hover:text-white text-sm mb-6">
            <ChevronLeft className="w-4 h-4" /> Back to Services
          </Link>
          <div className="flex items-center gap-3 mb-3">
            <div className="w-12 h-12 bg-blue-100 rounded-xl flex items-center justify-center">
              <Truck className="w-6 h-6 text-blue-600" />
            </div>
            <div>
              <Badge className="bg-white/20 text-white border-white/30 text-xs mb-1">Most Popular</Badge>
              <h1 className="text-2xl font-bold">Packers & Movers</h1>
            </div>
          </div>
          <p className="text-white/75 max-w-xl">Verified & insured movers. Get up to 3 instant quotes. Fixed pricing — no last-minute surprises.</p>
          <div className="flex gap-6 mt-4 text-sm text-white/80">
            {["Background Verified", "GPS Tracked", "Fully Insured", "Fixed Rates"].map(f => (
              <span key={f} className="flex items-center gap-1"><CheckCircle2 className="w-3.5 h-3.5 text-green-400" /> {f}</span>
            ))}
          </div>
        </div>
      </div>

      <div className="container mx-auto max-w-3xl px-4 py-10">
        {submitted ? (
          /* ── Success: Show quotes ── */
          <div>
            <div className="text-center mb-8">
              <div className="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <CheckCircle2 className="w-8 h-8 text-green-600" />
              </div>
              <h2 className="text-2xl font-bold mb-1">Your Quotes are Ready!</h2>
              <p className="text-muted-foreground">3 verified movers are available for <strong>{form.from} → {form.to}</strong> on <strong>{form.date}</strong></p>
            </div>
            <div className="space-y-4">
              {MOCK_QUOTES.map(q => (
                <div key={q.company} className={cn("bg-white border-2 rounded-xl p-5 flex items-center gap-5", q.color)}>
                  <div className="w-12 h-12 bg-muted rounded-xl flex items-center justify-center text-2xl shrink-0">🚛</div>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2 mb-1">
                      <p className="font-bold">{q.company}</p>
                      <span className="text-xs px-2 py-0.5 bg-primary/10 text-primary rounded-full font-semibold">{q.badge}</span>
                    </div>
                    <div className="flex items-center gap-3 text-sm text-muted-foreground">
                      <span className="flex items-center gap-1"><Star className="w-3.5 h-3.5 text-yellow-400 fill-yellow-400" /> {q.rating} ({q.reviews.toLocaleString()})</span>
                      <span>⏱ {q.time}</span>
                    </div>
                  </div>
                  <div className="text-right shrink-0">
                    <p className="text-2xl font-bold text-primary">{q.price}</p>
                    <Button size="sm" className="mt-2">Book Now</Button>
                  </div>
                </div>
              ))}
            </div>
            <div className="mt-6 p-4 bg-amber-50 border border-amber-200 rounded-xl text-sm text-amber-800">
              <strong>📞 Our team will call {form.phone} within 30 minutes</strong> to confirm your booking and answer any questions.
            </div>
            <Button variant="outline" className="mt-4 w-full" onClick={() => { setSubmitted(false); setStep(1); setForm({ from: "", to: "", date: "", moveType: "", floors: "", name: "", phone: "", email: "" }); }}>
              Get New Quotes
            </Button>
          </div>
        ) : (
          /* ── Multi-step form ── */
          <div>
            {/* Step indicator */}
            <div className="flex items-center mb-8">
              {[{ n: 1, label: "Route & Date" }, { n: 2, label: "Move Details" }, { n: 3, label: "Contact" }].map((s, i) => (
                <div key={s.n} className="flex items-center flex-1">
                  <div className={cn("w-8 h-8 rounded-full flex items-center justify-center text-sm font-bold border-2 shrink-0",
                    step > s.n ? "bg-green-500 border-green-500 text-white" :
                    step === s.n ? "bg-primary border-primary text-white" :
                    "bg-white border-border text-muted-foreground")}>
                    {step > s.n ? "✓" : s.n}
                  </div>
                  <span className={cn("ml-2 text-sm font-medium hidden sm:block", step === s.n ? "text-primary" : "text-muted-foreground")}>{s.label}</span>
                  {i < 2 && <div className={cn("flex-1 h-px mx-3", step > s.n ? "bg-green-400" : "bg-border")} />}
                </div>
              ))}
            </div>

            <div className="bg-white border rounded-2xl p-6 shadow-sm">
              {step === 1 && (
                <div className="space-y-4">
                  <h2 className="text-xl font-bold mb-4">Where are you moving?</h2>
                  <div>
                    <label className="text-sm font-semibold mb-1.5 block">Moving From <span className="text-destructive">*</span></label>
                    <div className="relative">
                      <MapPin className="absolute left-3 top-3 w-4 h-4 text-muted-foreground" />
                      <Input className="pl-9" placeholder="e.g. Bandra West, Mumbai" value={form.from} onChange={e => update("from", e.target.value)} />
                    </div>
                  </div>
                  <div>
                    <label className="text-sm font-semibold mb-1.5 block">Moving To <span className="text-destructive">*</span></label>
                    <div className="relative">
                      <MapPin className="absolute left-3 top-3 w-4 h-4 text-muted-foreground" />
                      <Input className="pl-9" placeholder="e.g. Koramangala, Bangalore" value={form.to} onChange={e => update("to", e.target.value)} />
                    </div>
                  </div>
                  <div>
                    <label className="text-sm font-semibold mb-1.5 block">Preferred Moving Date <span className="text-destructive">*</span></label>
                    <div className="relative">
                      <Calendar className="absolute left-3 top-3 w-4 h-4 text-muted-foreground" />
                      <Input className="pl-9" type="date" value={form.date} onChange={e => update("date", e.target.value)} min={new Date().toISOString().split("T")[0]} />
                    </div>
                  </div>
                  <Button className="w-full h-11" disabled={!step1Valid} onClick={() => setStep(2)}>
                    Next: Move Details <ChevronRight className="w-4 h-4 ml-1" />
                  </Button>
                </div>
              )}

              {step === 2 && (
                <div className="space-y-4">
                  <h2 className="text-xl font-bold mb-4">What are you moving?</h2>
                  <div>
                    <label className="text-sm font-semibold mb-2 block">Type of Move <span className="text-destructive">*</span></label>
                    <div className="grid grid-cols-3 gap-2">
                      {MOVE_TYPES.map(t => (
                        <button key={t.id} onClick={() => update("moveType", t.id)}
                          className={cn("border-2 rounded-xl p-3 text-center transition-colors",
                            form.moveType === t.id ? "border-primary bg-primary/5" : "border-border hover:border-primary/40")}>
                          <div className="text-2xl mb-1">{t.icon}</div>
                          <div className="text-xs font-semibold">{t.label}</div>
                        </button>
                      ))}
                    </div>
                  </div>
                  <div>
                    <label className="text-sm font-semibold mb-1.5 block">Floor (Current Location)</label>
                    <Input placeholder="e.g. Ground Floor, 3rd Floor" value={form.floors} onChange={e => update("floors", e.target.value)} />
                  </div>
                  <div className="flex gap-3 mt-2">
                    <Button variant="outline" className="flex-1" onClick={() => setStep(1)}>← Back</Button>
                    <Button className="flex-1" disabled={!step2Valid} onClick={() => setStep(3)}>
                      Next: Contact <ChevronRight className="w-4 h-4 ml-1" />
                    </Button>
                  </div>
                </div>
              )}

              {step === 3 && (
                <div className="space-y-4">
                  <h2 className="text-xl font-bold mb-4">Your Contact Details</h2>
                  <div>
                    <label className="text-sm font-semibold mb-1.5 block">Full Name <span className="text-destructive">*</span></label>
                    <div className="relative">
                      <User className="absolute left-3 top-3 w-4 h-4 text-muted-foreground" />
                      <Input className="pl-9" placeholder="Rahul Sharma" value={form.name} onChange={e => update("name", e.target.value)} />
                    </div>
                  </div>
                  <div>
                    <label className="text-sm font-semibold mb-1.5 block">Phone Number <span className="text-destructive">*</span></label>
                    <div className="relative">
                      <Phone className="absolute left-3 top-3 w-4 h-4 text-muted-foreground" />
                      <Input className="pl-9" placeholder="+91 98765 43210" value={form.phone} onChange={e => update("phone", e.target.value)} />
                    </div>
                  </div>
                  <div>
                    <label className="text-sm font-semibold mb-1.5 block">Email (optional)</label>
                    <Input type="email" placeholder="you@example.com" value={form.email} onChange={e => update("email", e.target.value)} />
                  </div>
                  <div className="p-3 bg-blue-50 rounded-lg text-sm text-blue-700 border border-blue-100">
                    <Shield className="w-4 h-4 inline mr-1.5" /> Your number is only shared with verified movers after you confirm.
                  </div>
                  <div className="flex gap-3">
                    <Button variant="outline" className="flex-1" onClick={() => setStep(2)}>← Back</Button>
                    <Button className="flex-1" disabled={!step3Valid} onClick={() => setSubmitted(true)}>
                      Get Free Quotes ✓
                    </Button>
                  </div>
                </div>
              )}
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
