import { useState } from "react";
import { Link } from "wouter";
import { ChevronLeft, Paintbrush, CheckCircle2, Star, Phone, Calendar, ArrowRight } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { cn } from "@/lib/utils";
import { Slider } from "@/components/ui/slider";

const STYLES = [
  { id: "modern", label: "Modern", emoji: "🏙", desc: "Clean lines, neutral palette, minimal clutter" },
  { id: "contemporary", label: "Contemporary", emoji: "✨", desc: "Sleek finishes, bold accents, open spaces" },
  { id: "traditional", label: "Traditional", emoji: "🏛", desc: "Rich textures, warm tones, classic furniture" },
  { id: "minimalist", label: "Minimalist", emoji: "⬜", desc: "Less is more — only the essentials" },
  { id: "industrial", label: "Industrial", emoji: "⚙️", desc: "Raw concrete, exposed metal, urban feel" },
  { id: "bohemian", label: "Bohemian", emoji: "🌿", desc: "Eclectic, vibrant, layered textures" },
];

const ROOMS = [
  { id: "living", label: "Living Room", icon: "🛋" },
  { id: "bedroom", label: "Bedroom", icon: "🛏" },
  { id: "kitchen", label: "Kitchen", icon: "🍳" },
  { id: "bathroom", label: "Bathroom", icon: "🚿" },
  { id: "dining", label: "Dining Room", icon: "🍽" },
  { id: "full", label: "Full Home", icon: "🏠" },
];

const DESIGNERS = [
  { name: "Ananya Kapoor", city: "Mumbai", exp: "8 yrs", rating: 4.9, projects: 142, speciality: "Modern & Minimalist", img: "AK" },
  { name: "Ravi Menon", city: "Bangalore", exp: "11 yrs", rating: 4.8, projects: 203, speciality: "Contemporary & Traditional", img: "RM" },
  { name: "Deepika Joshi", city: "Delhi", exp: "6 yrs", rating: 4.7, projects: 98, speciality: "Bohemian & Eclectic", img: "DJ" },
];

export default function InteriorDesign() {
  const [selectedStyle, setSelectedStyle] = useState<string | null>(null);
  const [selectedRooms, setSelectedRooms] = useState<string[]>([]);
  const [budget, setBudget] = useState(500000);
  const [form, setForm] = useState({ name: "", phone: "", city: "", area: "", date: "" });
  const [submitted, setSubmitted] = useState(false);

  function toggleRoom(id: string) {
    setSelectedRooms(r => r.includes(id) ? r.filter(x => x !== id) : [...r, id]);
  }

  const valid = selectedStyle && selectedRooms.length > 0 && form.name && form.phone;

  function fmtBudget(n: number) {
    if (n >= 100000) return `₹${(n / 100000).toFixed(1)}L`;
    return `₹${n.toLocaleString("en-IN")}`;
  }

  return (
    <div className="min-h-screen">
      <div className="bg-primary text-white py-12 px-4">
        <div className="container mx-auto max-w-4xl">
          <Link href="/services" className="inline-flex items-center gap-1.5 text-white/70 hover:text-white text-sm mb-6">
            <ChevronLeft className="w-4 h-4" /> Back to Services
          </Link>
          <div className="flex items-center gap-3 mb-3">
            <div className="w-12 h-12 bg-pink-100 rounded-xl flex items-center justify-center">
              <Paintbrush className="w-6 h-6 text-pink-600" />
            </div>
            <h1 className="text-2xl font-bold">Interior Design</h1>
          </div>
          <p className="text-white/75 max-w-xl">Expert designers, 3D visualisation, and end-to-end project management. Transform your new home.</p>
          <div className="flex gap-5 mt-4 text-sm text-white/80">
            {["Free 3D Design", "Expert Designers", "On-time Delivery", "2-Year Warranty"].map(f => (
              <span key={f} className="flex items-center gap-1"><CheckCircle2 className="w-3.5 h-3.5 text-green-400" /> {f}</span>
            ))}
          </div>
        </div>
      </div>

      <div className="container mx-auto max-w-4xl px-4 py-10 space-y-8">
        {submitted ? (
          <div className="text-center py-10">
            <CheckCircle2 className="w-16 h-16 text-green-600 mx-auto mb-4" />
            <h2 className="text-2xl font-bold mb-2">Design Consultation Booked!</h2>
            <p className="text-muted-foreground mb-6 max-w-md mx-auto">
              Your designer will reach out to <strong>{form.phone}</strong> within 24 hours to start your 3D design journey.
            </p>
            <div className="bg-white border rounded-xl p-5 max-w-sm mx-auto text-left space-y-2 mb-6">
              <p className="text-sm"><strong>Style:</strong> {STYLES.find(s => s.id === selectedStyle)?.label}</p>
              <p className="text-sm"><strong>Rooms:</strong> {selectedRooms.map(r => ROOMS.find(x => x.id === r)?.label).join(", ")}</p>
              <p className="text-sm"><strong>Budget:</strong> {fmtBudget(budget)}</p>
              <p className="text-sm"><strong>City:</strong> {form.city || "—"}</p>
            </div>
            <Button variant="outline" onClick={() => { setSubmitted(false); setSelectedStyle(null); setSelectedRooms([]); setBudget(500000); setForm({ name: "", phone: "", city: "", area: "", date: "" }); }}>
              Start Over
            </Button>
          </div>
        ) : (
          <>
            {/* Style selection */}
            <div className="bg-white border rounded-2xl p-6 shadow-sm">
              <h2 className="text-xl font-bold mb-5">Choose Your Style *</h2>
              <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
                {STYLES.map(s => (
                  <button key={s.id} onClick={() => setSelectedStyle(s.id === selectedStyle ? null : s.id)}
                    className={cn("border-2 rounded-xl p-4 text-left transition-all",
                      selectedStyle === s.id ? "border-primary bg-primary/5" : "border-border hover:border-primary/40")}>
                    <div className="text-3xl mb-2">{s.emoji}</div>
                    <p className="font-semibold text-sm">{s.label}</p>
                    <p className="text-xs text-muted-foreground mt-0.5">{s.desc}</p>
                  </button>
                ))}
              </div>
            </div>

            {/* Room selection */}
            <div className="bg-white border rounded-2xl p-6 shadow-sm">
              <h2 className="text-xl font-bold mb-5">Select Room(s) *</h2>
              <div className="grid grid-cols-3 md:grid-cols-6 gap-3">
                {ROOMS.map(r => (
                  <button key={r.id} onClick={() => toggleRoom(r.id)}
                    className={cn("border-2 rounded-xl p-3 text-center transition-all",
                      selectedRooms.includes(r.id) ? "border-primary bg-primary/5" : "border-border hover:border-primary/40")}>
                    <div className="text-2xl mb-1">{r.icon}</div>
                    <div className="text-xs font-semibold">{r.label}</div>
                  </button>
                ))}
              </div>
            </div>

            {/* Budget slider */}
            <div className="bg-white border rounded-2xl p-6 shadow-sm">
              <div className="flex justify-between mb-4">
                <h2 className="text-xl font-bold">Design Budget</h2>
                <span className="text-xl font-bold text-primary">{fmtBudget(budget)}</span>
              </div>
              <Slider min={100000} max={5000000} step={50000} value={[budget]} onValueChange={v => setBudget(v[0])} />
              <div className="flex justify-between text-xs text-muted-foreground mt-2">
                <span>₹1L (Essential)</span><span>₹50L (Luxury)</span>
              </div>
              <div className="mt-4 grid grid-cols-3 gap-3 text-center text-xs">
                {[{ label: "Essential", range: "₹1–5L", desc: "Basic modular + paint" }, { label: "Standard", range: "₹5–15L", desc: "Full modular + flooring" }, { label: "Premium", range: "₹15L+", desc: "Custom + imported materials" }].map(t => (
                  <div key={t.label} className={cn("border rounded-lg p-2", budget < 500000 && t.label === "Essential" ? "border-primary bg-primary/5" : budget < 1500000 && t.label === "Standard" ? "border-primary bg-primary/5" : t.label === "Premium" && budget >= 1500000 ? "border-primary bg-primary/5" : "border-border")}>
                    <p className="font-bold">{t.label}</p>
                    <p className="text-primary font-semibold">{t.range}</p>
                    <p className="text-muted-foreground text-[10px]">{t.desc}</p>
                  </div>
                ))}
              </div>
            </div>

            {/* Meet our designers */}
            <div>
              <h2 className="text-xl font-bold mb-5">Meet Our Designers</h2>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                {DESIGNERS.map(d => (
                  <div key={d.name} className="bg-white border rounded-xl p-4">
                    <div className="flex items-center gap-3 mb-3">
                      <div className="w-10 h-10 rounded-full bg-primary text-white flex items-center justify-center text-sm font-bold">{d.img}</div>
                      <div>
                        <p className="font-bold text-sm">{d.name}</p>
                        <p className="text-xs text-muted-foreground">{d.city} · {d.exp} exp</p>
                      </div>
                    </div>
                    <div className="flex items-center gap-1.5 text-xs text-muted-foreground mb-2">
                      <Star className="w-3.5 h-3.5 text-yellow-400 fill-yellow-400" /> {d.rating} · {d.projects} projects
                    </div>
                    <p className="text-xs text-muted-foreground">{d.speciality}</p>
                  </div>
                ))}
              </div>
            </div>

            {/* Booking form */}
            <div className="bg-white border rounded-2xl p-6 shadow-sm">
              <h2 className="text-xl font-bold mb-5">Book Free Consultation</h2>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <label className="text-sm font-semibold mb-1.5 block">Your Name *</label>
                  <Input placeholder="Anita Desai" value={form.name} onChange={e => setForm(f => ({ ...f, name: e.target.value }))} />
                </div>
                <div>
                  <label className="text-sm font-semibold mb-1.5 block">Phone *</label>
                  <div className="relative">
                    <Phone className="absolute left-3 top-3 w-4 h-4 text-muted-foreground" />
                    <Input className="pl-9" placeholder="+91 98765 43210" value={form.phone} onChange={e => setForm(f => ({ ...f, phone: e.target.value }))} />
                  </div>
                </div>
                <div>
                  <label className="text-sm font-semibold mb-1.5 block">City</label>
                  <Input placeholder="Mumbai" value={form.city} onChange={e => setForm(f => ({ ...f, city: e.target.value }))} />
                </div>
                <div>
                  <label className="text-sm font-semibold mb-1.5 block">Carpet Area (sqft)</label>
                  <Input type="number" placeholder="1200" value={form.area} onChange={e => setForm(f => ({ ...f, area: e.target.value }))} />
                </div>
              </div>
              <Button className="w-full h-12 text-base mt-4" disabled={!valid} onClick={() => setSubmitted(true)}>
                <Paintbrush className="w-4 h-4 mr-2" /> Book Free Consultation →
              </Button>
            </div>
          </>
        )}
      </div>
    </div>
  );
}
