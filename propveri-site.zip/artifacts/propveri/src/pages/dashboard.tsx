import { Link } from "wouter";
import { useGetUserProperties, getGetUserPropertiesQueryKey, useGetPropertyStats } from "@workspace/api-client-react";
import { Building2, PlusCircle, Edit, Trash2, LayoutDashboard, Eye, CheckCircle2, Clock } from "lucide-react";
import { formatIndianPrice, cn } from "@/lib/utils";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";

export default function Dashboard() {
  const MOCK_USER_ID = 1;
  
  const { data: properties, isLoading } = useGetUserProperties(MOCK_USER_ID, {
    query: {
      enabled: !!MOCK_USER_ID,
      queryKey: getGetUserPropertiesQueryKey(MOCK_USER_ID)
    }
  });

  const { data: stats } = useGetPropertyStats();

  const getStatusBadge = (status: string) => {
    switch (status) {
      case 'verified':
        return <Badge className="bg-green-100 text-green-800 border-green-200 hover:bg-green-100"><CheckCircle2 className="w-3 h-3 mr-1" /> Active</Badge>;
      case 'pending_verification':
        return <Badge variant="outline" className="bg-amber-50 text-amber-700 border-amber-200"><Clock className="w-3 h-3 mr-1" /> Pending Review</Badge>;
      case 'sold':
        return <Badge variant="secondary">Sold</Badge>;
      case 'rejected':
        return <Badge variant="destructive">Rejected</Badge>;
      default:
        return <Badge variant="outline">{status}</Badge>;
    }
  };

  return (
    <div className="container mx-auto px-4 py-12 max-w-6xl">
      <div className="flex flex-col md:flex-row md:items-end justify-between mb-8 gap-4">
        <div>
          <h1 className="text-3xl font-serif font-bold tracking-tight mb-2 flex items-center gap-2">
            <LayoutDashboard className="w-6 h-6 text-primary" /> My Dashboard
          </h1>
          <p className="text-muted-foreground">Manage your property listings and track performance.</p>
        </div>
        <Link href="/list-property">
          <Button>
            <PlusCircle className="w-4 h-4 mr-2" /> Add New Listing
          </Button>
        </Link>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-10">
        <Card className="bg-primary/5 border-primary/20 shadow-sm">
          <CardContent className="p-6">
            <div className="flex justify-between items-start mb-2">
              <p className="text-sm font-medium text-primary">Active Listings</p>
              <Building2 className="w-4 h-4 text-primary/60" />
            </div>
            <p className="text-3xl font-bold font-serif text-primary">
              {isLoading ? <Skeleton className="h-8 w-12" /> : properties?.filter(p => p.status === 'verified').length || 0}
            </p>
          </CardContent>
        </Card>
        
        <Card className="shadow-sm">
          <CardContent className="p-6">
            <div className="flex justify-between items-start mb-2">
              <p className="text-sm font-medium text-muted-foreground">Pending Review</p>
              <Clock className="w-4 h-4 text-muted-foreground/60" />
            </div>
            <p className="text-3xl font-bold font-serif">
              {isLoading ? <Skeleton className="h-8 w-12" /> : properties?.filter(p => p.status === 'pending_verification').length || 0}
            </p>
          </CardContent>
        </Card>

        <Card className="shadow-sm">
          <CardContent className="p-6">
            <div className="flex justify-between items-start mb-2">
              <p className="text-sm font-medium text-muted-foreground">Platform Avg Price</p>
              <Eye className="w-4 h-4 text-muted-foreground/60" />
            </div>
            <p className="text-3xl font-bold font-serif">
              {stats ? formatIndianPrice(stats.avgListedPrice) : <Skeleton className="h-8 w-24" />}
            </p>
          </CardContent>
        </Card>
      </div>

      <Card className="shadow-sm border-0 ring-1 ring-border/50">
        <CardHeader className="border-b bg-muted/30">
          <CardTitle className="text-lg">My Properties</CardTitle>
        </CardHeader>
        <CardContent className="p-0">
          {isLoading ? (
            <div className="divide-y">
              {[1, 2, 3].map(i => (
                <div key={i} className="p-6 flex items-center gap-6">
                  <Skeleton className="h-20 w-32 rounded-md" />
                  <div className="space-y-2 flex-1">
                    <Skeleton className="h-5 w-1/3" />
                    <Skeleton className="h-4 w-1/4" />
                  </div>
                  <div className="space-x-2">
                    <Skeleton className="h-9 w-20 inline-block" />
                    <Skeleton className="h-9 w-20 inline-block" />
                  </div>
                </div>
              ))}
            </div>
          ) : properties && properties.length > 0 ? (
            <div className="divide-y">
              {properties.map(property => (
                <div key={property.id} className="p-6 flex flex-col sm:flex-row sm:items-center gap-6 group hover:bg-muted/30 transition-colors">
                  <div className="w-full sm:w-32 h-24 sm:h-20 rounded-md overflow-hidden bg-muted shrink-0 relative">
                    {property.imageUrl ? (
                      <img src={property.imageUrl} alt={property.title} className="w-full h-full object-cover" />
                    ) : (
                      <div className="w-full h-full flex items-center justify-center text-muted-foreground">
                        <Building2 className="w-6 h-6 opacity-40" />
                      </div>
                    )}
                  </div>
                  
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2 mb-1">
                      <Link href={`/properties/${property.id}`} className="font-semibold text-lg hover:text-primary transition-colors truncate">
                        {property.title}
                      </Link>
                      {getStatusBadge(property.status)}
                    </div>
                    
                    <p className="text-sm text-muted-foreground mb-2 flex items-center gap-1.5">
                      <span className="font-medium text-foreground">{formatIndianPrice(property.listedPrice)}</span> listed 
                      <span className="mx-1">•</span> 
                      {property.city}, {property.state}
                    </p>
                    
                    <div className="text-xs text-muted-foreground">
                      Added {new Date(property.createdAt).toLocaleDateString()}
                    </div>
                  </div>
                  
                  <div className="flex items-center gap-2 sm:opacity-0 sm:group-hover:opacity-100 transition-opacity">
                    <Link href={`/properties/${property.id}`}>
                      <Button variant="outline" size="sm" className="h-9" title="View Listing">
                        <Eye className="w-4 h-4 mr-1.5" /> View
                      </Button>
                    </Link>
                    <Button variant="outline" size="sm" className="h-9" title="Edit Listing">
                      <Edit className="w-4 h-4 mr-1.5" /> Edit
                    </Button>
                    <Button variant="outline" size="sm" className="h-9 text-destructive hover:text-destructive hover:bg-destructive/10" title="Delete Listing">
                      <Trash2 className="w-4 h-4" />
                    </Button>
                  </div>
                </div>
              ))}
            </div>
          ) : (
            <div className="text-center py-16">
              <div className="w-16 h-16 bg-muted rounded-full flex items-center justify-center mx-auto mb-4">
                <Building2 className="w-8 h-8 text-muted-foreground/50" />
              </div>
              <h3 className="text-lg font-medium mb-2">No properties listed yet</h3>
              <p className="text-muted-foreground max-w-md mx-auto mb-6">
                Start adding your properties to the platform to reach verified buyers with honest pricing.
              </p>
              <Link href="/list-property">
                <Button>List Your First Property</Button>
              </Link>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}