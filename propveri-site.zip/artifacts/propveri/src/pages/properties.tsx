import { useState, useEffect, Suspense, lazy } from "react";
import { useSearch, Link } from "wouter";
import { useListProperties, getListPropertiesQueryKey } from "@workspace/api-client-react";
import { Search, X, BadgeCheck, LayoutList, Map } from "lucide-react";
import { PropertyCard } from "@/components/property-card";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import { Badge } from "@/components/ui/badge";
import { cn } from "@/lib/utils";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { formatIndianPrice } from "@/lib/utils";
import { Bed, Bath, Square } from "lucide-react";

const PropertyMap = lazy(() =>
  import("@/components/property-map").then(m => ({ default: m.PropertyMap }))
);

type Mode = "buy" | "rent" | "pg";
type ViewMode = "list" | "map";
const BHK_OPTIONS = ["1", "2", "3", "4", "4+"] as const;
const BUDGET_OPTIONS: { label: string; min?: number; max?: number }[] = [
  { label: "Under ₹30L", max: 30 },
  { label: "₹30–60L", min: 30, max: 60 },
  { label: "₹60L–1Cr", min: 60, max: 100 },
  { label: "₹1–2Cr", min: 100, max: 200 },
  { label: "₹2Cr+", min: 200 },
];

export default function Properties() {
  const rawSearch = useSearch();
  const params = new URLSearchParams(rawSearch);

  const [mode, setMode] = useState<Mode>((params.get("mode") as Mode) || "buy");
  const [viewMode, setViewMode] = useState<ViewMode>("list");
  const [searchCity, setSearchCity] = useState(params.get("city") || "");
  const [inputCity, setInputCity] = useState(params.get("city") || "");
  const [propertyType, setPropertyType] = useState(params.get("type") || "all");
  const [status, setStatus] = useState("all");
  const [bhk, setBhk] = useState<string | null>(null);
  const [budget, setBudget] = useState<{ label: string; min?: number; max?: number } | null>(null);
  const [noBroker, setNoBroker] = useState(false);
  const [sortBy, setSortBy] = useState("newest");
  const [activeId, setActiveId] = useState<number | null>(null);

  useEffect(() => {
    const city = params.get("city");
    if (city) { setSearchCity(city); setInputCity(city); }
    const type = params.get("type");
    if (type) setPropertyType(type);
    const m = params.get("mode") as Mode;
    if (m) setMode(m);
  }, [rawSearch]);

  const queryParams = {
    ...(searchCity ? { city: searchCity } : {}),
    ...(propertyType !== "all" ? { type: propertyType } : {}),
    ...(status !== "all" ? { status } : {}),
    ...(budget?.min ? { minPrice: budget.min } : {}),
    ...(budget?.max ? { maxPrice: budget.max } : {}),
  };

  const { data: allProperties, isLoading } = useListProperties(queryParams, {
    query: { queryKey: getListPropertiesQueryKey(queryParams) }
  });

  let properties = allProperties ?? [];

  if (bhk) {
    const bedrooms = bhk === "4+" ? 4 : parseInt(bhk);
    properties = properties.filter(p =>
      bhk === "4+" ? p.bedrooms >= 4 : p.bedrooms === bedrooms
    );
  }

  if (sortBy === "price_asc") properties = [...properties].sort((a, b) => a.listedPrice - b.listedPrice);
  else if (sortBy === "price_desc") properties = [...properties].sort((a, b) => b.listedPrice - a.listedPrice);
  else if (sortBy === "area_desc") properties = [...properties].sort((a, b) => b.areasqft - a.areasqft);

  const activeFilters = [
    bhk && `${bhk} BHK`,
    budget && budget.label,
    propertyType !== "all" && propertyType,
    status !== "all" && status,
    noBroker && "No Broker",
  ].filter(Boolean) as string[];

  function clearAll() {
    setSearchCity(""); setInputCity("");
    setPropertyType("all"); setStatus("all");
    setBhk(null); setBudget(null); setNoBroker(false); setSortBy("newest");
  }

  const isMapView = viewMode === "map";

  return (
    <div className="min-h-screen bg-muted/20 flex flex-col">
      {/* Mode tabs */}
      <div className="bg-white border-b sticky top-16 z-30">
        <div className="container mx-auto px-4">
          <div className="flex items-center justify-between">
            <div className="flex">
              {(["buy", "rent", "pg"] as Mode[]).map(m => (
                <button
                  key={m}
                  onClick={() => setMode(m)}
                  className={cn(
                    "px-6 py-4 text-sm font-semibold uppercase tracking-wide border-b-2 transition-colors",
                    mode === m ? "border-primary text-primary" : "border-transparent text-muted-foreground hover:text-foreground"
                  )}
                >
                  {m === "buy" ? "Buy" : m === "rent" ? "Rent" : "PG / Co-living"}
                </button>
              ))}
            </div>

            {/* List / Map toggle */}
            <div className="flex items-center gap-1 bg-muted rounded-lg p-1">
              <button
                onClick={() => setViewMode("list")}
                className={cn(
                  "flex items-center gap-1.5 px-3 py-1.5 rounded-md text-sm font-medium transition-colors",
                  viewMode === "list" ? "bg-white text-foreground shadow-sm" : "text-muted-foreground hover:text-foreground"
                )}
              >
                <LayoutList className="w-4 h-4" /> List
              </button>
              <button
                onClick={() => setViewMode("map")}
                className={cn(
                  "flex items-center gap-1.5 px-3 py-1.5 rounded-md text-sm font-medium transition-colors",
                  viewMode === "map" ? "bg-white text-foreground shadow-sm" : "text-muted-foreground hover:text-foreground"
                )}
              >
                <Map className="w-4 h-4" /> Map
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* Search + filters bar */}
      <div className="bg-white border-b z-20">
        <div className="container mx-auto px-4 py-3">
          {/* Search row */}
          <div className="flex flex-col md:flex-row gap-3 mb-3 items-end">
            <div className="flex-1 min-w-0">
              <div className="relative">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                <Input
                  placeholder="Search city, locality, landmark…"
                  className="pl-9 h-10"
                  value={inputCity}
                  onChange={e => setInputCity(e.target.value)}
                  onKeyDown={e => { if (e.key === "Enter") setSearchCity(inputCity); }}
                />
              </div>
            </div>
            <div className="w-full md:w-40">
              <Select value={propertyType} onValueChange={setPropertyType}>
                <SelectTrigger className="h-10">
                  <SelectValue placeholder="All Types" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Types</SelectItem>
                  <SelectItem value="apartment">Apartment</SelectItem>
                  <SelectItem value="villa">Villa</SelectItem>
                  <SelectItem value="plot">Plot</SelectItem>
                  <SelectItem value="commercial">Commercial</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="w-full md:w-40">
              <Select value={sortBy} onValueChange={setSortBy}>
                <SelectTrigger className="h-10">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="newest">Newest First</SelectItem>
                  <SelectItem value="price_asc">Price: Low → High</SelectItem>
                  <SelectItem value="price_desc">Price: High → Low</SelectItem>
                  <SelectItem value="area_desc">Largest Area</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <Button className="h-10 px-5 shrink-0" onClick={() => setSearchCity(inputCity)}>
              <Search className="w-4 h-4 mr-1.5" /> Search
            </Button>
          </div>

          {/* Filter chips */}
          <div className="flex flex-wrap gap-2 items-center">
            <span className="text-xs text-muted-foreground font-semibold hidden sm:block">BHK:</span>
            {BHK_OPTIONS.map(b => (
              <button key={b} onClick={() => setBhk(bhk === b ? null : b)}
                className={cn("px-3 py-1 rounded-full text-xs font-semibold border transition-colors",
                  bhk === b ? "bg-primary text-white border-primary" : "bg-white border-border hover:border-primary")}>
                {b} BHK
              </button>
            ))}
            <span className="text-xs text-muted-foreground font-semibold hidden sm:block ml-1">Budget:</span>
            {BUDGET_OPTIONS.map(b => (
              <button key={b.label} onClick={() => setBudget(budget?.label === b.label ? null : b)}
                className={cn("px-3 py-1 rounded-full text-xs font-semibold border transition-colors",
                  budget?.label === b.label ? "bg-primary text-white border-primary" : "bg-white border-border hover:border-primary")}>
                {b.label}
              </button>
            ))}
            <button onClick={() => setNoBroker(!noBroker)}
              className={cn("flex items-center gap-1 px-3 py-1 rounded-full text-xs font-semibold border transition-colors",
                noBroker ? "bg-green-600 text-white border-green-600" : "bg-white border-border hover:border-green-500")}>
              <BadgeCheck className="w-3.5 h-3.5" /> No Broker
            </button>
            <Select value={status} onValueChange={setStatus}>
              <SelectTrigger className="h-7 w-auto text-xs rounded-full px-3 bg-white border-border">
                <SelectValue placeholder="Status" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Status</SelectItem>
                <SelectItem value="verified">Verified Only</SelectItem>
                <SelectItem value="pending_verification">Pending</SelectItem>
              </SelectContent>
            </Select>
            {activeFilters.length > 0 && (
              <button onClick={clearAll} className="flex items-center gap-1 text-xs text-destructive font-semibold px-2 py-1 rounded-full border border-destructive/30 hover:bg-destructive/5">
                <X className="w-3 h-3" /> Clear
              </button>
            )}
          </div>
        </div>
      </div>

      {/* Results count */}
      <div className="container mx-auto px-4 py-2 flex items-center justify-between">
        <p className="text-sm text-muted-foreground">
          {isLoading ? "Loading…" : `${properties.length} propert${properties.length === 1 ? "y" : "ies"} found`}
          {searchCity && ` in ${searchCity}`}
        </p>
        {noBroker && (
          <Badge className="bg-green-100 text-green-800 border-green-200 text-xs">
            <BadgeCheck className="w-3 h-3 mr-1" /> Owner Listings Only
          </Badge>
        )}
      </div>

      {/* ── Main content area ── */}
      {isMapView ? (
        /* ── MAP VIEW: split panel ── */
        <div className="flex flex-1 overflow-hidden" style={{ height: "calc(100vh - 200px)" }}>
          {/* Left: scrollable property list */}
          <div className="w-full md:w-[380px] lg:w-[420px] xl:w-[460px] shrink-0 overflow-y-auto bg-white border-r">
            {isLoading ? (
              <div className="p-3 space-y-3">
                {[...Array(5)].map((_, i) => (
                  <div key={i} className="border rounded-xl overflow-hidden">
                    <Skeleton className="h-32 w-full rounded-none" />
                    <div className="p-3">
                      <Skeleton className="h-4 w-full mb-2" />
                      <Skeleton className="h-3 w-2/3" />
                    </div>
                  </div>
                ))}
              </div>
            ) : properties.length === 0 ? (
              <div className="flex flex-col items-center justify-center h-64 p-6 text-center">
                <Search className="w-10 h-10 text-muted-foreground/30 mb-3" />
                <p className="font-medium mb-1">No properties found</p>
                <p className="text-sm text-muted-foreground mb-4">Try adjusting your filters.</p>
                <Button variant="outline" size="sm" onClick={clearAll}>Clear filters</Button>
              </div>
            ) : (
              <div className="p-3 space-y-3">
                {properties.map(p => (
                  <Link key={p.id} href={`/properties/${p.id}`}>
                    <div
                      className={cn(
                        "border rounded-xl overflow-hidden cursor-pointer transition-all hover:shadow-md hover:border-primary/40",
                        activeId === p.id && "border-primary shadow-md ring-1 ring-primary/20"
                      )}
                      onMouseEnter={() => setActiveId(p.id)}
                      onMouseLeave={() => setActiveId(null)}
                    >
                      <div className="flex gap-0">
                        {/* Thumbnail */}
                        <div className="w-28 h-24 shrink-0 bg-muted relative">
                          {p.imageUrl ? (
                            <img src={p.imageUrl} alt={p.title} className="w-full h-full object-cover" />
                          ) : (
                            <div className="w-full h-full flex items-center justify-center text-muted-foreground/40 text-xs">No photo</div>
                          )}
                          {p.locationVerified && (
                            <span className="absolute top-1 left-1 text-[9px] font-bold bg-green-600 text-white px-1.5 py-0.5 rounded-full">✓ Verified</span>
                          )}
                        </div>
                        {/* Info */}
                        <div className="p-3 flex-1 min-w-0">
                          <p className="font-semibold text-sm line-clamp-1 mb-0.5">{p.title}</p>
                          <p className="text-xs text-muted-foreground mb-1.5">{p.city}, {p.state}</p>
                          <div className="flex items-center gap-2 text-xs text-muted-foreground mb-2">
                            <span className="flex items-center gap-0.5"><Bed className="w-3 h-3" /> {p.bedrooms}</span>
                            <span className="flex items-center gap-0.5"><Bath className="w-3 h-3" /> {p.bathrooms}</span>
                            <span className="flex items-center gap-0.5"><Square className="w-3 h-3" /> {p.areasqft}sqft</span>
                          </div>
                          <div className="flex items-end gap-2">
                            <span className="font-bold text-sm text-primary">{formatIndianPrice(p.listedPrice)}</span>
                            {p.actualVisitPrice && p.actualVisitPrice !== p.listedPrice && (
                              <span className="text-xs text-destructive">Visit: {formatIndianPrice(p.actualVisitPrice)}</span>
                            )}
                          </div>
                        </div>
                      </div>
                    </div>
                  </Link>
                ))}
              </div>
            )}
          </div>

          {/* Right: sticky map */}
          <div className="flex-1 relative">
            <Suspense fallback={
              <div className="w-full h-full bg-muted flex items-center justify-center">
                <div className="text-center">
                  <Map className="w-10 h-10 text-muted-foreground/40 mx-auto mb-2" />
                  <p className="text-sm text-muted-foreground">Loading map…</p>
                </div>
              </div>
            }>
              <PropertyMap
                properties={properties}
                city={searchCity}
                activeId={activeId}
                onHover={setActiveId}
              />
            </Suspense>
            {/* Map attribution overlay hint */}
            <div className="absolute top-3 left-3 z-10 bg-white/90 backdrop-blur rounded-lg px-3 py-2 text-xs text-muted-foreground shadow border pointer-events-none">
              🗺 {properties.length} propert{properties.length === 1 ? "y" : "ies"} on map • Click a pin to see details
            </div>
          </div>
        </div>
      ) : (
        /* ── LIST VIEW ── */
        <div className="container mx-auto px-4 py-5">
          {isLoading ? (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-5">
              {[...Array(8)].map((_, i) => (
                <div key={i} className="bg-white border rounded-xl overflow-hidden h-[440px]">
                  <Skeleton className="h-48 w-full rounded-none" />
                  <div className="p-5">
                    <Skeleton className="h-4 w-24 mb-3" />
                    <Skeleton className="h-5 w-full mb-2" />
                    <Skeleton className="h-4 w-2/3 mb-5" />
                    <Skeleton className="h-16 w-full" />
                  </div>
                </div>
              ))}
            </div>
          ) : properties.length > 0 ? (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-5">
              {properties.map(p => <PropertyCard key={p.id} property={p} />)}
            </div>
          ) : (
            <div className="text-center py-32 bg-white rounded-xl border border-dashed">
              <Search className="w-12 h-12 mx-auto text-muted-foreground/30 mb-4" />
              <h3 className="text-xl font-semibold mb-2">No properties found</h3>
              <p className="text-muted-foreground max-w-sm mx-auto mb-6">
                Try adjusting your filters or searching a different city.
              </p>
              <Button variant="outline" onClick={clearAll}>
                <X className="w-4 h-4 mr-2" /> Clear all filters
              </Button>
            </div>
          )}
        </div>
      )}
    </div>
  );
}
