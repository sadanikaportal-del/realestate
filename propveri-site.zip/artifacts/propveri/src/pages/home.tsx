import { useState } from "react";
import { Link, useLocation } from "wouter";
import { useGetPropertyStats, useListFeaturedProperties } from "@workspace/api-client-react";
import {
  Building2, ShieldCheck, TrendingUp, CheckCircle2, Search, MapPin,
  Home as HomeIcon, Briefcase, Users, ArrowRight, Star, Truck, FileText, Paintbrush,
  Wrench, BadgeCheck, PhoneCall, HandshakeIcon, ChevronRight
} from "lucide-react";
import { formatIndianPrice } from "@/lib/utils";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent } from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { PropertyCard } from "@/components/property-card";
import { cn } from "@/lib/utils";

const CITIES = [
  { name: "Mumbai", state: "MH" },
  { name: "Bangalore", state: "KA" },
  { name: "Delhi", state: "DL" },
  { name: "Hyderabad", state: "TS" },
  { name: "Chennai", state: "TN" },
  { name: "Pune", state: "MH" },
  { name: "Gurgaon", state: "HR" },
  { name: "Nashik", state: "MH" },
];

const SERVICES = [
  { icon: Truck, label: "Packers & Movers", desc: "Verified movers at best prices", color: "bg-blue-50 text-blue-600" },
  { icon: FileText, label: "Rental Agreement", desc: "Legal e-stamped agreements", color: "bg-green-50 text-green-600" },
  { icon: HandshakeIcon, label: "Legal Services", desc: "Property lawyers & advice", color: "bg-purple-50 text-purple-600" },
  { icon: Building2, label: "Home Loans", desc: "Best rates from top banks", color: "bg-orange-50 text-orange-600" },
  { icon: Paintbrush, label: "Interior Design", desc: "Transform your new home", color: "bg-pink-50 text-pink-600" },
  { icon: Wrench, label: "Home Repairs", desc: "Plumbers, electricians & more", color: "bg-teal-50 text-teal-600" },
  { icon: BadgeCheck, label: "Background Check", desc: "Verify tenants & owners", color: "bg-indigo-50 text-indigo-600" },
  { icon: PhoneCall, label: "Property Mgmt", desc: "Hassle-free ownership", color: "bg-red-50 text-red-600" },
];

type ListingMode = "buy" | "rent" | "pg";

export default function Home() {
  const [, navigate] = useLocation();
  const [mode, setMode] = useState<ListingMode>("buy");
  const [searchCity, setSearchCity] = useState("");

  const { data: stats, isLoading: statsLoading } = useGetPropertyStats();
  const { data: featured, isLoading: featuredLoading } = useListFeaturedProperties();

  function handleSearch() {
    if (searchCity.trim()) {
      navigate(`/properties?city=${encodeURIComponent(searchCity.trim())}&mode=${mode}`);
    } else {
      navigate(`/properties?mode=${mode}`);
    }
  }

  function handleCityClick(city: string) {
    navigate(`/properties?city=${encodeURIComponent(city)}&mode=${mode}`);
  }

  return (
    <div className="flex flex-col min-h-screen">

      {/* ── Hero ── */}
      <section className="relative bg-primary text-primary-foreground overflow-hidden">
        <div className="absolute inset-0 bg-[url('https://images.unsplash.com/photo-1600596542815-ffad4c1539a9?q=80&w=2075')] bg-cover bg-center opacity-10" />

        <div className="container mx-auto px-4 pt-16 pb-20 relative z-10">
          <div className="max-w-3xl mx-auto text-center">
            <Badge variant="secondary" className="mb-5 bg-white/10 text-white border-white/20 backdrop-blur-md">
              <ShieldCheck className="w-3.5 h-3.5 mr-1.5" /> India's Most Honest Real Estate Platform
            </Badge>
            <h1 className="text-4xl md:text-6xl font-bold tracking-tight mb-4 leading-tight">
              Find Your Dream Home.<br />
              <span className="text-yellow-300">No Broker. No Hidden Fees.</span>
            </h1>
            <p className="text-lg text-white/80 mb-8 max-w-xl mx-auto">
              Direct from owners. Verified locations. Transparent pricing. Every listing is real.
            </p>

            {/* Buy / Rent / PG tabs */}
            <div className="bg-white rounded-2xl shadow-2xl overflow-hidden max-w-2xl mx-auto">
              <div className="flex border-b">
                {(["buy", "rent", "pg"] as ListingMode[]).map(m => (
                  <button
                    key={m}
                    onClick={() => setMode(m)}
                    className={cn(
                      "flex-1 py-3.5 text-sm font-semibold uppercase tracking-wide transition-colors",
                      mode === m
                        ? "bg-primary text-white"
                        : "text-gray-500 hover:bg-gray-50"
                    )}
                  >
                    {m === "buy" ? "Buy" : m === "rent" ? "Rent" : "PG / Co-living"}
                  </button>
                ))}
              </div>
              <div className="p-4 flex gap-3">
                <div className="relative flex-1">
                  <MapPin className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
                  <Input
                    value={searchCity}
                    onChange={e => setSearchCity(e.target.value)}
                    onKeyDown={e => e.key === "Enter" && handleSearch()}
                    placeholder="Search city, locality, landmark…"
                    className="pl-9 h-12 text-base text-foreground border-gray-200 focus:border-primary"
                  />
                </div>
                <Button onClick={handleSearch} className="h-12 px-6 text-base shrink-0">
                  <Search className="w-4 h-4 mr-2" /> Search
                </Button>
              </div>
            </div>

            {/* Popular Cities */}
            <div className="mt-5 flex flex-wrap items-center justify-center gap-2">
              <span className="text-white/60 text-sm">Popular:</span>
              {CITIES.map(c => (
                <button
                  key={c.name}
                  onClick={() => handleCityClick(c.name)}
                  className="text-sm text-white/80 hover:text-white bg-white/10 hover:bg-white/20 px-3 py-1 rounded-full transition-colors"
                >
                  {c.name}
                </button>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* ── Trust Badges ── */}
      <section className="bg-white border-b py-4">
        <div className="container mx-auto px-4">
          <div className="flex flex-wrap justify-center gap-x-10 gap-y-3">
            {[
              { icon: BadgeCheck, label: "100% Verified Listings" },
              { icon: Users, label: "Direct Owner Contact" },
              { icon: ShieldCheck, label: "Zero Brokerage" },
              { icon: TrendingUp, label: "Price Transparency" },
            ].map(({ icon: Icon, label }) => (
              <div key={label} className="flex items-center gap-2 text-sm font-medium text-muted-foreground">
                <Icon className="w-4 h-4 text-primary" />
                {label}
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* ── Stats ── */}
      <section className="py-14 bg-muted/30 border-b">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-6 text-center">
            {[
              { value: statsLoading ? null : stats?.totalListings || 0, label: "Properties Listed", color: "text-primary" },
              { value: statsLoading ? null : stats?.verifiedListings || 0, label: "Verified Locations", color: "text-green-600" },
              { value: statsLoading ? null : stats?.totalCities || 0, label: "Cities Covered", color: "text-primary" },
              { value: statsLoading ? null : (stats?.avgListedPrice ? formatIndianPrice(stats.avgListedPrice) : "0"), label: "Avg. Property Price", color: "text-primary" },
            ].map(({ value, label, color }) => (
              <div key={label} className="bg-white rounded-xl p-6 shadow-sm border">
                <div className={cn("text-3xl md:text-4xl font-bold mb-1", color)}>
                  {value === null ? <Skeleton className="h-10 w-20 mx-auto" /> : value}
                </div>
                <p className="text-xs font-semibold text-muted-foreground uppercase tracking-wider">{label}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* ── Featured Properties ── */}
      <section className="py-20 bg-white">
        <div className="container mx-auto px-4">
          <div className="flex justify-between items-end mb-10">
            <div>
              <p className="text-primary text-sm font-semibold uppercase tracking-wider mb-1">Handpicked for You</p>
              <h2 className="text-3xl font-bold tracking-tight">Featured Properties</h2>
              <p className="text-muted-foreground mt-1 max-w-xl">Fully verified listings with complete price transparency and direct owner contact.</p>
            </div>
            <Link href="/properties">
              <Button variant="outline" className="hidden sm:flex items-center gap-1">
                View All <ChevronRight className="w-4 h-4" />
              </Button>
            </Link>
          </div>

          {featuredLoading ? (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {[1, 2, 3].map(i => (
                <Card key={i} className="overflow-hidden h-[480px]">
                  <Skeleton className="h-52 w-full rounded-none" />
                  <CardContent className="p-5">
                    <Skeleton className="h-4 w-24 mb-3" />
                    <Skeleton className="h-6 w-full mb-2" />
                    <Skeleton className="h-4 w-2/3 mb-6" />
                    <Skeleton className="h-16 w-full mt-auto" />
                  </CardContent>
                </Card>
              ))}
            </div>
          ) : featured && featured.length > 0 ? (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {featured.slice(0, 6).map(p => <PropertyCard key={p.id} property={p} />)}
            </div>
          ) : (
            <div className="text-center py-16 bg-muted/30 rounded-xl border border-dashed">
              <Building2 className="w-12 h-12 mx-auto text-muted-foreground/30 mb-4" />
              <p className="text-muted-foreground">No featured properties yet.</p>
            </div>
          )}

          <div className="mt-8 text-center sm:hidden">
            <Link href="/properties"><Button variant="outline" className="w-full">View All Properties</Button></Link>
          </div>
        </div>
      </section>

      {/* ── Browse by Category ── */}
      <section className="py-16 bg-muted/20 border-y">
        <div className="container mx-auto px-4">
          <h2 className="text-2xl font-bold mb-8 text-center">Browse by Type</h2>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            {[
              { icon: HomeIcon, label: "Apartments", type: "apartment", count: "Most Popular" },
              { icon: Building2, label: "Villas", type: "villa", count: "Premium Picks" },
              { icon: MapPin, label: "Plots", type: "plot", count: "Best Investment" },
              { icon: Briefcase, label: "Commercial", type: "commercial", count: "For Business" },
            ].map(({ icon: Icon, label, type, count }) => (
              <Link key={type} href={`/properties?type=${type}`}>
                <div className="bg-white border rounded-xl p-6 flex flex-col items-center text-center hover:border-primary hover:shadow-md transition-all cursor-pointer group">
                  <div className="w-14 h-14 rounded-full bg-primary/10 flex items-center justify-center mb-3 group-hover:bg-primary group-hover:text-white transition-colors text-primary">
                    <Icon className="w-7 h-7" />
                  </div>
                  <p className="font-semibold">{label}</p>
                  <p className="text-xs text-muted-foreground mt-0.5">{count}</p>
                </div>
              </Link>
            ))}
          </div>
        </div>
      </section>

      {/* ── Home Services (NoBroker style) ── */}
      <section className="py-20 bg-white">
        <div className="container mx-auto px-4">
          <div className="text-center mb-12">
            <p className="text-primary text-sm font-semibold uppercase tracking-wider mb-1">One-Stop Solution</p>
            <h2 className="text-3xl font-bold tracking-tight mb-2">Home Services</h2>
            <p className="text-muted-foreground max-w-lg mx-auto">Everything you need before, during, and after moving — all in one place.</p>
          </div>

          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            {SERVICES.map(({ icon: Icon, label, desc, color }) => (
              <Link key={label} href="/services">
                <div className="border rounded-xl p-5 hover:shadow-md hover:border-primary/30 transition-all cursor-pointer group bg-white">
                  <div className={cn("w-11 h-11 rounded-lg flex items-center justify-center mb-3", color)}>
                    <Icon className="w-5 h-5" />
                  </div>
                  <p className="font-semibold text-sm mb-1">{label}</p>
                  <p className="text-xs text-muted-foreground leading-relaxed">{desc}</p>
                  <div className="flex items-center gap-1 mt-3 text-xs text-primary font-medium opacity-0 group-hover:opacity-100 transition-opacity">
                    Learn more <ArrowRight className="w-3 h-3" />
                  </div>
                </div>
              </Link>
            ))}
          </div>
        </div>
      </section>

      {/* ── How It Works ── */}
      <section className="py-20 bg-primary text-white">
        <div className="container mx-auto px-4 text-center">
          <p className="text-yellow-300 text-sm font-semibold uppercase tracking-wider mb-2">Simple Process</p>
          <h2 className="text-3xl font-bold mb-14">How PropVeri Works</h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-10 max-w-4xl mx-auto relative">
            <div className="hidden md:block absolute top-8 left-1/4 right-1/4 h-px border-t-2 border-dashed border-white/20" />
            {[
              { step: "01", title: "Search & Filter", desc: "Browse verified listings by city, type, budget, and BHK. Use our No Broker filter for direct owner deals." },
              { step: "02", title: "See Real Prices", desc: "Every listing shows both the advertised price and the actual price buyers are quoted at the property." },
              { step: "03", title: "Contact & Close", desc: "Connect directly with the owner or agent. No middlemen, no hidden brokerage, no surprises." },
            ].map(({ step, title, desc }) => (
              <div key={step} className="flex flex-col items-center">
                <div className="w-16 h-16 rounded-full bg-white/15 text-white font-bold text-xl flex items-center justify-center mb-5 border-2 border-white/20">
                  {step}
                </div>
                <h3 className="text-lg font-bold mb-2">{title}</h3>
                <p className="text-white/70 text-sm leading-relaxed">{desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* ── PropVeri Promise ── */}
      <section className="py-20 bg-white">
        <div className="container mx-auto px-4 text-center">
          <h2 className="text-3xl font-bold tracking-tight mb-14">The PropVeri Promise</h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-10 max-w-5xl mx-auto">
            {[
              { icon: ShieldCheck, title: "Location Verified", desc: "We cross-check GPS coordinates against the listed address. What you see on the map is where the property actually is." },
              { icon: TrendingUp, title: "Price Transparency", desc: "Displayed price vs actual visit price — both shown side by side. Our Price Discrepancy Alert warns you before you visit." },
              { icon: CheckCircle2, title: "Zero Brokerage", desc: "Owner listings are clearly marked. Contact directly. No commission charged to buyers or tenants." },
            ].map(({ icon: Icon, title, desc }) => (
              <div key={title} className="flex flex-col items-center">
                <div className="w-16 h-16 rounded-full bg-primary/10 flex items-center justify-center mb-5 text-primary">
                  <Icon className="w-8 h-8" />
                </div>
                <h3 className="text-xl font-bold mb-3">{title}</h3>
                <p className="text-muted-foreground leading-relaxed">{desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* ── CTA Banner ── */}
      <section className="py-16 bg-muted/30 border-t">
        <div className="container mx-auto px-4 text-center">
          <h2 className="text-2xl md:text-3xl font-bold mb-3">Ready to list your property?</h2>
          <p className="text-muted-foreground mb-8 max-w-lg mx-auto">Get your property in front of thousands of serious buyers and tenants. Verified. Transparent. Free to start.</p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Link href="/list-property">
              <Button size="lg" className="h-12 px-8">List for Free</Button>
            </Link>
            <Link href="/packages">
              <Button size="lg" variant="outline" className="h-12 px-8">View Packages</Button>
            </Link>
          </div>
        </div>
      </section>
    </div>
  );
}
