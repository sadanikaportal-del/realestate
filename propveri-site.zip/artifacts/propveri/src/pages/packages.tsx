import { useEffect, useState } from "react";
import { useListPackages, usePurchasePackage } from "@workspace/api-client-react";
import { CheckCircle2, Package as PackageIcon, IndianRupee, ShieldCheck, CreditCard, AlertTriangle, Loader2 } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardFooter, CardHeader } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { cn } from "@/lib/utils";
import { useAuth } from "@/lib/auth-context";

declare global {
  interface Window {
    Razorpay: any;
  }
}

function loadRazorpayScript(): Promise<boolean> {
  return new Promise(resolve => {
    if (window.Razorpay) { resolve(true); return; }
    const script = document.createElement("script");
    script.src = "https://checkout.razorpay.com/v1/checkout.js";
    script.onload = () => resolve(true);
    script.onerror = () => resolve(false);
    document.body.appendChild(script);
  });
}

export default function Packages() {
  const { toast } = useToast();
  const { user } = useAuth();
  const { data: packages, isLoading } = useListPackages();
  const purchasePackage = usePurchasePackage();
  const [razorpayConfigured, setRazorpayConfigured] = useState<boolean | null>(null);
  const [payingId, setPayingId] = useState<number | null>(null);

  useEffect(() => {
    fetch("/api/payments/config")
      .then(r => r.json())
      .then(d => setRazorpayConfigured(d.configured))
      .catch(() => setRazorpayConfigured(false));
  }, []);

  const handlePurchase = async (pkg: { id: number; name: string; price: number }) => {
    setPayingId(pkg.id);

    try {
      if (!razorpayConfigured) {
        // Demo mode — skip payment, directly activate
        await purchasePackage.mutateAsync({
          data: { userId: user?.id ?? 1, packageId: pkg.id },
        });
        toast({
          title: "Package Activated (Demo)",
          description: `${pkg.name} is now active. Add Razorpay keys for real payments.`,
        });
        setPayingId(null);
        return;
      }

      // Step 1 — create Razorpay order on backend
      const orderRes = await fetch("/api/payments/create-order", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ amount: pkg.price, packageId: pkg.id }),
      });
      if (!orderRes.ok) throw new Error("Failed to create payment order");
      const order = await orderRes.json();

      // Step 2 — load Razorpay SDK
      const loaded = await loadRazorpayScript();
      if (!loaded) throw new Error("Could not load Razorpay checkout");

      // Step 3 — open checkout
      await new Promise<void>((resolve, reject) => {
        const rzp = new window.Razorpay({
          key: order.keyId,
          amount: order.amount,
          currency: order.currency,
          name: "PropVeri",
          description: pkg.name,
          image: "/logo.png",
          order_id: order.orderId,
          prefill: {
            name: user?.name ?? "",
            email: user?.email ?? "",
            contact: user?.phone ?? "",
          },
          theme: { color: "#1e3a5f" },
          handler: async (response: any) => {
            try {
              // Step 4 — verify signature on backend
              const verifyRes = await fetch("/api/payments/verify", {
                method: "POST",
                headers: { "Content-Type": "application/json" },
                body: JSON.stringify({
                  razorpay_order_id: response.razorpay_order_id,
                  razorpay_payment_id: response.razorpay_payment_id,
                  razorpay_signature: response.razorpay_signature,
                  packageId: pkg.id,
                  userId: user?.id ?? 1,
                }),
              });

              if (!verifyRes.ok) throw new Error("Payment verification failed");

              // Step 5 — activate package in DB
              await purchasePackage.mutateAsync({
                data: { userId: user?.id ?? 1, packageId: pkg.id },
              });

              toast({
                title: "Payment Successful 🎉",
                description: `${pkg.name} is now active. Start listing properties!`,
              });
              resolve();
            } catch (err: any) {
              reject(err);
            }
          },
          modal: {
            ondismiss: () => reject(new Error("dismissed")),
          },
        });
        rzp.open();
      });
    } catch (err: any) {
      if (err.message !== "dismissed") {
        toast({
          title: "Payment Failed",
          description: err.message || "Something went wrong. Please try again.",
          variant: "destructive",
        });
      }
    } finally {
      setPayingId(null);
    }
  };

  return (
    <div className="container mx-auto px-4 py-16 max-w-6xl">
      <div className="text-center mb-16 max-w-2xl mx-auto">
        <Badge variant="outline" className="mb-4 text-primary border-primary/20 bg-primary/5">
          <PackageIcon className="w-3.5 h-3.5 mr-1.5" /> Pricing Plans
        </Badge>
        <h1 className="text-4xl md:text-5xl font-serif font-bold tracking-tight mb-6">Simple, transparent pricing</h1>
        <p className="text-lg text-muted-foreground">
          Choose a plan that fits your needs. Just like mobile recharges — straightforward with no hidden fees.
        </p>

        {/* Razorpay status banner */}
        {razorpayConfigured === false && (
          <div className="mt-6 flex items-center gap-2 justify-center text-sm text-amber-700 bg-amber-50 border border-amber-200 rounded-xl px-4 py-2.5">
            <AlertTriangle className="w-4 h-4 shrink-0" />
            <span>Demo mode — Razorpay keys not configured. Payments are simulated.</span>
          </div>
        )}
        {razorpayConfigured === true && (
          <div className="mt-6 flex items-center gap-2 justify-center text-sm text-green-700 bg-green-50 border border-green-200 rounded-xl px-4 py-2.5">
            <CheckCircle2 className="w-4 h-4 shrink-0" />
            <span>Razorpay payments active — secure checkout enabled</span>
          </div>
        )}
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-8 max-w-5xl mx-auto">
        {isLoading ? (
          <>
            {[1, 2, 3].map(i => (
              <Card key={i} className="flex flex-col h-[500px]">
                <CardHeader>
                  <Skeleton className="h-6 w-1/2 mb-2" />
                  <Skeleton className="h-10 w-3/4" />
                </CardHeader>
                <CardContent className="flex-1 space-y-4">
                  {[1, 2, 3, 4].map(j => <Skeleton key={j} className="h-4 w-full" />)}
                </CardContent>
                <CardFooter>
                  <Skeleton className="h-12 w-full" />
                </CardFooter>
              </Card>
            ))}
          </>
        ) : packages && packages.length > 0 ? (
          packages.map(pkg => (
            <Card
              key={pkg.id}
              className={cn(
                "flex flex-col relative transition-all duration-300",
                pkg.popular
                  ? "border-primary shadow-lg scale-105 z-10 bg-card"
                  : "border-border/60 hover:border-primary/30 hover:shadow-md bg-card"
              )}
            >
              {pkg.popular && (
                <div className="absolute -top-4 inset-x-0 flex justify-center">
                  <Badge className="bg-primary text-primary-foreground font-semibold px-4 py-1 shadow-sm uppercase tracking-wider text-xs">
                    Most Popular
                  </Badge>
                </div>
              )}

              <CardHeader className={cn("text-center pb-8 pt-8", pkg.popular && "bg-primary/5 rounded-t-xl")}>
                <h3 className="text-xl font-medium text-muted-foreground mb-4">{pkg.name}</h3>
                <div className="flex items-center justify-center font-bold">
                  <IndianRupee className="w-6 h-6 text-foreground mr-1" />
                  <span className="text-5xl text-foreground font-serif">{pkg.price}</span>
                </div>
                <p className="text-sm text-muted-foreground mt-2">for {pkg.durationDays} days</p>
              </CardHeader>

              <CardContent className="flex-1 px-6 pt-6">
                <div className="mb-6 flex items-center gap-3 bg-secondary/50 p-3 rounded-lg">
                  <ShieldCheck className="w-5 h-5 text-primary" />
                  <span className="font-medium">{pkg.listingsAllowed} Property Listings</span>
                </div>

                <ul className="space-y-4">
                  {pkg.features.map((feature, idx) => (
                    <li key={idx} className="flex items-start gap-3">
                      <CheckCircle2 className="w-5 h-5 text-green-500 shrink-0 mt-0.5" />
                      <span className="text-sm text-muted-foreground">{feature}</span>
                    </li>
                  ))}
                </ul>
              </CardContent>

              <CardFooter className="px-6 pb-8 pt-4 flex flex-col gap-2">
                <Button
                  className={cn("w-full h-12 text-base gap-2", !pkg.popular && "bg-secondary text-foreground hover:bg-secondary/80")}
                  onClick={() => handlePurchase({ id: pkg.id, name: pkg.name, price: pkg.price })}
                  disabled={payingId === pkg.id}
                >
                  {payingId === pkg.id ? (
                    <><Loader2 className="w-4 h-4 animate-spin" /> Processing…</>
                  ) : razorpayConfigured ? (
                    <><CreditCard className="w-4 h-4" /> Pay with Razorpay</>
                  ) : (
                    "Subscribe Now"
                  )}
                </Button>
                {razorpayConfigured && (
                  <p className="text-[11px] text-center text-muted-foreground">
                    Secured by <span className="font-semibold text-[#528FF0]">Razorpay</span> · UPI, Cards, Net Banking accepted
                  </p>
                )}
              </CardFooter>
            </Card>
          ))
        ) : (
          <div className="col-span-3 text-center py-20">
            <p className="text-muted-foreground">No packages available at the moment.</p>
          </div>
        )}
      </div>

      <div className="mt-20 bg-muted/30 rounded-2xl p-8 max-w-4xl mx-auto text-center border border-dashed border-border/60">
        <h3 className="text-xl font-bold mb-3">Enterprise Needs?</h3>
        <p className="text-muted-foreground mb-6">Are you a large developer with more than 50 properties to list? Contact us for custom enterprise pricing with dedicated support.</p>
        <Button variant="outline">Contact Sales Team</Button>
      </div>
    </div>
  );
}
