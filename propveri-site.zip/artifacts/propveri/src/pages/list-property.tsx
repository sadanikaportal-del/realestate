import { useState, useMemo } from "react";
import { useLocation } from "wouter";
import { useCreateProperty } from "@workspace/api-client-react";
import {
  Building2, MapPin, IndianRupee, Image as ImageIcon,
  Loader2, CheckCircle2, AlertTriangle, ShieldCheck,
  ChevronRight, ChevronLeft, BadgeCheck, Eye, Bed, Bath, Square
} from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { cn } from "@/lib/utils";

/* ── City → coordinates lookup ─────────────────────────────── */
const CITY_COORDS: Record<string, { lat: number; lng: number; state: string }> = {
  Mumbai:    { lat: 19.076, lng: 72.877, state: "Maharashtra" },
  Delhi:     { lat: 28.613, lng: 77.209, state: "Delhi" },
  Bangalore: { lat: 12.971, lng: 77.594, state: "Karnataka" },
  Hyderabad: { lat: 17.385, lng: 78.486, state: "Telangana" },
  Chennai:   { lat: 13.082, lng: 80.270, state: "Tamil Nadu" },
  Kolkata:   { lat: 22.572, lng: 88.363, state: "West Bengal" },
  Pune:      { lat: 18.520, lng: 73.856, state: "Maharashtra" },
  Ahmedabad: { lat: 23.022, lng: 72.571, state: "Gujarat" },
  Jaipur:    { lat: 26.912, lng: 75.787, state: "Rajasthan" },
  Lucknow:   { lat: 26.846, lng: 80.946, state: "Uttar Pradesh" },
  Surat:     { lat: 21.170, lng: 72.831, state: "Gujarat" },
  Chandigarh:{ lat: 30.733, lng: 76.779, state: "Punjab" },
  Gurgaon:   { lat: 28.459, lng: 77.026, state: "Haryana" },
  Noida:     { lat: 28.535, lng: 77.391, state: "Uttar Pradesh" },
  Kochi:     { lat: 9.931,  lng: 76.267, state: "Kerala" },
};

const SAMPLE_IMAGES = [
  { url: "https://images.unsplash.com/photo-1545324418-cc1a3fa10c00?w=800&q=80", label: "Modern Apartment" },
  { url: "https://images.unsplash.com/photo-1600596542815-ffad4c1539a9?w=800&q=80", label: "Luxury Villa" },
  { url: "https://images.unsplash.com/photo-1600585154340-be6161a56a0c?w=800&q=80", label: "Contemporary Home" },
  { url: "https://images.unsplash.com/photo-1560448204-e02f11c3d0e2?w=800&q=80", label: "City Flat" },
  { url: "https://images.unsplash.com/photo-1484154218962-a197022b5858?w=800&q=80", label: "Interior View" },
  { url: "https://images.unsplash.com/photo-1512917774080-9991f1c4c750?w=800&q=80", label: "Premium Property" },
];

const AMENITIES = [
  "Swimming Pool", "Gym / Fitness Centre", "24×7 Security", "Power Backup",
  "Covered Parking", "Clubhouse", "Children's Play Area", "Lift / Elevator",
  "Intercom", "CCTV", "Garden / Park", "Visitor Parking",
];

const LISTING_TYPES = [
  { id: "sale", label: "For Sale", icon: "🏠" },
  { id: "rent", label: "For Rent", icon: "🔑" },
  { id: "pg", label: "PG / Co-living", icon: "🏨" },
];

type FormState = {
  /* step 1 */
  title: string; type: string; areasqft: string; bedrooms: string; bathrooms: string;
  description: string; furnishing: string; facing: string; floor: string; amenities: string[];
  /* step 2 */
  listingType: string; listedPrice: string; actualVisitPrice: string;
  maintenanceCharges: string; availableFrom: string;
  /* step 3 */
  address: string; city: string; state: string; latitude: number; longitude: number;
  landmark: string;
  /* step 4 */
  imageUrl: string;
};

const INIT: FormState = {
  title: "", type: "", areasqft: "", bedrooms: "", bathrooms: "",
  description: "", furnishing: "unfurnished", facing: "", floor: "", amenities: [],
  listingType: "sale", listedPrice: "", actualVisitPrice: "", maintenanceCharges: "", availableFrom: "",
  address: "", city: "", state: "", latitude: 0, longitude: 0, landmark: "",
  imageUrl: "",
};

function fmtLakhs(v: string) {
  const n = parseFloat(v);
  if (!v || isNaN(n)) return "—";
  if (n >= 100) return `₹${(n / 100).toFixed(2)} Cr`;
  return `₹${n}L`;
}

const STEPS = [
  { n: 1, label: "Basic Info", icon: Building2 },
  { n: 2, label: "Pricing",    icon: IndianRupee },
  { n: 3, label: "Location",   icon: MapPin },
  { n: 4, label: "Photos",     icon: ImageIcon },
];

export default function ListProperty() {
  const [, navigate] = useLocation();
  const { toast } = useToast();
  const [step, setStep] = useState(1);
  const [form, setForm] = useState<FormState>(INIT);
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [isVerifying, setIsVerifying] = useState(false);
  const [locationVerified, setLocationVerified] = useState(false);
  const [published, setPublished] = useState<number | null>(null);

  const createProperty = useCreateProperty();

  function set(key: keyof FormState, val: string | string[]) {
    setForm(f => ({ ...f, [key]: val }));
    setErrors(e => { const n = { ...e }; delete n[key]; return n; });
  }

  function toggleAmenity(a: string) {
    setForm(f => ({
      ...f,
      amenities: f.amenities.includes(a) ? f.amenities.filter(x => x !== a) : [...f.amenities, a],
    }));
  }

  /* ── per-step validation ── */
  function validate(s: number): boolean {
    const e: Record<string, string> = {};
    if (s === 1) {
      if (!form.title || form.title.length < 5) e.title = "Title must be at least 5 characters";
      if (!form.type) e.type = "Select a property type";
      if (!form.areasqft || +form.areasqft <= 0) e.areasqft = "Enter valid area";
      if (!form.bedrooms) e.bedrooms = "Required";
      if (!form.bathrooms) e.bathrooms = "Required";
      if (!form.description || form.description.length < 20) e.description = "At least 20 characters";
    }
    if (s === 2) {
      if (!form.listedPrice || +form.listedPrice <= 0) e.listedPrice = "Enter a valid price";
      if (!form.actualVisitPrice || +form.actualVisitPrice <= 0) e.actualVisitPrice = "Enter a valid price";
    }
    if (s === 3) {
      if (!form.address) e.address = "Address is required";
      if (!form.city) e.city = "City is required";
      if (!locationVerified) e.location = "Please verify the location";
    }
    setErrors(e);
    return Object.keys(e).length === 0;
  }

  function nextStep() {
    if (!validate(step)) return;
    setStep(s => s + 1);
    window.scrollTo({ top: 0, behavior: "smooth" });
  }

  /* ── City autocomplete → fill coords ── */
  function handleCityChange(city: string) {
    set("city", city);
    const c = CITY_COORDS[city];
    if (c) {
      setForm(f => ({ ...f, city, state: c.state, latitude: c.lat, longitude: c.lng }));
      setLocationVerified(false);
    }
  }

  async function verifyLocation() {
    if (!form.city || !form.address) {
      setErrors(e => ({ ...e, location: "Fill address and city first" }));
      return;
    }
    setIsVerifying(true);
    setLocationVerified(false);
    await new Promise(r => setTimeout(r, 1800));
    const inIndia = form.latitude >= 8 && form.latitude <= 37 && form.longitude >= 68 && form.longitude <= 97;
    setIsVerifying(false);
    if (inIndia) {
      setLocationVerified(true);
      setErrors(e => { const n = { ...e }; delete n.location; return n; });
    } else {
      setErrors(e => ({ ...e, location: "Could not verify — try selecting a city from the list." }));
    }
  }

  /* ── Submit ── */
  async function publish() {
    if (!validate(step)) return;
    if (!form.imageUrl) {
      setErrors({ imageUrl: "Please provide or select a photo" });
      return;
    }
    try {
      const res = await createProperty.mutateAsync({
        data: {
          title: form.title,
          description: form.description,
          address: form.address,
          city: form.city,
          state: form.state,
          latitude: form.latitude,
          longitude: form.longitude,
          listedPrice: +form.listedPrice,
          actualVisitPrice: +form.actualVisitPrice,
          type: form.type,
          bedrooms: +form.bedrooms,
          bathrooms: +form.bathrooms,
          areasqft: +form.areasqft,
          imageUrl: form.imageUrl,
          ownerId: 1,
          areasgft: +form.areasqft,
        },
      });
      setPublished(res.id);
    } catch (err: any) {
      toast({
        title: "Submission Failed",
        description: err.message || "Something went wrong. Please try again.",
        variant: "destructive",
      });
    }
  }

  const priceDiff = useMemo(() => {
    const l = +form.listedPrice, a = +form.actualVisitPrice;
    if (!l || !a) return 0;
    return ((a - l) / l) * 100;
  }, [form.listedPrice, form.actualVisitPrice]);

  /* ── SUCCESS screen ── */
  if (published) {
    return (
      <div className="min-h-screen flex items-center justify-center px-4">
        <div className="text-center max-w-md">
          <div className="w-24 h-24 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-6">
            <CheckCircle2 className="w-12 h-12 text-green-600" />
          </div>
          <h2 className="text-3xl font-bold mb-2">Property Listed!</h2>
          <p className="text-muted-foreground mb-2">Your listing is live on PropVeri.</p>
          <p className="text-sm text-muted-foreground mb-8">Listing ID: <strong className="text-primary">PV-{published}</strong></p>

          {/* Preview card */}
          <div className="bg-white border rounded-2xl overflow-hidden shadow-md mb-8 text-left">
            {form.imageUrl && (
              <img src={form.imageUrl} alt={form.title} className="w-full h-40 object-cover" />
            )}
            <div className="p-4">
              <p className="font-bold text-base mb-1">{form.title}</p>
              <p className="text-sm text-muted-foreground mb-2">{form.address}, {form.city}</p>
              <div className="flex items-center gap-3 text-xs text-muted-foreground mb-3">
                <span><Bed className="w-3 h-3 inline mr-0.5" />{form.bedrooms} Beds</span>
                <span><Bath className="w-3 h-3 inline mr-0.5" />{form.bathrooms} Baths</span>
                <span><Square className="w-3 h-3 inline mr-0.5" />{form.areasqft} sqft</span>
              </div>
              <p className="text-xl font-bold text-primary">{fmtLakhs(form.listedPrice)}</p>
            </div>
          </div>

          <div className="flex flex-col sm:flex-row gap-3 justify-center">
            <Button onClick={() => navigate(`/properties/${published}`)}>
              <Eye className="w-4 h-4 mr-2" /> View Listing
            </Button>
            <Button variant="outline" onClick={() => { setForm(INIT); setStep(1); setPublished(null); setLocationVerified(false); }}>
              List Another Property
            </Button>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-muted/20 py-10 px-4">
      <div className="max-w-2xl mx-auto">
        {/* Header */}
        <div className="text-center mb-10">
          <Badge variant="outline" className="mb-4 text-primary border-primary/30 bg-primary/5 px-3 py-1">
            <ShieldCheck className="w-3.5 h-3.5 mr-1.5" /> Honest Listings Only
          </Badge>
          <h1 className="text-3xl md:text-4xl font-bold mb-2">List Your Property</h1>
          <p className="text-muted-foreground">Join the trusted marketplace where transparency wins buyers.</p>
        </div>

        {/* Step indicator */}
        <div className="flex items-center mb-8 relative">
          <div className="absolute inset-0 top-5 flex items-start px-5">
            <div className="w-full h-0.5 bg-border" />
          </div>
          {STEPS.map(({ n, label, icon: Icon }, i) => (
            <div key={n} className="flex-1 flex flex-col items-center relative z-10">
              <div className={cn(
                "w-10 h-10 rounded-full flex items-center justify-center font-bold text-sm transition-all duration-300",
                step > n ? "bg-green-500 text-white shadow-md" :
                step === n ? "bg-primary text-white shadow-lg ring-4 ring-primary/20" :
                "bg-white text-muted-foreground border-2 border-border"
              )}>
                {step > n ? <CheckCircle2 className="w-5 h-5" /> : n}
              </div>
              <span className={cn("text-xs mt-1.5 font-medium hidden sm:block",
                step === n ? "text-primary" : step > n ? "text-green-600" : "text-muted-foreground")}>
                {label}
              </span>
            </div>
          ))}
        </div>

        {/* Form card */}
        <div className="bg-white border rounded-2xl shadow-sm overflow-hidden">
          {/* ── Step 1: Basic Info ── */}
          {step === 1 && (
            <div className="p-6 md:p-8 space-y-5 animate-in fade-in duration-300">
              <div className="flex items-center gap-2 text-xl font-bold border-b pb-4">
                <Building2 className="w-5 h-5 text-primary" /> Basic Information
              </div>

              <div>
                <label className="text-sm font-semibold mb-1.5 block">Property Title <span className="text-destructive">*</span></label>
                <Input
                  placeholder="e.g. Spacious 2BHK near Metro, Andheri West"
                  value={form.title}
                  onChange={e => set("title", e.target.value)}
                  className={errors.title ? "border-destructive" : ""}
                />
                <p className="text-xs text-muted-foreground mt-1">A clear, descriptive title catches attention.</p>
                {errors.title && <p className="text-xs text-destructive mt-1">{errors.title}</p>}
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="text-sm font-semibold mb-1.5 block">Property Type <span className="text-destructive">*</span></label>
                  <select
                    className={cn("w-full h-10 border rounded-md px-3 text-sm focus:outline-none focus:ring-2 focus:ring-primary/30", errors.type ? "border-destructive" : "border-border")}
                    value={form.type}
                    onChange={e => set("type", e.target.value)}
                  >
                    <option value="">Select type</option>
                    <option value="apartment">Apartment</option>
                    <option value="villa">Villa / Bungalow</option>
                    <option value="plot">Plot / Land</option>
                    <option value="commercial">Commercial Space</option>
                    <option value="studio">Studio Apartment</option>
                  </select>
                  {errors.type && <p className="text-xs text-destructive mt-1">{errors.type}</p>}
                </div>
                <div>
                  <label className="text-sm font-semibold mb-1.5 block">Area (sq ft) <span className="text-destructive">*</span></label>
                  <Input type="number" placeholder="e.g. 1200" value={form.areasqft} onChange={e => set("areasqft", e.target.value)}
                    className={errors.areasqft ? "border-destructive" : ""} />
                  {errors.areasqft && <p className="text-xs text-destructive mt-1">{errors.areasqft}</p>}
                </div>
              </div>

              <div className="grid grid-cols-3 gap-4">
                <div>
                  <label className="text-sm font-semibold mb-1.5 block">Bedrooms <span className="text-destructive">*</span></label>
                  <Input type="number" min={0} max={20} placeholder="2" value={form.bedrooms} onChange={e => set("bedrooms", e.target.value)}
                    className={errors.bedrooms ? "border-destructive" : ""} />
                  {errors.bedrooms && <p className="text-xs text-destructive mt-1">{errors.bedrooms}</p>}
                </div>
                <div>
                  <label className="text-sm font-semibold mb-1.5 block">Bathrooms <span className="text-destructive">*</span></label>
                  <Input type="number" min={0} max={10} placeholder="2" value={form.bathrooms} onChange={e => set("bathrooms", e.target.value)}
                    className={errors.bathrooms ? "border-destructive" : ""} />
                  {errors.bathrooms && <p className="text-xs text-destructive mt-1">{errors.bathrooms}</p>}
                </div>
                <div>
                  <label className="text-sm font-semibold mb-1.5 block">Floor</label>
                  <Input placeholder="e.g. 4th" value={form.floor} onChange={e => set("floor", e.target.value)} />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="text-sm font-semibold mb-1.5 block">Furnishing</label>
                  <select className="w-full h-10 border border-border rounded-md px-3 text-sm" value={form.furnishing} onChange={e => set("furnishing", e.target.value)}>
                    <option value="unfurnished">Unfurnished</option>
                    <option value="semi-furnished">Semi-Furnished</option>
                    <option value="fully-furnished">Fully Furnished</option>
                  </select>
                </div>
                <div>
                  <label className="text-sm font-semibold mb-1.5 block">Facing</label>
                  <select className="w-full h-10 border border-border rounded-md px-3 text-sm" value={form.facing} onChange={e => set("facing", e.target.value)}>
                    <option value="">Select</option>
                    {["East", "West", "North", "South", "North-East", "North-West", "South-East", "South-West"].map(d => <option key={d}>{d}</option>)}
                  </select>
                </div>
              </div>

              <div>
                <label className="text-sm font-semibold mb-1.5 block">Description <span className="text-destructive">*</span></label>
                <textarea
                  className={cn("w-full border rounded-md p-3 text-sm h-28 resize-none focus:outline-none focus:ring-2 focus:ring-primary/30", errors.description ? "border-destructive" : "border-border")}
                  placeholder="Describe the property — amenities, nearby landmarks, unique features, society details..."
                  value={form.description}
                  onChange={e => set("description", e.target.value)}
                />
                <div className="flex justify-between">
                  {errors.description && <p className="text-xs text-destructive">{errors.description}</p>}
                  <p className="text-xs text-muted-foreground ml-auto">{form.description.length} / 20 min</p>
                </div>
              </div>

              <div>
                <label className="text-sm font-semibold mb-2 block">Amenities</label>
                <div className="grid grid-cols-3 gap-2">
                  {AMENITIES.map(a => (
                    <label key={a} className={cn("flex items-center gap-1.5 text-xs border rounded-lg px-2 py-1.5 cursor-pointer transition-colors",
                      form.amenities.includes(a) ? "border-primary bg-primary/5 text-primary" : "border-border hover:border-primary/40")}>
                      <input type="checkbox" className="accent-primary" checked={form.amenities.includes(a)} onChange={() => toggleAmenity(a)} />
                      {a}
                    </label>
                  ))}
                </div>
              </div>
            </div>
          )}

          {/* ── Step 2: Pricing ── */}
          {step === 2 && (
            <div className="p-6 md:p-8 space-y-5 animate-in fade-in duration-300">
              <div className="flex items-center gap-2 text-xl font-bold border-b pb-4">
                <IndianRupee className="w-5 h-5 text-primary" /> Honest Pricing
              </div>

              <div className="p-4 bg-primary/5 border border-primary/20 rounded-xl text-sm">
                <p className="font-semibold text-primary flex items-center gap-1.5 mb-1"><ShieldCheck className="w-4 h-4" /> The PropVeri Promise</p>
                <p className="text-muted-foreground leading-relaxed">Buyers are tired of inflated listings. Showing your real price attracts serious buyers and builds instant trust.</p>
              </div>

              {/* Listing type */}
              <div>
                <label className="text-sm font-semibold mb-2 block">Listing For</label>
                <div className="flex gap-2">
                  {LISTING_TYPES.map(t => (
                    <button key={t.id} onClick={() => set("listingType", t.id)}
                      className={cn("flex-1 py-2.5 rounded-xl border-2 text-sm font-semibold transition-colors flex items-center justify-center gap-1.5",
                        form.listingType === t.id ? "border-primary bg-primary text-white" : "border-border hover:border-primary/40")}>
                      {t.icon} {t.label}
                    </button>
                  ))}
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="text-sm font-semibold mb-1.5 block">
                    Advertised Price <span className="text-xs text-muted-foreground font-normal">(in Lakhs)</span>
                    <span className="text-destructive"> *</span>
                  </label>
                  <div className="relative">
                    <span className="absolute left-3 top-2.5 text-muted-foreground">₹</span>
                    <Input type="number" className={cn("pl-7 pr-12", errors.listedPrice ? "border-destructive" : "")}
                      placeholder="e.g. 85" value={form.listedPrice} onChange={e => set("listedPrice", e.target.value)} />
                    <span className="absolute right-3 top-2.5 text-xs text-muted-foreground">L</span>
                  </div>
                  {form.listedPrice && <p className="text-xs text-primary font-medium mt-1">{fmtLakhs(form.listedPrice)}</p>}
                  {errors.listedPrice && <p className="text-xs text-destructive mt-1">{errors.listedPrice}</p>}
                  <p className="text-xs text-muted-foreground mt-1">The price shown on standard portals.</p>
                </div>

                <div>
                  <label className="text-sm font-semibold mb-1.5 block text-primary">
                    Actual Visit Price <span className="text-xs text-muted-foreground font-normal">(in Lakhs)</span>
                    <span className="text-destructive"> *</span>
                  </label>
                  <div className="relative">
                    <span className="absolute left-3 top-2.5 text-primary">₹</span>
                    <Input type="number" className={cn("pl-7 pr-12 border-primary/40 focus-visible:ring-primary/30", errors.actualVisitPrice ? "border-destructive" : "")}
                      placeholder="e.g. 92" value={form.actualVisitPrice} onChange={e => set("actualVisitPrice", e.target.value)} />
                    <span className="absolute right-3 top-2.5 text-xs text-primary/70">L</span>
                  </div>
                  {form.actualVisitPrice && <p className="text-xs text-primary font-bold mt-1">{fmtLakhs(form.actualVisitPrice)}</p>}
                  {errors.actualVisitPrice && <p className="text-xs text-destructive mt-1">{errors.actualVisitPrice}</p>}
                  <p className="text-xs text-muted-foreground mt-1">The real price a buyer pays on visit.</p>
                </div>
              </div>

              {/* Price discrepancy indicator */}
              {form.listedPrice && form.actualVisitPrice && (
                <div className={cn("p-4 rounded-xl border flex items-start gap-3 text-sm",
                  priceDiff > 15 ? "bg-destructive/5 border-destructive/20 text-destructive" :
                  priceDiff > 0 ? "bg-amber-50 border-amber-200 text-amber-800" :
                  "bg-green-50 border-green-200 text-green-800")}>
                  {priceDiff > 10 ? <AlertTriangle className="w-4 h-4 shrink-0 mt-0.5" /> : <CheckCircle2 className="w-4 h-4 shrink-0 mt-0.5" />}
                  <div>
                    {priceDiff === 0
                      ? <><strong>Perfect transparency!</strong> Both prices match.</>
                      : priceDiff < 0
                      ? <><strong>Visit price is lower</strong> — this attracts buyers quickly.</>
                      : <><strong>Difference: {priceDiff.toFixed(1)}%</strong> — This will be clearly shown to buyers. {priceDiff > 15 && "Consider reducing the gap to improve conversion."}</>
                    }
                  </div>
                </div>
              )}

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="text-sm font-semibold mb-1.5 block">Maintenance Charges <span className="text-xs text-muted-foreground font-normal">(₹/month, optional)</span></label>
                  <Input type="number" placeholder="e.g. 3000" value={form.maintenanceCharges} onChange={e => set("maintenanceCharges", e.target.value)} />
                </div>
                <div>
                  <label className="text-sm font-semibold mb-1.5 block">Available From</label>
                  <Input type="date" value={form.availableFrom} onChange={e => set("availableFrom", e.target.value)} />
                </div>
              </div>
            </div>
          )}

          {/* ── Step 3: Location ── */}
          {step === 3 && (
            <div className="p-6 md:p-8 space-y-5 animate-in fade-in duration-300">
              <div className="flex items-center gap-2 text-xl font-bold border-b pb-4">
                <MapPin className="w-5 h-5 text-primary" /> Location Verification
              </div>

              <div className="p-4 bg-amber-50 border border-amber-200 rounded-xl text-sm text-amber-800 flex gap-3">
                <AlertTriangle className="w-4 h-4 shrink-0 mt-0.5 text-amber-600" />
                <span>Properties cannot be listed without location verification. Select your city for automatic coordinate detection.</span>
              </div>

              {/* City selector → auto-fills coords */}
              <div>
                <label className="text-sm font-semibold mb-1.5 block">City <span className="text-destructive">*</span></label>
                <select
                  className={cn("w-full h-10 border rounded-md px-3 text-sm focus:outline-none focus:ring-2 focus:ring-primary/30", errors.city ? "border-destructive" : "border-border")}
                  value={form.city}
                  onChange={e => handleCityChange(e.target.value)}
                >
                  <option value="">Select city…</option>
                  {Object.keys(CITY_COORDS).map(c => <option key={c}>{c}</option>)}
                </select>
                {errors.city && <p className="text-xs text-destructive mt-1">{errors.city}</p>}
              </div>

              <div>
                <label className="text-sm font-semibold mb-1.5 block">State</label>
                <Input value={form.state} onChange={e => set("state", e.target.value)} placeholder="Auto-filled from city" />
              </div>

              <div>
                <label className="text-sm font-semibold mb-1.5 block">Full Address <span className="text-destructive">*</span></label>
                <textarea
                  className={cn("w-full border rounded-md p-3 text-sm h-20 resize-none focus:outline-none focus:ring-2 focus:ring-primary/30", errors.address ? "border-destructive" : "border-border")}
                  placeholder="Building name, street, area / locality..."
                  value={form.address}
                  onChange={e => set("address", e.target.value)}
                />
                {errors.address && <p className="text-xs text-destructive mt-1">{errors.address}</p>}
              </div>

              <div>
                <label className="text-sm font-semibold mb-1.5 block">Nearby Landmark (optional)</label>
                <Input placeholder="e.g. Near Andheri Metro Station" value={form.landmark} onChange={e => set("landmark", e.target.value)} />
              </div>

              {/* Coordinates display */}
              {form.latitude !== 0 && (
                <div className="flex gap-3 p-3 bg-muted/40 rounded-lg text-xs text-muted-foreground">
                  <span><strong>Lat:</strong> {form.latitude.toFixed(4)}</span>
                  <span><strong>Lng:</strong> {form.longitude.toFixed(4)}</span>
                  <span className="text-green-600 font-medium">← Auto-detected from city</span>
                </div>
              )}

              {/* Verify button */}
              <div className="flex flex-col items-center gap-3 bg-muted/30 rounded-xl p-5 border">
                <Button type="button" onClick={verifyLocation} disabled={isVerifying || !form.city || !form.address} className="w-full">
                  {isVerifying ? (
                    <><Loader2 className="w-4 h-4 animate-spin mr-2" /> Verifying Location…</>
                  ) : locationVerified ? (
                    <><CheckCircle2 className="w-4 h-4 mr-2" /> Location Verified — Re-verify</>
                  ) : (
                    <><MapPin className="w-4 h-4 mr-2" /> Verify Location</>
                  )}
                </Button>
                {locationVerified && (
                  <div className="flex items-center gap-2 text-sm text-green-700 font-semibold">
                    <CheckCircle2 className="w-4 h-4" />
                    Location verified — coordinates match {form.city}
                  </div>
                )}
                {errors.location && (
                  <div className="flex items-center gap-2 text-sm text-destructive">
                    <AlertTriangle className="w-4 h-4" /> {errors.location}
                  </div>
                )}
              </div>
            </div>
          )}

          {/* ── Step 4: Photos ── */}
          {step === 4 && (
            <div className="p-6 md:p-8 space-y-5 animate-in fade-in duration-300">
              <div className="flex items-center gap-2 text-xl font-bold border-b pb-4">
                <ImageIcon className="w-5 h-5 text-primary" /> Property Photo
              </div>

              <div>
                <label className="text-sm font-semibold mb-1.5 block">Image URL <span className="text-destructive">*</span></label>
                <Input
                  placeholder="https://…"
                  value={form.imageUrl}
                  onChange={e => set("imageUrl", e.target.value)}
                  className={errors.imageUrl ? "border-destructive" : ""}
                />
                {errors.imageUrl && <p className="text-xs text-destructive mt-1">{errors.imageUrl}</p>}
                <p className="text-xs text-muted-foreground mt-1">Paste a direct image URL, or pick one of the stock photos below.</p>
              </div>

              {/* Sample photo picker */}
              <div>
                <p className="text-sm font-semibold mb-2">Quick Pick — Stock Photos</p>
                <div className="grid grid-cols-3 gap-2">
                  {SAMPLE_IMAGES.map(img => (
                    <button
                      key={img.url}
                      type="button"
                      onClick={() => set("imageUrl", img.url)}
                      className={cn("relative rounded-lg overflow-hidden border-2 transition-all aspect-video",
                        form.imageUrl === img.url ? "border-primary shadow-md" : "border-transparent hover:border-primary/40")}
                    >
                      <img src={img.url} alt={img.label} className="w-full h-full object-cover" />
                      {form.imageUrl === img.url && (
                        <div className="absolute inset-0 bg-primary/20 flex items-center justify-center">
                          <CheckCircle2 className="w-6 h-6 text-white drop-shadow" />
                        </div>
                      )}
                      <div className="absolute bottom-0 left-0 right-0 bg-black/40 text-white text-[10px] py-0.5 text-center">{img.label}</div>
                    </button>
                  ))}
                </div>
              </div>

              {/* Live preview */}
              {form.imageUrl && (
                <div className="rounded-xl overflow-hidden border aspect-video bg-muted">
                  <img
                    src={form.imageUrl}
                    alt="Preview"
                    className="w-full h-full object-cover"
                    onError={e => { (e.target as HTMLImageElement).style.display = "none"; }}
                  />
                </div>
              )}

              {/* Listing summary */}
              <div className="bg-primary/5 border border-primary/20 rounded-xl p-5 space-y-2">
                <p className="font-semibold text-primary flex items-center gap-1.5 mb-3">
                  <BadgeCheck className="w-4 h-4" /> Listing Summary
                </p>
                <div className="grid grid-cols-2 gap-x-6 gap-y-1.5 text-sm">
                  <div className="flex justify-between"><span className="text-muted-foreground">Title</span><span className="font-medium truncate ml-2">{form.title || "—"}</span></div>
                  <div className="flex justify-between"><span className="text-muted-foreground">Type</span><span className="font-medium capitalize">{form.type || "—"}</span></div>
                  <div className="flex justify-between"><span className="text-muted-foreground">Area</span><span className="font-medium">{form.areasqft ? `${form.areasqft} sqft` : "—"}</span></div>
                  <div className="flex justify-between"><span className="text-muted-foreground">Beds / Baths</span><span className="font-medium">{form.bedrooms} / {form.bathrooms}</span></div>
                  <div className="flex justify-between"><span className="text-muted-foreground">City</span><span className="font-medium">{form.city || "—"}</span></div>
                  <div className="flex justify-between"><span className="text-muted-foreground">Price</span><span className="font-bold text-primary">{fmtLakhs(form.listedPrice)}</span></div>
                </div>
              </div>

              <div className="p-4 bg-muted/30 rounded-xl text-sm text-muted-foreground border">
                <CheckCircle2 className="w-4 h-4 inline text-green-600 mr-1.5" />
                By publishing, you confirm all details are accurate and truthful per PropVeri's guidelines.
              </div>
            </div>
          )}

          {/* Navigation */}
          <div className="px-6 md:px-8 pb-6 flex justify-between border-t pt-5">
            <Button variant="outline" onClick={() => { setStep(s => s - 1); window.scrollTo({ top: 0, behavior: "smooth" }); }} disabled={step === 1 || createProperty.isPending}>
              <ChevronLeft className="w-4 h-4 mr-1" /> Previous
            </Button>

            {step < 4 ? (
              <Button onClick={nextStep}>
                Next Step <ChevronRight className="w-4 h-4 ml-1" />
              </Button>
            ) : (
              <Button onClick={publish} disabled={createProperty.isPending} className="px-8">
                {createProperty.isPending ? <><Loader2 className="w-4 h-4 animate-spin mr-2" /> Publishing…</> : "🚀 Publish Listing"}
              </Button>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
