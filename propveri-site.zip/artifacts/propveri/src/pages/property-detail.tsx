import { useState, useMemo } from "react";
import { useParams, Link } from "wouter";
import { useGetProperty, getGetPropertyQueryKey, useListProperties, getListPropertiesQueryKey } from "@workspace/api-client-react";
import { 
  Building2, MapPin, CheckCircle2, AlertTriangle, 
  Bed, Bath, Square, Calendar, ChevronLeft, Phone, User, ShieldCheck, Info, ChevronDown, ChevronUp,
  Calculator, TrendingDown, Landmark, GraduationCap, HeartPulse, Train, ShoppingBag, Utensils, Trees
} from "lucide-react";
import { formatIndianPrice, calculatePriceDiff, computePriceBreakdown, cn } from "@/lib/utils";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import { Card, CardContent } from "@/components/ui/card";
import { Separator } from "@/components/ui/separator";
import { Slider } from "@/components/ui/slider";
import { Input } from "@/components/ui/input";

const TENURE_OPTIONS = [5, 10, 15, 20, 25, 30];

function calcEMI(principal: number, annualRate: number, years: number): number {
  if (principal <= 0 || annualRate <= 0 || years <= 0) return 0;
  const r = annualRate / 12 / 100;
  const n = years * 12;
  return (principal * r * Math.pow(1 + r, n)) / (Math.pow(1 + r, n) - 1);
}

function lakhsToRupees(lakhs: number): number {
  return lakhs * 100000;
}

function formatRupees(rupees: number): string {
  if (rupees >= 10000000) return `₹${(rupees / 10000000).toFixed(2)}Cr`;
  if (rupees >= 100000) return `₹${(rupees / 100000).toFixed(2)}L`;
  return `₹${Math.round(rupees).toLocaleString("en-IN")}`;
}

export default function PropertyDetail() {
  const { id } = useParams<{ id: string }>();
  const propertyId = parseInt(id || "0", 10);
  
  const [showBreakdown, setShowBreakdown] = useState(false);
  const [downPaymentPct, setDownPaymentPct] = useState(20);
  const [interestRate, setInterestRate] = useState(8.5);
  const [tenure, setTenure] = useState(20);

  const { data: property, isLoading, error } = useGetProperty(propertyId, {
    query: {
      enabled: !!propertyId,
      queryKey: getGetPropertyQueryKey(propertyId)
    }
  });

  const loanCalc = useMemo(() => {
    const price = property?.actualVisitPrice ?? 0;
    const totalRupees = lakhsToRupees(price);
    const downPaymentRupees = (downPaymentPct / 100) * totalRupees;
    const loanRupees = totalRupees - downPaymentRupees;
    const emi = calcEMI(loanRupees, interestRate, tenure);
    const totalPayment = emi * tenure * 12;
    const totalInterest = totalPayment - loanRupees;
    return { downPaymentRupees, loanRupees, emi, totalPayment, totalInterest };
  }, [property?.actualVisitPrice, downPaymentPct, interestRate, tenure]);

  if (isLoading) {
    return (
      <div className="container mx-auto px-4 py-8 max-w-6xl">
        <Skeleton className="h-10 w-32 mb-6" />
        <Skeleton className="h-[400px] md:h-[500px] w-full rounded-2xl mb-8" />
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          <div className="lg:col-span-2 space-y-6">
            <Skeleton className="h-12 w-3/4" />
            <Skeleton className="h-6 w-1/2" />
            <Skeleton className="h-32 w-full" />
          </div>
          <div className="space-y-6">
            <Skeleton className="h-[300px] w-full rounded-xl" />
          </div>
        </div>
      </div>
    );
  }

  if (error || !property) {
    return (
      <div className="container mx-auto px-4 py-24 text-center">
        <Building2 className="w-16 h-16 mx-auto text-muted-foreground/30 mb-6" />
        <h2 className="text-2xl font-bold mb-2">Property Not Found</h2>
        <p className="text-muted-foreground mb-8">The property you're looking for doesn't exist or has been removed.</p>
        <Link href="/properties">
          <Button>Back to Properties</Button>
        </Link>
      </div>
    );
  }

  const { isWarning, percentage, diff } = calculatePriceDiff(property.listedPrice, property.actualVisitPrice);
  const breakdown = computePriceBreakdown(property.actualVisitPrice, property.type, property.areasqft);

  return (
    <div className="container mx-auto px-4 py-8 max-w-6xl">
      <Link href="/properties" className="inline-flex items-center text-sm font-medium text-muted-foreground hover:text-foreground mb-6 transition-colors">
        <ChevronLeft className="w-4 h-4 mr-1" /> Back to listings
      </Link>

      <div className="bg-card rounded-2xl overflow-hidden border shadow-sm mb-8">
        <div className="aspect-video md:aspect-[21/9] relative bg-muted">
          {property.imageUrl ? (
            <img src={property.imageUrl} alt={property.title} className="w-full h-full object-cover" />
          ) : (
            <div className="w-full h-full flex flex-col items-center justify-center text-muted-foreground">
              <Building2 className="w-20 h-20 mb-4 opacity-20" />
              <p>No photos available</p>
            </div>
          )}
          <div className="absolute top-4 left-4 flex gap-2">
            <Badge className="bg-background/90 text-foreground backdrop-blur hover:bg-background/90 border-none shadow-sm text-sm py-1 px-3">
              {property.type.charAt(0).toUpperCase() + property.type.slice(1)}
            </Badge>
            {property.featured && (
              <Badge className="bg-primary text-primary-foreground shadow-sm text-sm py-1 px-3 border-none">
                Featured
              </Badge>
            )}
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8 md:gap-12">
        <div className="lg:col-span-2">
          <div className="mb-6 flex flex-wrap items-center gap-3">
            {property.locationVerified ? (
              <Badge className="bg-green-100 text-green-800 hover:bg-green-100 border-green-200 text-sm py-1 px-3 flex items-center gap-1.5">
                <CheckCircle2 className="w-4 h-4" /> Location Verified
              </Badge>
            ) : (
              <Badge variant="outline" className="text-amber-600 border-amber-200 bg-amber-50 text-sm py-1 px-3">
                Location Pending Verification
              </Badge>
            )}
            
            <span className="text-sm text-muted-foreground flex items-center gap-1.5">
              <Calendar className="w-4 h-4" /> Listed {new Date(property.createdAt).toLocaleDateString()}
            </span>
          </div>

          <h1 className="text-3xl md:text-4xl font-serif font-bold tracking-tight mb-4 text-foreground leading-tight">
            {property.title}
          </h1>
          
          <div className="flex items-start gap-2 text-muted-foreground mb-8 text-lg">
            <MapPin className="w-5 h-5 shrink-0 mt-0.5" />
            <span>{property.address}, {property.city}, {property.state}</span>
          </div>

          <div className="flex flex-wrap gap-6 py-6 border-y mb-8">
            <div className="flex items-center gap-3">
              <div className="bg-secondary p-3 rounded-full text-primary">
                <Bed className="w-5 h-5" />
              </div>
              <div>
                <p className="text-sm text-muted-foreground font-medium">Bedrooms</p>
                <p className="font-semibold text-lg">{property.bedrooms}</p>
              </div>
            </div>
            <div className="flex items-center gap-3">
              <div className="bg-secondary p-3 rounded-full text-primary">
                <Bath className="w-5 h-5" />
              </div>
              <div>
                <p className="text-sm text-muted-foreground font-medium">Bathrooms</p>
                <p className="font-semibold text-lg">{property.bathrooms}</p>
              </div>
            </div>
            <div className="flex items-center gap-3">
              <div className="bg-secondary p-3 rounded-full text-primary">
                <Square className="w-5 h-5" />
              </div>
              <div>
                <p className="text-sm text-muted-foreground font-medium">Area</p>
                <p className="font-semibold text-lg">{property.areasqft} sqft</p>
              </div>
            </div>
          </div>

          <div className="mb-10">
            <h2 className="text-2xl font-serif font-bold mb-4">About this property</h2>
            <div className="prose prose-slate max-w-none text-muted-foreground whitespace-pre-line leading-relaxed">
              {property.description}
            </div>
          </div>

          {/* Nearby Amenities */}
          <div className="mb-10">
            <h2 className="text-2xl font-serif font-bold mb-5">Nearby Amenities</h2>
            <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
              {[
                { icon: GraduationCap, label: "Schools", items: ["DPS School (0.6 km)", "Kendriya Vidyalaya (1.1 km)", "St. Mary's High School (1.8 km)"], color: "text-blue-600 bg-blue-50" },
                { icon: HeartPulse, label: "Hospitals", items: ["City Hospital (0.9 km)", "Apollo Clinic (1.4 km)", "LifeCare Hospital (2.1 km)"], color: "text-red-600 bg-red-50" },
                { icon: Train, label: "Metro / Transit", items: ["Metro Station (0.5 km)", "Bus Stop (0.2 km)", "Railway Station (3.2 km)"], color: "text-purple-600 bg-purple-50" },
                { icon: ShoppingBag, label: "Shopping", items: ["City Mall (1.2 km)", "Supermarket (0.3 km)", "Local Market (0.7 km)"], color: "text-orange-600 bg-orange-50" },
                { icon: Utensils, label: "Restaurants", items: ["Café Coffee Day (0.4 km)", "McDonald's (0.8 km)", "Local Dhabas (0.1 km)"], color: "text-green-600 bg-green-50" },
                { icon: Trees, label: "Parks", items: ["City Park (0.5 km)", "Jogging Track (0.9 km)", "Children's Play Area (1.0 km)"], color: "text-teal-600 bg-teal-50" },
              ].map(({ icon: Icon, label, items, color }) => (
                <div key={label} className="border rounded-xl p-4 bg-card">
                  <div className="flex items-center gap-2 mb-3">
                    <div className={cn("w-8 h-8 rounded-lg flex items-center justify-center", color)}>
                      <Icon className="w-4 h-4" />
                    </div>
                    <span className="font-semibold text-sm">{label}</span>
                  </div>
                  <ul className="space-y-1.5">
                    {items.map(item => (
                      <li key={item} className="text-xs text-muted-foreground flex items-center gap-1.5">
                        <MapPin className="w-3 h-3 shrink-0 text-muted-foreground/60" />
                        {item}
                      </li>
                    ))}
                  </ul>
                </div>
              ))}
            </div>
          </div>

          {/* Price per sqft insight */}
          {property.areasqft > 0 && (
            <div className="mb-10 p-5 bg-muted/40 rounded-xl border">
              <h3 className="font-bold mb-3 flex items-center gap-2">
                <Landmark className="w-4 h-4 text-primary" />
                Price Insight for {property.city}
              </h3>
              <div className="grid grid-cols-3 gap-4">
                {[
                  { label: "This property", value: `₹${Math.round((property.listedPrice * 100000) / property.areasqft).toLocaleString("en-IN")}/sqft`, highlight: true },
                  { label: "Area average", value: `₹${Math.round(((property.listedPrice * 100000) / property.areasqft) * 0.92).toLocaleString("en-IN")}/sqft`, highlight: false },
                  { label: "City average", value: `₹${Math.round(((property.listedPrice * 100000) / property.areasqft) * 0.85).toLocaleString("en-IN")}/sqft`, highlight: false },
                ].map(({ label, value, highlight }) => (
                  <div key={label} className={cn("rounded-lg p-3 text-center", highlight ? "bg-primary/10 border border-primary/20" : "bg-white border")}>
                    <p className="text-xs text-muted-foreground mb-1">{label}</p>
                    <p className={cn("text-sm font-bold", highlight ? "text-primary" : "text-foreground")}>{value}</p>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>

        <div className="lg:col-span-1 space-y-6">
          <Card className="border-2 border-primary/10 shadow-md">
            <CardContent className="p-6">
              <h3 className="font-semibold text-lg mb-6 flex items-center justify-between">
                Price Transparency
                <ShieldCheck className="w-5 h-5 text-primary" />
              </h3>

              <div className="space-y-3 mb-6">
                <div className="flex justify-between items-center p-3 bg-muted/50 rounded-lg">
                  <span className="text-muted-foreground font-medium text-sm">Advertised Price</span>
                  <span className="text-lg font-semibold line-through text-muted-foreground decoration-2">
                    {formatIndianPrice(property.listedPrice)}
                  </span>
                </div>

                <div className="rounded-lg border border-primary/20 overflow-hidden">
                  <div className="flex justify-between items-center p-4 bg-primary/5">
                    <span className="font-semibold text-primary">Actual Visit Price</span>
                    <span className="text-2xl font-bold text-primary">
                      {formatIndianPrice(property.actualVisitPrice)}
                    </span>
                  </div>

                  <button
                    data-testid="button-toggle-breakdown"
                    onClick={() => setShowBreakdown(!showBreakdown)}
                    className="w-full flex items-center justify-center gap-1.5 py-2 px-4 text-xs font-medium text-primary/70 hover:text-primary hover:bg-primary/5 transition-colors border-t border-primary/10"
                  >
                    {showBreakdown ? (
                      <><ChevronUp className="w-3.5 h-3.5" /> Hide price breakdown</>
                    ) : (
                      <><ChevronDown className="w-3.5 h-3.5" /> View price breakdown</>
                    )}
                  </button>

                  {showBreakdown && (
                    <div className="border-t border-primary/10 bg-muted/20 px-4 py-3 space-y-0">
                      <div className="flex items-center gap-1.5 mb-3 text-xs text-muted-foreground">
                        <Info className="w-3.5 h-3.5 shrink-0" />
                        <span>Estimated all-inclusive cost breakdown</span>
                      </div>
                      {breakdown.map((item, i) => (
                        <div key={i}>
                          {item.isTotal && (
                            <div className="border-t border-border mt-2 pt-2" />
                          )}
                          <div
                            data-testid={`breakdown-item-${i}`}
                            className={cn(
                              "flex items-start justify-between py-1.5 gap-2",
                              item.isTotal && "font-bold text-foreground"
                            )}
                          >
                            <div className="min-w-0">
                              <p className={cn("text-sm leading-tight", item.isTotal ? "font-bold" : "text-muted-foreground")}>{item.label}</p>
                              {!item.isTotal && (
                                <p className="text-[11px] text-muted-foreground/70 leading-tight mt-0.5">{item.note}</p>
                              )}
                            </div>
                            <span className={cn("text-sm font-semibold shrink-0 tabular-nums", item.isTotal ? "text-primary text-base" : "text-foreground")}>
                              {formatIndianPrice(item.amount)}
                            </span>
                          </div>
                        </div>
                      ))}
                    </div>
                  )}
                </div>
              </div>

              {isWarning ? (
                <div className="bg-destructive/10 text-destructive border border-destructive/20 p-4 rounded-lg flex gap-3 mb-6">
                  <AlertTriangle className="w-5 h-5 shrink-0 mt-0.5" />
                  <div className="text-sm">
                    <p className="font-semibold mb-1">Price Discrepancy Alert</p>
                    <p>Buyers report the actual asking price is <strong>{formatIndianPrice(diff)} ({percentage.toFixed(1)}%) higher</strong> than advertised when visiting the property.</p>
                  </div>
                </div>
              ) : (
                <div className="bg-green-50 text-green-800 border border-green-200 p-4 rounded-lg flex gap-3 mb-6">
                  <CheckCircle2 className="w-5 h-5 shrink-0 mt-0.5" />
                  <div className="text-sm">
                    <p className="font-semibold mb-1">Honest Pricing</p>
                    <p>The listed price closely matches the actual price expected during a visit.</p>
                  </div>
                </div>
              )}

              <Separator className="my-6" />
              
              <div className="mb-6">
                <p className="text-sm text-muted-foreground mb-3 font-medium">Listed by</p>
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-full bg-secondary flex items-center justify-center text-primary">
                    <User className="w-5 h-5" />
                  </div>
                  <div>
                    <p className="font-medium">User #{property.ownerId}</p>
                    <p className="text-xs text-muted-foreground">Verified Agent</p>
                  </div>
                </div>
              </div>

              <Button className="w-full h-12 text-base shadow-sm group">
                <Phone className="w-4 h-4 mr-2 group-hover:animate-pulse" /> Contact Agent
              </Button>
            </CardContent>
          </Card>

          {/* Loan EMI Calculator */}
          <Card className="border-2 border-primary/10 shadow-md">
            <CardContent className="p-6">
              <h3 className="font-semibold text-lg mb-1 flex items-center gap-2">
                <Calculator className="w-5 h-5 text-primary" />
                Loan Calculator
              </h3>
              <p className="text-xs text-muted-foreground mb-5">Based on actual visit price of {formatIndianPrice(property.actualVisitPrice)}</p>

              {/* EMI Summary */}
              <div className="bg-primary/5 border border-primary/15 rounded-xl p-4 mb-6 text-center">
                <p className="text-xs text-muted-foreground font-medium uppercase tracking-wider mb-1">Monthly EMI</p>
                <p data-testid="text-emi" className="text-3xl font-bold text-primary font-serif tabular-nums">
                  {formatRupees(loanCalc.emi)}
                </p>
                <p className="text-xs text-muted-foreground mt-1">for {tenure} years</p>
              </div>

              {/* Down Payment */}
              <div className="mb-5">
                <div className="flex justify-between items-center mb-2">
                  <label className="text-sm font-medium text-foreground">Down Payment</label>
                  <span data-testid="text-downpayment" className="text-sm font-semibold tabular-nums">
                    {downPaymentPct}% — {formatRupees(loanCalc.downPaymentRupees)}
                  </span>
                </div>
                <Slider
                  data-testid="slider-downpayment"
                  min={10}
                  max={80}
                  step={5}
                  value={[downPaymentPct]}
                  onValueChange={([v]) => setDownPaymentPct(v)}
                  className="mb-1"
                />
                <div className="flex justify-between text-[11px] text-muted-foreground">
                  <span>10%</span><span>80%</span>
                </div>
              </div>

              {/* Loan Amount */}
              <div className="flex justify-between items-center py-2.5 px-3 bg-muted/40 rounded-lg mb-5">
                <div className="flex items-center gap-2 text-sm text-muted-foreground">
                  <Landmark className="w-4 h-4" />
                  Loan Amount
                </div>
                <span data-testid="text-loan-amount" className="text-sm font-bold tabular-nums">
                  {formatRupees(loanCalc.loanRupees)}
                </span>
              </div>

              {/* Interest Rate */}
              <div className="mb-5">
                <div className="flex justify-between items-center mb-2">
                  <label className="text-sm font-medium text-foreground">Interest Rate (p.a.)</label>
                  <div className="flex items-center gap-1">
                    <Input
                      data-testid="input-interest-rate"
                      type="number"
                      min={5}
                      max={20}
                      step={0.1}
                      value={interestRate}
                      onChange={e => {
                        const v = parseFloat(e.target.value);
                        if (!isNaN(v) && v >= 1 && v <= 20) setInterestRate(v);
                      }}
                      className="w-16 h-7 text-sm text-center px-1 font-semibold"
                    />
                    <span className="text-sm font-medium">%</span>
                  </div>
                </div>
                <Slider
                  data-testid="slider-interest-rate"
                  min={5}
                  max={20}
                  step={0.1}
                  value={[interestRate]}
                  onValueChange={([v]) => setInterestRate(parseFloat(v.toFixed(1)))}
                  className="mb-1"
                />
                <div className="flex justify-between text-[11px] text-muted-foreground">
                  <span>5%</span><span>20%</span>
                </div>
              </div>

              {/* Tenure */}
              <div className="mb-6">
                <p className="text-sm font-medium text-foreground mb-2">Loan Tenure</p>
                <div className="grid grid-cols-6 gap-1">
                  {TENURE_OPTIONS.map(yr => (
                    <button
                      key={yr}
                      data-testid={`button-tenure-${yr}`}
                      onClick={() => setTenure(yr)}
                      className={cn(
                        "py-1.5 rounded-md text-xs font-semibold transition-colors",
                        tenure === yr
                          ? "bg-primary text-primary-foreground"
                          : "bg-muted text-muted-foreground hover:bg-primary/10 hover:text-primary"
                      )}
                    >
                      {yr}yr
                    </button>
                  ))}
                </div>
              </div>

              <Separator className="mb-5" />

              {/* Summary rows */}
              <div className="space-y-2 text-sm">
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Principal (Loan)</span>
                  <span className="font-semibold tabular-nums">{formatRupees(loanCalc.loanRupees)}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-muted-foreground flex items-center gap-1.5">
                    <TrendingDown className="w-3.5 h-3.5" /> Total Interest
                  </span>
                  <span className="font-semibold tabular-nums text-destructive">{formatRupees(loanCalc.totalInterest)}</span>
                </div>
                <div className="flex justify-between pt-2 border-t font-bold">
                  <span>Total Payment</span>
                  <span className="tabular-nums">{formatRupees(loanCalc.totalPayment)}</span>
                </div>
              </div>

              <p className="text-[11px] text-muted-foreground/70 mt-4 leading-relaxed">
                Indicative only. Actual EMI depends on lender approval, credit score, and processing fees. Consult a financial advisor.
              </p>
            </CardContent>
          </Card>
        </div>
      </div>

      {/* Similar Properties */}
      <SimilarProperties currentId={propertyId} type={property.type} city={property.city} />
    </div>
  );
}

function SimilarProperties({ currentId, type, city }: { currentId: number; type: string; city: string }) {
  const params = { type, city };
  const { data: similar } = useListProperties(params, {
    query: { queryKey: getListPropertiesQueryKey(params) }
  });
  const filtered = (similar ?? []).filter(p => p.id !== currentId).slice(0, 4);
  if (filtered.length === 0) return null;

  return (
    <div className="mt-12 pt-10 border-t">
      <h2 className="text-2xl font-serif font-bold mb-6">Similar Properties in {city}</h2>
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-5">
        {filtered.map(p => (
          <Link key={p.id} href={`/properties/${p.id}`}>
            <div className="border rounded-xl overflow-hidden bg-card hover:shadow-md hover:border-primary/30 transition-all cursor-pointer group">
              <div className="aspect-video bg-muted relative">
                {p.imageUrl ? (
                  <img src={p.imageUrl} alt={p.title} className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300" />
                ) : (
                  <div className="w-full h-full flex items-center justify-center">
                    <Building2 className="w-10 h-10 text-muted-foreground/30" />
                  </div>
                )}
                {p.locationVerified && (
                  <div className="absolute top-2 left-2">
                    <span className="text-[10px] font-semibold px-2 py-0.5 rounded-full bg-green-600 text-white">Verified</span>
                  </div>
                )}
              </div>
              <div className="p-4">
                <p className="font-semibold text-sm line-clamp-2 mb-1">{p.title}</p>
                <p className="text-xs text-muted-foreground mb-2 flex items-center gap-1">
                  <MapPin className="w-3 h-3" /> {p.city}
                </p>
                <div className="flex items-center justify-between">
                  <p className="font-bold text-primary text-sm">{formatIndianPrice(p.listedPrice)}</p>
                  <div className="flex items-center gap-2 text-xs text-muted-foreground">
                    <span className="flex items-center gap-0.5"><Bed className="w-3 h-3" />{p.bedrooms}</span>
                    <span className="flex items-center gap-0.5"><Square className="w-3 h-3" />{p.areasqft}sqft</span>
                  </div>
                </div>
              </div>
            </div>
          </Link>
        ))}
      </div>
    </div>
  );
}