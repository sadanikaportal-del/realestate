import { Link } from "wouter";
import {
  Truck, FileText, HandshakeIcon, Building2, Paintbrush, Wrench,
  BadgeCheck, PhoneCall, CheckCircle2, ArrowRight, Star
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { cn } from "@/lib/utils";

const SERVICES = [
  {
    icon: Truck,
    label: "Packers & Movers",
    href: "/services/packers-movers",
    desc: "Verified and insured moving companies for local and interstate moves. Get up to 5 instant quotes.",
    features: ["Background verified", "GPS tracking", "Insurance covered", "Fixed pricing"],
    color: "bg-blue-50 text-blue-600",
    badge: "Most Popular",
  },
  {
    icon: FileText,
    label: "Rental Agreement",
    href: "/services/rental-agreement",
    desc: "Legally valid, e-stamped rental agreements drafted and delivered digitally within 24 hours.",
    features: ["Legally valid", "e-Stamp paper", "Doorstep delivery", "Lawyer reviewed"],
    color: "bg-green-50 text-green-600",
    badge: "Digital",
  },
  {
    icon: HandshakeIcon,
    label: "Legal Services",
    href: "/services/legal-services",
    desc: "Expert property lawyers for title verification, sale deed, RERA compliance, and more.",
    features: ["Title search", "Sale deed", "RERA advice", "Home loan NOC"],
    color: "bg-purple-50 text-purple-600",
    badge: null,
  },
  {
    icon: Building2,
    label: "Home Loans",
    href: "/services/home-loans",
    desc: "Compare home loan offers from 20+ banks and NBFCs. Get the lowest EMI guaranteed.",
    features: ["Lowest rates", "Fast approval", "Doorstep service", "Free eligibility check"],
    color: "bg-orange-50 text-orange-600",
    badge: "Save ₹2L+",
  },
  {
    icon: Paintbrush,
    label: "Interior Design",
    href: "/services/interior-design",
    desc: "Transform your new home with our network of interior designers. 3D visualisation included.",
    features: ["3D design", "Expert designers", "Budget friendly", "End-to-end support"],
    color: "bg-pink-50 text-pink-600",
    badge: null,
  },
  {
    icon: Wrench,
    label: "Home Repairs",
    href: "/services/home-repairs",
    desc: "Plumbers, electricians, carpenters, and AC technicians available on same-day booking.",
    features: ["Same-day booking", "Fixed rates", "Warranty on work", "Verified pros"],
    color: "bg-teal-50 text-teal-600",
    badge: "On Demand",
  },
  {
    icon: BadgeCheck,
    label: "Tenant Verification",
    href: "/services/tenant-verification",
    desc: "Comprehensive background check for tenants including police verification and credit check.",
    features: ["Police verify", "Credit check", "Employment verify", "Reference check"],
    color: "bg-indigo-50 text-indigo-600",
    badge: null,
  },
  {
    icon: PhoneCall,
    label: "Property Management",
    href: "/services/property-management",
    desc: "We manage your rental property end-to-end — tenant finding, rent collection, and maintenance.",
    features: ["Tenant finding", "Rent collection", "Maintenance", "Monthly reports"],
    color: "bg-red-50 text-red-600",
    badge: "For Owners",
  },
];

const TESTIMONIALS = [
  { name: "Vikram Nair", city: "Mumbai", text: "Used PropVeri's packers & movers service for my Andheri to Powai shift. Stress-free and at a fixed price!", stars: 5 },
  { name: "Sneha Reddy", city: "Bangalore", text: "Got my rental agreement done in 24 hours. Completely legal and e-stamped. No need to go to a lawyer.", stars: 5 },
  { name: "Rajan Mehta", city: "Delhi", text: "The home loan comparison saved me almost ₹2.4 lakhs over a 20-year tenure. Highly recommend!", stars: 5 },
];

export default function Services() {
  return (
    <div className="min-h-screen">
      {/* Hero */}
      <section className="bg-primary text-white py-20 relative overflow-hidden">
        <div className="absolute inset-0 bg-[url('https://images.unsplash.com/photo-1560518883-ce09059eeffa?w=1200')] bg-cover bg-center opacity-10" />
        <div className="container mx-auto px-4 relative z-10 text-center">
          <Badge className="mb-5 bg-white/15 text-white border-white/20 text-sm">
            <BadgeCheck className="w-3.5 h-3.5 mr-1.5" /> Trusted Service Partners
          </Badge>
          <h1 className="text-4xl md:text-5xl font-bold mb-4 leading-tight">
            All Home Services,<br />One Trusted Platform
          </h1>
          <p className="text-white/75 text-lg max-w-xl mx-auto mb-8">
            NoBroker-style end-to-end support for everything from moving in to settling down — with PropVeri's verified service providers.
          </p>
          <div className="flex flex-wrap justify-center gap-6 text-sm text-white/80">
            {["Background Verified Pros", "Transparent Pricing", "5-Star Rated Partners", "24/7 Support"].map(f => (
              <div key={f} className="flex items-center gap-1.5">
                <CheckCircle2 className="w-4 h-4 text-green-400" />
                {f}
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Services Grid */}
      <section className="py-20 bg-muted/20">
        <div className="container mx-auto px-4">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold mb-2">Our Services</h2>
            <p className="text-muted-foreground max-w-lg mx-auto">Choose from our range of verified home services — all designed to make your property journey smooth.</p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-5">
            {SERVICES.map(({ icon: Icon, label, href, desc, features, color, badge }) => (
              <div key={label} className="bg-white rounded-xl border p-6 hover:shadow-lg hover:border-primary/30 transition-all group flex flex-col">
                <div className="flex items-start justify-between mb-4">
                  <div className={cn("w-12 h-12 rounded-xl flex items-center justify-center", color)}>
                    <Icon className="w-6 h-6" />
                  </div>
                  {badge && (
                    <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-primary/10 text-primary uppercase tracking-wider">
                      {badge}
                    </span>
                  )}
                </div>
                <h3 className="font-bold text-base mb-2">{label}</h3>
                <p className="text-sm text-muted-foreground leading-relaxed mb-4 flex-1">{desc}</p>
                <ul className="space-y-1.5 mb-5">
                  {features.map(f => (
                    <li key={f} className="flex items-center gap-2 text-xs text-muted-foreground">
                      <CheckCircle2 className="w-3.5 h-3.5 text-green-500 shrink-0" />
                      {f}
                    </li>
                  ))}
                </ul>
                <Link href={href}>
                  <Button variant="outline" size="sm" className="w-full group-hover:bg-primary group-hover:text-white group-hover:border-primary transition-colors">
                    Get Started <ArrowRight className="w-3.5 h-3.5 ml-1.5" />
                  </Button>
                </Link>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Testimonials */}
      <section className="py-16 bg-white border-y">
        <div className="container mx-auto px-4">
          <h2 className="text-2xl font-bold text-center mb-10">What Our Users Say</h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 max-w-4xl mx-auto">
            {TESTIMONIALS.map(({ name, city, text, stars }) => (
              <div key={name} className="bg-muted/30 rounded-xl p-6 border">
                <div className="flex mb-3">
                  {[...Array(stars)].map((_, i) => (
                    <Star key={i} className="w-4 h-4 text-yellow-400 fill-yellow-400" />
                  ))}
                </div>
                <p className="text-sm text-muted-foreground leading-relaxed mb-4">"{text}"</p>
                <div className="flex items-center gap-2">
                  <div className="w-8 h-8 rounded-full bg-primary text-white flex items-center justify-center text-xs font-bold">
                    {name.charAt(0)}
                  </div>
                  <div>
                    <p className="text-sm font-semibold">{name}</p>
                    <p className="text-xs text-muted-foreground">{city}</p>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA */}
      <section className="py-16 bg-muted/20">
        <div className="container mx-auto px-4 text-center">
          <h2 className="text-2xl font-bold mb-3">Need help choosing a service?</h2>
          <p className="text-muted-foreground mb-6 max-w-md mx-auto">Our expert team is available Mon–Sat, 9AM–7PM to guide you.</p>
          <div className="flex gap-4 justify-center flex-wrap">
            <Link href="/properties">
              <Button size="lg" variant="outline" className="h-12 px-6">Browse Properties</Button>
            </Link>
            <Button size="lg" className="h-12 px-6">
              <PhoneCall className="w-4 h-4 mr-2" /> Request Callback
            </Button>
          </div>
        </div>
      </section>
    </div>
  );
}
