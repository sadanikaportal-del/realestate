import { useListUsers } from "@workspace/api-client-react";
import { Users as UsersIcon, ShieldCheck, Mail, Phone, Calendar } from "lucide-react";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";

export default function Users() {
  const { data: users, isLoading } = useListUsers();

  const getRoleBadge = (role: string) => {
    switch (role) {
      case 'owner':
        return <Badge className="bg-blue-100 text-blue-800 hover:bg-blue-100 border-blue-200">Owner</Badge>;
      case 'agent':
        return <Badge className="bg-amber-100 text-amber-800 hover:bg-amber-100 border-amber-200">Verified Agent</Badge>;
      case 'developer':
        return <Badge className="bg-purple-100 text-purple-800 hover:bg-purple-100 border-purple-200">Developer</Badge>;
      default:
        return <Badge variant="secondary" className="capitalize">{role}</Badge>;
    }
  };

  const getInitials = (name: string) => {
    return name.split(' ').map(n => n[0]).join('').toUpperCase().substring(0, 2);
  };

  return (
    <div className="container mx-auto px-4 py-12 max-w-6xl">
      <div className="mb-10 border-b pb-6">
        <div className="flex items-center gap-3 mb-2">
          <div className="p-2 bg-primary/10 rounded-lg">
            <UsersIcon className="w-6 h-6 text-primary" />
          </div>
          <h1 className="text-3xl font-serif font-bold tracking-tight">Verified Network</h1>
        </div>
        <p className="text-muted-foreground text-lg ml-12 max-w-2xl">
          Meet the verified property owners, dedicated agents, and developers who have committed to honest pricing on PropVeri.
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {isLoading ? (
          <>
            {[1, 2, 3, 4, 5, 6].map(i => (
              <Card key={i} className="overflow-hidden">
                <CardContent className="p-6">
                  <div className="flex items-start gap-4">
                    <Skeleton className="w-14 h-14 rounded-full" />
                    <div className="space-y-2 flex-1">
                      <Skeleton className="h-5 w-2/3" />
                      <Skeleton className="h-4 w-1/3" />
                      <div className="pt-4 space-y-2">
                        <Skeleton className="h-4 w-full" />
                        <Skeleton className="h-4 w-4/5" />
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </>
        ) : users && users.length > 0 ? (
          users.map(user => (
            <Card key={user.id} className="overflow-hidden hover:shadow-md transition-shadow group border-border/60">
              <div className="h-2 w-full bg-gradient-to-r from-primary/40 to-primary/10"></div>
              <CardContent className="p-6">
                <div className="flex items-start justify-between mb-4">
                  <div className="flex items-center gap-4">
                    <Avatar className="w-14 h-14 border-2 border-background shadow-sm group-hover:border-primary/20 transition-colors">
                      <AvatarFallback className="bg-primary/5 text-primary font-semibold text-lg">
                        {getInitials(user.name)}
                      </AvatarFallback>
                    </Avatar>
                    <div>
                      <h3 className="font-bold text-lg leading-tight text-foreground">{user.name}</h3>
                      <div className="mt-1">
                        {getRoleBadge(user.role)}
                      </div>
                    </div>
                  </div>
                  {user.role === 'agent' && (
                    <ShieldCheck className="w-5 h-5 text-primary shrink-0 opacity-80" title="Verified Professional" />
                  )}
                </div>

                <div className="space-y-3 mt-6 text-sm text-muted-foreground bg-muted/30 p-4 rounded-lg">
                  <div className="flex items-center gap-3">
                    <Mail className="w-4 h-4 text-muted-foreground/70" />
                    <span className="truncate">{user.email}</span>
                  </div>
                  {user.phone && (
                    <div className="flex items-center gap-3">
                      <Phone className="w-4 h-4 text-muted-foreground/70" />
                      <span>{user.phone}</span>
                    </div>
                  )}
                  <div className="flex items-center gap-3">
                    <Calendar className="w-4 h-4 text-muted-foreground/70" />
                    <span>Joined {new Date(user.createdAt).toLocaleDateString()}</span>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))
        ) : (
          <div className="col-span-full text-center py-24 bg-card rounded-xl border border-dashed">
            <UsersIcon className="w-12 h-12 mx-auto text-muted-foreground/30 mb-4" />
            <h3 className="text-xl font-medium mb-2">No users found</h3>
            <p className="text-muted-foreground">The directory is currently empty.</p>
          </div>
        )}
      </div>
    </div>
  );
}