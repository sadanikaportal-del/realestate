import { Router } from "express";
import Razorpay from "razorpay";
import crypto from "crypto";
import { z } from "zod";

const router = Router();

function getRazorpay() {
  const keyId = process.env["RAZORPAY_KEY_ID"];
  const keySecret = process.env["RAZORPAY_KEY_SECRET"];
  if (!keyId || !keySecret) return null;
  return new Razorpay({ key_id: keyId, key_secret: keySecret });
}

const CreateOrderSchema = z.object({
  amount: z.number().positive(),
  packageId: z.number().int().positive(),
  currency: z.string().default("INR"),
});

const VerifySchema = z.object({
  razorpay_order_id: z.string(),
  razorpay_payment_id: z.string(),
  razorpay_signature: z.string(),
  packageId: z.number().int().positive(),
  userId: z.number().int().positive(),
});

router.post("/payments/create-order", async (req, res) => {
  const parsed = CreateOrderSchema.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: "Invalid request", details: parsed.error.flatten() });
    return;
  }

  const rzp = getRazorpay();
  if (!rzp) {
    res.status(503).json({ error: "Payment gateway not configured. Please add RAZORPAY_KEY_ID and RAZORPAY_KEY_SECRET." });
    return;
  }

  try {
    const order = await rzp.orders.create({
      amount: parsed.data.amount * 100,
      currency: parsed.data.currency,
      receipt: `pv_pkg_${parsed.data.packageId}_${Date.now()}`,
      notes: { packageId: String(parsed.data.packageId) },
    });

    res.json({
      orderId: order.id,
      amount: order.amount,
      currency: order.currency,
      keyId: process.env["RAZORPAY_KEY_ID"],
    });
  } catch (err: any) {
    req.log.error({ err }, "Razorpay order creation failed");
    res.status(500).json({ error: "Failed to create payment order" });
  }
});

router.post("/payments/verify", async (req, res) => {
  const parsed = VerifySchema.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: "Invalid request" });
    return;
  }

  const keySecret = process.env["RAZORPAY_KEY_SECRET"];
  if (!keySecret) {
    res.status(503).json({ error: "Payment gateway not configured" });
    return;
  }

  const { razorpay_order_id, razorpay_payment_id, razorpay_signature } = parsed.data;
  const body = razorpay_order_id + "|" + razorpay_payment_id;
  const expectedSig = crypto.createHmac("sha256", keySecret).update(body).digest("hex");

  if (expectedSig !== razorpay_signature) {
    res.status(400).json({ error: "Payment verification failed — invalid signature" });
    return;
  }

  res.json({ verified: true, paymentId: razorpay_payment_id, orderId: razorpay_order_id });
});

router.get("/payments/config", (_req, res) => {
  const keyId = process.env["RAZORPAY_KEY_ID"];
  res.json({ configured: !!keyId, keyId: keyId ?? null });
});

export default router;
