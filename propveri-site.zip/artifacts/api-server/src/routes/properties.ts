import { Router, type IRouter } from "express";
import { eq, and, gte, lte, sql } from "drizzle-orm";
import { db, propertiesTable } from "@workspace/db";
import {
  ListPropertiesQueryParams,
  CreatePropertyBody,
  GetPropertyParams,
  UpdatePropertyParams,
  UpdatePropertyBody,
  DeletePropertyParams,
  VerifyPropertyLocationParams,
  VerifyPropertyLocationBody,
} from "@workspace/api-zod";

const router: IRouter = Router();

router.get("/properties", async (req, res): Promise<void> => {
  const parsed = ListPropertiesQueryParams.safeParse(req.query);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }

  const { type, minPrice, maxPrice, city, status } = parsed.data;

  const conditions = [];
  if (type) conditions.push(eq(propertiesTable.type, type));
  if (city) conditions.push(eq(propertiesTable.city, city));
  if (status) conditions.push(eq(propertiesTable.status, status));
  if (minPrice != null) conditions.push(gte(propertiesTable.listedPrice, minPrice));
  if (maxPrice != null) conditions.push(lte(propertiesTable.listedPrice, maxPrice));

  const properties = await db
    .select()
    .from(propertiesTable)
    .where(conditions.length > 0 ? and(...conditions) : undefined)
    .orderBy(propertiesTable.createdAt);

  res.json(properties);
});

router.post("/properties", async (req, res): Promise<void> => {
  const parsed = CreatePropertyBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }

  const data = parsed.data;
  const { latitude, longitude, address } = data;

  // Location verification: check coords are valid (within India bounding box)
  const inIndia =
    latitude >= 8.0 && latitude <= 37.5 && longitude >= 68.0 && longitude <= 97.5;

  if (!inIndia) {
    res.status(400).json({ error: "Invalid location: coordinates do not match a valid address in India. Please check your latitude and longitude." });
    return;
  }

  const [property] = await db
    .insert(propertiesTable)
    .values({
      title: data.title,
      description: data.description,
      address: data.address,
      city: data.city,
      state: data.state,
      latitude: data.latitude,
      longitude: data.longitude,
      listedPrice: data.listedPrice,
      actualVisitPrice: data.actualVisitPrice,
      type: data.type,
      ownerId: data.ownerId,
      bedrooms: data.bedrooms,
      bathrooms: data.bathrooms,
      areasqft: data.areasgft ?? 0,
      imageUrl: data.imageUrl ?? null,
      locationVerified: inIndia,
      status: inIndia ? "pending_verification" : "rejected",
    })
    .returning();

  res.status(201).json(property);
});

router.get("/properties/featured", async (_req, res): Promise<void> => {
  const properties = await db
    .select()
    .from(propertiesTable)
    .where(and(eq(propertiesTable.featured, true), eq(propertiesTable.locationVerified, true)))
    .orderBy(propertiesTable.createdAt)
    .limit(6);

  res.json(properties);
});

router.get("/properties/stats", async (_req, res): Promise<void> => {
  const [total] = await db
    .select({ count: sql<number>`count(*)::int` })
    .from(propertiesTable);

  const [verified] = await db
    .select({ count: sql<number>`count(*)::int` })
    .from(propertiesTable)
    .where(eq(propertiesTable.locationVerified, true));

  const [pending] = await db
    .select({ count: sql<number>`count(*)::int` })
    .from(propertiesTable)
    .where(eq(propertiesTable.status, "pending_verification"));

  const cities = await db
    .selectDistinct({ city: propertiesTable.city })
    .from(propertiesTable);

  const [avgPrice] = await db
    .select({ avg: sql<number>`coalesce(avg(listed_price)::int, 0)` })
    .from(propertiesTable);

  const byTypeRows = await db
    .select({
      type: propertiesTable.type,
      count: sql<number>`count(*)::int`,
    })
    .from(propertiesTable)
    .groupBy(propertiesTable.type);

  const byType: Record<string, number> = {};
  for (const row of byTypeRows) {
    byType[row.type] = row.count;
  }

  res.json({
    totalListings: total.count,
    verifiedListings: verified.count,
    pendingVerification: pending.count,
    totalCities: cities.length,
    avgListedPrice: avgPrice.avg,
    byType,
  });
});

router.get("/properties/:id", async (req, res): Promise<void> => {
  const params = GetPropertyParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }

  const [property] = await db
    .select()
    .from(propertiesTable)
    .where(eq(propertiesTable.id, params.data.id));

  if (!property) {
    res.status(404).json({ error: "Property not found" });
    return;
  }

  res.json(property);
});

router.patch("/properties/:id", async (req, res): Promise<void> => {
  const params = UpdatePropertyParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }

  const parsed = UpdatePropertyBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }

  const [property] = await db
    .update(propertiesTable)
    .set(parsed.data)
    .where(eq(propertiesTable.id, params.data.id))
    .returning();

  if (!property) {
    res.status(404).json({ error: "Property not found" });
    return;
  }

  res.json(property);
});

router.delete("/properties/:id", async (req, res): Promise<void> => {
  const params = DeletePropertyParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }

  const [property] = await db
    .delete(propertiesTable)
    .where(eq(propertiesTable.id, params.data.id))
    .returning();

  if (!property) {
    res.status(404).json({ error: "Property not found" });
    return;
  }

  res.sendStatus(204);
});

router.post("/properties/:id/verify-location", async (req, res): Promise<void> => {
  const params = VerifyPropertyLocationParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }

  const body = VerifyPropertyLocationBody.safeParse(req.body);
  if (!body.success) {
    res.status(400).json({ error: body.error.message });
    return;
  }

  const { latitude, longitude, address } = body.data;

  // Verify coordinates are within India bounding box
  const inIndia =
    latitude >= 8.0 && latitude <= 37.5 && longitude >= 68.0 && longitude <= 97.5;

  if (!inIndia) {
    res.json({
      verified: false,
      message: "Coordinates are outside India. Please enter a valid Indian address with correct coordinates.",
      distanceKm: null,
    });
    return;
  }

  // Check address contains at least a city/state reference (basic validation)
  const hasAddressContent = address && address.trim().length >= 10;
  if (!hasAddressContent) {
    res.json({
      verified: false,
      message: "Address is too short. Please provide a complete address including street, city, and state.",
      distanceKm: null,
    });
    return;
  }

  // Mark the property as location-verified
  await db
    .update(propertiesTable)
    .set({ locationVerified: true, status: "verified" })
    .where(eq(propertiesTable.id, params.data.id));

  res.json({
    verified: true,
    message: "Location successfully verified. Your property is now live.",
    distanceKm: null,
  });
});

export default router;
