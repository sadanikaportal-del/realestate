import { Router, type IRouter } from "express";
import { eq } from "drizzle-orm";
import { db, usersTable, propertiesTable } from "@workspace/db";
import {
  CreateUserBody,
  GetUserParams,
  GetUserPropertiesParams,
} from "@workspace/api-zod";

const router: IRouter = Router();

router.get("/users", async (_req, res): Promise<void> => {
  const users = await db
    .select()
    .from(usersTable)
    .orderBy(usersTable.createdAt);
  res.json(users);
});

router.post("/users", async (req, res): Promise<void> => {
  const parsed = CreateUserBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }

  const [user] = await db
    .insert(usersTable)
    .values(parsed.data)
    .returning();

  res.status(201).json(user);
});

router.get("/users/:id", async (req, res): Promise<void> => {
  const params = GetUserParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }

  const [user] = await db
    .select()
    .from(usersTable)
    .where(eq(usersTable.id, params.data.id));

  if (!user) {
    res.status(404).json({ error: "User not found" });
    return;
  }

  res.json(user);
});

router.get("/users/:id/properties", async (req, res): Promise<void> => {
  const params = GetUserPropertiesParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }

  const properties = await db
    .select()
    .from(propertiesTable)
    .where(eq(propertiesTable.ownerId, params.data.id))
    .orderBy(propertiesTable.createdAt);

  res.json(properties);
});

export default router;
