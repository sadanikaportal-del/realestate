import { Router, type IRouter } from "express";
import healthRouter from "./health";
import propertiesRouter from "./properties";
import usersRouter from "./users";
import packagesRouter from "./packages";
import authRouter from "./auth";
import paymentsRouter from "./payments";

const router: IRouter = Router();

router.use(authRouter);
router.use(healthRouter);
router.use(propertiesRouter);
router.use(usersRouter);
router.use(packagesRouter);
router.use(paymentsRouter);

export default router;
