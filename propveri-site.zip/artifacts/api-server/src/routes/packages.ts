import { Router, type IRouter } from "express";
import { eq } from "drizzle-orm";
import { db, packagesTable, userPackagesTable } from "@workspace/db";
import {
  GetPackageParams,
  PurchasePackageBody,
} from "@workspace/api-zod";

const router: IRouter = Router();

router.get("/packages", async (_req, res): Promise<void> => {
  const packages = await db
    .select()
    .from(packagesTable)
    .orderBy(packagesTable.price);
  res.json(packages);
});

router.get("/packages/:id", async (req, res): Promise<void> => {
  const params = GetPackageParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }

  const [pkg] = await db
    .select()
    .from(packagesTable)
    .where(eq(packagesTable.id, params.data.id));

  if (!pkg) {
    res.status(404).json({ error: "Package not found" });
    return;
  }

  res.json(pkg);
});

router.get("/user-packages", async (_req, res): Promise<void> => {
  const userPackages = await db
    .select()
    .from(userPackagesTable)
    .orderBy(userPackagesTable.startDate);
  res.json(userPackages);
});

router.post("/user-packages", async (req, res): Promise<void> => {
  const parsed = PurchasePackageBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }

  const [pkg] = await db
    .select()
    .from(packagesTable)
    .where(eq(packagesTable.id, parsed.data.packageId));

  if (!pkg) {
    res.status(404).json({ error: "Package not found" });
    return;
  }

  const startDate = new Date();
  const endDate = new Date();
  endDate.setDate(endDate.getDate() + pkg.durationDays);

  const [userPackage] = await db
    .insert(userPackagesTable)
    .values({
      userId: parsed.data.userId,
      packageId: parsed.data.packageId,
      startDate,
      endDate,
      status: "active",
      listingsUsed: 0,
    })
    .returning();

  res.status(201).json(userPackage);
});

export default router;
